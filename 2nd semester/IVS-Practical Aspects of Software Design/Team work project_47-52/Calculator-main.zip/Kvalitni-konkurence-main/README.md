Enviroment
---------
Windows 64bit

Authors
------
Kvalitni konkurence  
- xbedna80 Kristýna Bednářová
- xcepel03 Kateřina Čepelková
- xphamo00 Thu Tra Phamová	 
- xtrnov01 Eva Trnovská 

License
-------
GNU General Public  Licence v3.0

Instalation 
-------
1. Start installer file: instal.exe
2. Follow instructions of the installer 
  
    2.1 Confirm licenses
  
    2.2 Select destination location
  
    2.3 Select to create a desktop shorcut
  
    2.4 Confirm instalation 
  
3. Wait for installer to finish the installation 
4. Yay you did it. Enjoy! Another info is in user guide. 


Uninstall  
-------
1. Start file unins00.exe 
2. Follow its instructions
3. It will uninstall all files and programs related to the app. 
4. Installer won't be deleted. 
5. Yay you did it! Hope you liked our app!  
