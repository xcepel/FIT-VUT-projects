"""
@file tests.py
@brief Tests for math_lib.py by Kvalitni konkurence IVS Team

How to run: in Windows command line type "python -m pytest tests.py" in the directory containing both tests.py and math_lib.py
Epsilon for floating point operations: 0.000001 
"""

import pytest
from math_lib import *


def is_in_range(epsilon, result, expected):
    """ Checks that operation result does not differ from expected by more than epsilon

    Function for tests with floating point inputs/outputs
    @param epsilon maximum allowed difference from expected result
    @param result result of given mathematical operation
    @param expected expected result
    """
    return (result >= expected - epsilon) and (result <= expected + epsilon)


def test_addition():
    """ Tests of operation "plus" with integers """

    assert plus(2, 3) == 5
    assert plus(3, 2) == 5
    assert plus(12345, 9876) == 22221
    assert plus(0, -662) == -662


def test_addition_float():
    """ Tests of operation "plus" with floats """
    assert is_in_range(0.000001, plus(2.004, 6.997), 9.001)  # expected True
    assert not is_in_range(0.000001, plus(98.234, 2111.9871), 2210.223)  # expected False


def test_subtraction():
    """ Tests of operation "minus" with integers """
    assert minus(2, 3) == -1
    assert minus(30009, 43221) == -13212
    assert minus(43221, 30009) == 13212
    assert minus(-5, 12) == -17
    assert minus(32, -42) == 74


def test_subtraction_float():
    """ Tests of operation "minus" with floats """
    assert is_in_range(0.000001, minus(2.004, 6.997), -4.993)
    assert is_in_range(0.000001, minus(2456.0981, -98.333), 2554.4311001)


def test_multiplication():
    """ Tests of operation "multiply" with integers """
    assert multiply(2, 3) == 6
    assert multiply(321, 888) == 285048
    assert multiply(-23, 999) == -22977
    assert multiply(-24, -17) == 408
    

def test_multiplication_float():
    """ Tests of operation "multiply" with floats """
    assert is_in_range(0.000001, multiply(78.286, 991.574), 77626.362164)
    assert not is_in_range(0.000001, multiply(65.6666, -41.08), -2697.583926)
    

def test_division():
    """ Tests of operation "divide" with integers """
    assert divide(3, 2) == 1.5
    assert divide(544, -8) == -68
    assert divide(-13202, -23) == 574
    assert divide(0, 31) == 0


def test_division_float():
    """ Tests of operation "divide" with floats """
    assert is_in_range(0.000001, divide(65.62, -0.08), -820.25)
    assert is_in_range(0.000001, divide(12.573829, 9), 1.3970921)


def test_division_throw():
    """ Tests of operation "divide" raising exceptions """
    with pytest.raises(Exception):
        divide(1, 0)
    with pytest.raises(Exception):
        divide(-85, 0)


def test_factorial():
    """ Tests of operation "factorial" """
    assert factorial(3) == 6
    assert factorial(5) == 120
    assert factorial(0) == 1
    assert factorial(9) == 362880


def test_factorial_throw():
    """ Tests of operation "factorial" raising exceptions """
    with pytest.raises(Exception):
        factorial(-1)
    with pytest.raises(Exception):
        factorial(-13)
    with pytest.raises(Exception): 
        factorial(4.5)
    with pytest.raises(Exception): 
        factorial(23)


def test_power():
    """ Tests of operation "power" with integers """
    assert power(2, 5) == 32
    assert power(-3, 3) == -27
    assert power(-4, 2) == 16
    assert power(5, 7) == 78125
    assert power(0.5, 2) == 0.25


def test_power_float():
    """ Tests of operation "power" with floats """
    assert is_in_range(0.000001, power(23.1, 3), 12326.391)
    assert is_in_range(0.000001, power(-2.28, 14), 102585.9437175)


def test_root():
    """ Tests of operation "root" both with integers and floats """
    assert root(25, 2) == 5
    assert root(-32, 5) == -2
    assert is_in_range(0.000001, root(68921, 3), 41)
    assert is_in_range(0.000001, root(-0.125, 3), -0.5)


def test_root_throw():
    """ Tests of operation "root" raising exceptions """
    with pytest.raises(Exception):
        root(-1, 2)
    with pytest.raises(Exception):
        root(-85, 42)


def test_remainder():
    """ Tests of operation "root" modulo """
    assert modulo(13, 10) == 3
    assert modulo(99, 2) == 1
    assert modulo(16, 4) == 0


def test_modulo_throw():
    """ Tests of operation "modulo" throwing exceptions """
    with pytest.raises(Exception):
        modulo(1, 0)
    with pytest.raises(Exception):
        modulo(-85, 0)
    with pytest.raises(Exception):
        modulo(56.9, 12)
    with pytest.raises(Exception):
        modulo(69, 12.5)

########################### END OF tests.py FILE ########################### 
