"""
@file math_lib.py
@brief Math library by Kvalitni konkurence IVS Team
"""


def plus(n1, n2):
    """ Function "plus" returns result of n1 + n2 """
    return n1 + n2


def minus(n1, n2):
    """ Function "minus" returns result of n1 - n2 """
    return n1 - n2


def multiply(n1, n2):
    """ Function "multiply" returns result of n1 * n2 """
    return n1 * n2


def divide(n1, n2):
    """ Function "divide" returns result of n1 / n2 or exception if n2 == 0 """
    if n2 == 0:
        raise ZeroDivisionError("Cannot divide by zero.")
    else:
        return n1 / n2


def factorial(n):
    """ Function "factorial" returns factorial n or exception if n < 0 or float """
    if (int(n) != n):
        raise Exception("Factorial of float numbers is undefined.")
    if n > 22:
        raise Exception("Factorial of numbers greater than 22 is unsupported.")
    if n >= 0:
        fact = 1
        while n > 1:
            fact *= n
            n -= 1
        return fact
    else:
        raise Exception("Factorial of negative numbers is undefined.")


def power(n1, n2):
    """ Function "power" returns n1 to the power of n2 """
    return n1 ** n2


def root(n1, n2):
    """ Function "sqrt" returns n2-st/th root of n1 """
    if (n2 % 2) == 0:
        if n1 < 0:
            raise Exception("Even root of negative numbers is undefined.")
    if n1 < 0:
        return -((-n1) ** (1 / n2))
    return n1 ** (1 / n2)
# warning - in need of rounding (float arithmetic)


def modulo(n1, n2):
    """ Function "modulo" returns modulo of n1 / n2 or exception if n2 == 0 or if n1 or n2 are float numbers """
    if (int(n1) != n1) or (int(n2) != n2):
        raise Exception("Modulo of float numbers is undefined.")
    if n2 == 0:
        raise ZeroDivisionError("Cannot divide by zero.")
    else:
        return n1 % n2

########################### END OF math_lib.py FILE ###########################
