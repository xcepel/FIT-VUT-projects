"""
@file calc_logic.py
@brief The logic behind KK Calculator (buttons, calling math functions ect.
"""

from PyQt5 import QtGui, QtCore, QtWidgets
from calc_ui import Ui_MainWindow
from math_lib import *
import sys
import os

#TODO: chybove stavy
lib_func=[plus, minus, multiply, divide, modulo, power, root, factorial]
str_op = ['+', '-', '*', '/', '%', '^', '√', '!']

#Hints
hints = ["power - number x multiplied y times by itself",
         "root - root of x is another number which when multiplied by itself y times equals x - first operand is index, second is radicant, both must be set",
         "factorial - integer multiplied by every integer below till 0 - first type number, then !",
         "⌫ - deletes one symbol from the righ",
         "CE - clears display"]
span_start = "<SPAN STYLE='font-size:15px'>"
span_end = "</SPAN>"
help_on = False             # Help is initially disabled 

error_on = False            # Global indicator of an invoked error
result_displayed = False    # Global indicator of result being displayed on the screen, use for further calculations
calc_str = ""               # String displayed to user, used for parsing the input when '=' is pressed
op_list = []                # Ordered list of operations  present in the calculation
num_list = []               # List of operands present in the calculation 
result = 0                  # Temporary result stored for further calculations




class MyMainWindow(QtWidgets.QMainWindow, Ui_MainWindow):
    """ @class Calculator's main window """
    def __init__(self):
        """ Contructor of main window """
        super().__init__()
        self.setupUi(self)
        self.show()
        
        directory = os.path.dirname(__file__)
        self.setWindowIcon(QtGui.QIcon(directory + '/kk_icon.png'))
        
        ### Number buttons' setup ###
        self.bn0.clicked.connect(lambda: self.get_text("0"))
        self.bn1.clicked.connect(lambda: self.get_text("1"))
        self.bn2.clicked.connect(lambda: self.get_text("2"))
        self.bn3.clicked.connect(lambda: self.get_text("3"))
        self.bn4.clicked.connect(lambda: self.get_text("4"))
        self.bn5.clicked.connect(lambda: self.get_text("5"))
        self.bn6.clicked.connect(lambda: self.get_text("6"))
        self.bn7.clicked.connect(lambda: self.get_text("7"))
        self.bn8.clicked.connect(lambda: self.get_text("8"))
        self.bn9.clicked.connect(lambda: self.get_text("9"))

        ### Operation buttons' setup ###
        self.b_plus.clicked.connect(lambda: self.get_text("+"))
        self.b_minus.clicked.connect(lambda: self.get_text("-"))
        self.b_multiply.clicked.connect(lambda: self.get_text("*"))
        self.b_divide.clicked.connect(lambda: self.get_text("/"))
        self.b_modulo.clicked.connect(lambda: self.get_text("%"))
        self.b_power.clicked.connect(lambda: self.get_text("^"))
        self.b_sqrt.clicked.connect(lambda: self.get_text("√"))
        self.b_fact.clicked.connect(lambda: self.get_text("!"))
        self.b_help.clicked.connect(lambda: self.switch_help())

        ### User buttons' setup ###
        self.b_dot.clicked.connect(lambda: self.get_text("."))
        self.b_result.clicked.connect(lambda: self.show_result())
        self.b_clear.clicked.connect(lambda: self.clear_all())
        self.b_delete.clicked.connect(lambda: self.delete_char())

        ### Hints ###
        self.b_power.enterEvent = lambda e: self.displayHelp(0)
        self.b_power.leaveEvent = lambda e: self.removeHelp()
        self.b_sqrt.enterEvent = lambda e: self.displayHelp(1)
        self.b_sqrt.leaveEvent = lambda e: self.removeHelp()
        self.b_fact.enterEvent = lambda e: self.displayHelp(2)
        self.b_fact.leaveEvent = lambda e: self.removeHelp()
        self.b_delete.enterEvent = lambda e: self.displayHelp(3)
        self.b_delete.leaveEvent = lambda e: self.removeHelp()
        self.b_clear.enterEvent = lambda e: self.displayHelp(4)
        self.b_clear.leaveEvent = lambda e: self.removeHelp()
        self.b_help.enterEvent = lambda e: self.help_hint(True)
        self.b_help.leaveEvent = lambda e: self.help_hint(False)

    def switch_help(self):
        """ Turns on/off hovering help tips on display """
        global help_on
        if (help_on):
            help_on = False
        else:
            help_on = True

    def help_hint(self, on):
        """ If user hovers the mouse over '?' button, a quick tip on hints' usage is shown on display """
        if (on):
            self.display.setText("Click on '?' button to enable/disable built-in hints. Hover over the buttons to get tips on display. For more information, check the user guide.")
        else:
            self.display.setText(calc_str)

    def displayHelp(self, num_hint):
        """
        Displays help on display.
        @param num_hint number of hint in array of hint texts

        """
        if (help_on):
            my_hint = span_start + "<br>" + "❀ " + hints[num_hint] + " ❀" + span_end
            self.display.setText(calc_str + my_hint)

    def removeHelp(self):
        """ When user stops hovering over the button, original display text appears."""
        self.display.setText(calc_str)
    
    def keyPressEvent(self, event):
        """ Permits the user to enter numbers, operations as well as obtaing the result or clearing the display using keyboard """
        my_key = event.key()
        if (my_key >= 0x30 and my_key <= 0x39): # for numbers
            tmp = my_key - 0x30
            self.get_text(str(tmp))
        elif(my_key == QtCore.Qt.Key_Plus):
            self.get_text('+')
        elif(my_key == QtCore.Qt.Key_Minus):
            self.get_text('-')
        elif(my_key == QtCore.Qt.Key_Asterisk): 
            self.get_text('*')
        elif(my_key == QtCore.Qt.Key_Slash):
            self.get_text('/')
        elif(my_key == QtCore.Qt.Key_Percent):
            self.get_text('%')
        elif(my_key == QtCore.Qt.Key_Period or my_key == QtCore.Qt.Key_Comma):
            self.get_text('.')
        elif(my_key == QtCore.Qt.Key_Enter or my_key == QtCore.Qt.Key_Return):
            self.show_result()
        elif(my_key == QtCore.Qt.Key_Delete):
            self.clear_all()
        elif(my_key == QtCore.Qt.Key_Backspace):
            self.delete_char()


    ### GUI handling functions ###

    def clear_all(self):
        """ Deletes the contents od num_list, op_list, calc_str, sets result_display to False and if there are no errors present, clears the display """
        global num_list, op_list, current_num, display_str, result_displayed, calc_str
        num_list.clear()
        op_list.clear()
        calc_str =""
        result_displayed = False
        if not error_on:
            self.display.setText("")

    def delete_char(self):
        """ Deletes last char from user input in display string and updates the display """
        global calc_str
        calc_str = calc_str[0:-1]
        self.display.setText(calc_str)
        if(len(calc_str) == 0):
            self.clear_all()


    def get_text(self, pressed_button):
        """ Adds user input to the display string based on buttons/keys pressed.

            @param pressed_button number/sign/period entered by user via keyboard/buttons
            Runs the first chceck ensuring no blatant mistakes are included. The rest is check by str_to_list function. """
        global calc_str, list_op, result_displayed
        if (result_displayed):
            self.clear_all()
            if (pressed_button in str_op):
                calc_str = str(result)
            result_displayed = False

        ## Check correct input ##
        if ((len(calc_str) > 1) and (pressed_button == '!') and (calc_str[-1] == '!')):
            pass
        elif ((len(calc_str) > 1) and (calc_str[-1] in str_op) and (pressed_button in str_op) and (calc_str[-1] != '!') and (pressed_button != '-' )):
            ## User cannot put two operations in a row. Operation will be changed (previous operation sign disappears).
            calc_str=calc_str[0:-1] + pressed_button
        elif((len(calc_str) > 1) and (calc_str[-1] == '!') and not ((pressed_button in str_op))):
            ## User cannot put a number directly after factorial sign (operation needed).
            pass
        elif ((len(calc_str) == 0) and (pressed_button in str_op) and (pressed_button != '-')):
            ## Calculation cannot start with an oeration sign, except for '-'
            calc_str=""
        elif (len(calc_str) == 1 and calc_str[0] == '-' and pressed_button in str_op):
            ## If a calculation starts wit '-' sign, next entered symbol must be a number
            pass
        elif (len(calc_str) >= 1 and ((calc_str[-1] == '.' and pressed_button == '.') or (calc_str[-1] == '.' and pressed_button in str_op))):
            ## User cannot put '.' twice in a row or put an operation sign directly after '.'
            pass
        elif (len(calc_str) >= 2 and pressed_button == '-' and calc_str[-1] == '-' and (calc_str[-2] in str_op and calc_str[-2] != '!')):
            ## User cannot type 3 operations in a row (except for factorial)
            pass
        else:
            calc_str+=pressed_button
        self.display.setText(calc_str)

    def str_to_list(self):
        """ Divides display string into numbers and operations and stores them in adequate lists """
        global num_list, op_list, calc_str, str_op
        if (len(calc_str) == 0):
            return
        elif (calc_str[-1] in str_op and calc_str[-1] != '!'):
            self.clear_all()
            self.display.setText('ERROR! Calculation cannot end with an operator (except for "!").')
            return
        elif (calc_str[-1] == '.'):
            self.clear_all()
            self.display.setText('ERROR! Calculation cannot end with a peridos (".")')
            return
        i1 = 0
        i2 = 0
        prev = ''

        ## Changes 'e' to '*10^'
        index = 0
        for i in calc_str:
            if (i == 'e'):
                calc_str = calc_str[:(index)] + "*10^" + calc_str[(index+1):]
            index = index + 1

        ## Splits string to lists of operations and numbers
        for i in calc_str:
            if (i in str_op):
                if (i2 == 0 and i == '-'):
                    pass
                elif (prev != '!' and i != '-'): 
                    num_list.append(float(calc_str[i1:i2]))
                    op_list.append(i)
                    prev = i
                    i1 = i2 + 1
                elif (i2 > 0 and i == '-' and not (calc_str[i2-1] in str_op)):
                    num_list.append(float(calc_str[i1:i2]))
                    op_list.append(i)
                    prev = i
                    i1 = i2 + 1
                elif (prev == '!'):
                    op_list.append(i)
                    prev = i
                    i1 = i2 + 1
            i2 = i2 + 1
        if(len(calc_str) > i1):
            num_list.append(float(calc_str[i1:]))

    def show_result(self):
        """ Calls str_to_list to divide display string into operations and numbers and calls calculate functions to get the final gesult """
        global op_list, num_list, calc_str, result_displayed, result, error_on
        
        ## Prevents crash when the user is undisciplined ##
        if (len(calc_str) and not result_displayed):
            self.str_to_list()
            if(not len(calc_str)): # If an error occurs while diving the string
                return
        else:
            return

        # Remake: while/for cyklus
        self.calculate_unary("!")
        self.calculate_binary("^")
        self.calculate_binary("√")
        self.calculate_binary("/")
        self.calculate_binary("%")
        self.calculate_binary("*")
        self.calculate_binary("-")
        self.calculate_binary("+")

        ## If result is an integer, it is displayed without the fractional part ##
        if (num_list[0] == int(num_list[0])):
            num_list[0] = int(num_list[0])
        else:
            num_list[0] = round(num_list[0], 15) ## Float result is rounded to 15 decimals

        if not error_on:
            calc_str=calc_str + '= ' + str(num_list[0])
            result = num_list[0]
            self.display.setText(calc_str)
            result_displayed = True
        else:
            self.clear_all()
            error_on = False

    def calculate_unary(self, operation):
        """ Calculates unary operations.
            @warning Converts operand to int! """
        
        global num_list, op_list, error_on
        if (operation in op_list):
            op_index = str_op.index(operation)
            j = 0
            for i in op_list:
                if (i == operation):
                    try:
                        num_list[j] = lib_func[op_index](num_list[j])
                        del op_list[j]
                    except Exception as e:
                        self.display.setText("ERROR! " + str(e))
                        del op_list[j]
                        error_on = True
                        return
                j=j+1


    def calculate_binary(self, operation):
        """ Calculates binary operations (operations with 2 operand)
            @warning If selected operation is √ (root), 1st operand found in list is considered index, 2nd is considered radicand """
        global num_list, op_list, error_on
        skip = 0
        if (operation in op_list):
            op_index = str_op.index(operation)
            for i in range (len(op_list)):
                if (op_list[skip] == operation):
                    try:
                        if(operation == "√"): # Swap of operands
                            num_list[skip] = lib_func[op_index](num_list[skip+1], num_list[skip])
                        else:
                            num_list[skip] = lib_func[op_index](num_list[skip], num_list[skip+1])
                    except Exception as e:
                        self.display.setText("ERROR! " + str(e))
                        error_on = True
                        return
                    del num_list[skip+1]
                    del op_list[skip]
                else:
                    skip = skip + 1


########################### END OF calc_logic.py FILE ########################### 
