"""
@file main.py
@brief Setup of the app
"""

from PyQt5 import QtGui, QtCore, QtWidgets
from calc_logic import *
from math_lib import *


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    app.setStyleSheet("QWidget{font-size: 14pt;}")
    window = MyMainWindow()
    window.show()
    sys.exit(app.exec_())


########################### END OF main.py FILE ########################### 
