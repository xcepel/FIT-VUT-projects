"""
@file profiling.py
@brief Profiling of math_lib by Kvalitni konkurence IVS Team

How to run:
    Linux: python ./profiling.py < [stdin]
"""

import sys
from math_lib import *

""" Read from stdin """
numString = sys.stdin.read()
nums = numString.split()
for i in range(0, len(nums)):  # conversion of values to floats
    nums[i] = float(nums[i])
N = len(nums)

try:
    """" N - 1 """
    one = minus(N, 1)

    """" 1 / (N - 1) """
    two = divide(1, one)

    """" pow(nums) """
    three = []
    for item in nums:
        three.append(power(item, 2))

    """" sum of pow(nums) """
    four = 0
    for item in three:
        four = plus(four, item)

    """" 1 / N """
    five = divide(1, N)

    """" sums of nums """
    six = 0
    for item in nums:
        six = plus(six, item)

    """" (1 / N) * sums of nums"""
    seven = multiply(five, six)

    """" pow((1 / N) * sums of nums) """
    eight = power(seven, 2)

    """" N * pow((1 / N) * sums of nums) """
    nine = multiply(N, eight)

    """" sum of pow(nums) - (N * pow((1 / N) * sums of nums)) """
    ten = minus(four, nine)

    """ (1 / (N - 1)) * (sum of pow(nums) - (N * pow((1 / N) * sums of nums))) """
    eleven = multiply(two, ten)

    """ sqrt((1 / (N - 1)) * (sum of pow(nums) - (N * pow((1 / N) * sums of nums)))) """
    s = root(eleven, 2)
    print(s)

except Exception:
    print("Error. One of the numbers is invalid.")

########################### END OF profiling.py FILE ###########################
