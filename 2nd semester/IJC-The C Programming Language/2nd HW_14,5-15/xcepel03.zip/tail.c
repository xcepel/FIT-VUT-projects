// tail.c
// Reseni IJC-DU2, priklad 1), 13. 4. 2022
// Autor: Katerina Cepelkova, FIT
// Prelozeno: gcc 11.2
//


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>

#define MAX_LEN 4095


int main(int argc, char *argv[])
{
    int n = 10; //pocet radku
    FILE *fp = NULL;
    bool exceeded = false;
    char *ptr; // pro kontrolu vystupu strtol

    // kontrola chybneho vstupu
    if (argc > 4)
    {
            fprintf(stderr, "Chybny pocet argumentu.\n");
            return 1;
    }

    // kontrola vstupu a ulozeni paramatru lines
    if (argc == 3 || argc == 4)
    {
        if (!strcmp(argv[1], "-n"))
        {
            n = strtol(argv[2], &ptr, 10);
            if (*ptr != '\0') // pokud nebyly vsechny znamenka prevedeny na int
            {
                fprintf(stderr, "Zadan chybny vstup - po -n nebylo zadano cislo.\n");
                return 1;
            }
            if (n == 0)
                return 0;
            if (n < 0)
            {
                fprintf(stderr, "Zadan chybny vstup - n nemuze byt zaporne.\n");
                return 1;
            }
        }   
        else
        {
            fprintf(stderr, "Zadan chybny vstup.\n");
            return 1;
        }
    }

    // nacteni vstupu/souboru do fp
    if (argc == 2)
    {
        fp = fopen(argv[1], "r");
        if (fp == NULL)
        {
            fprintf(stderr, "Soubor nelze otevrit.\n");
            return 1;
        }
    }
    else if (argc == 4)
    {
        fp = fopen(argv[3], "r");
        if (fp == NULL)
        {
            fprintf(stderr, "Soubor nelze otevrit.\n");
            return 1;
        }
    }
    else
    {
        fp = stdin;
    }

    // alokace radku do 2d pole lines[pocet_radku][max_velikost_radku]   
    char **lines = calloc(n, sizeof(char*));
 
    for (int i = 0; i < n; i++)
    {
        lines[i] = calloc(MAX_LEN, sizeof(char));
    }
   
    // ukladani poslednich n radku
    int row = 0;
    int c = 0; // int na "odhazovani" prebytku radku
    while(fgets(lines[row%n], MAX_LEN, fp) != NULL)
    {
        c = 0;
        // overeni, zda se nacetl cely radek
        if (lines[row%n][MAX_LEN - 2] != '\n' && lines[row%n][MAX_LEN - 2] != '\0')
        {
            if (!exceeded)    
            {
                exceeded = true;
                fprintf(stderr, "Prekrocen limit delky radku %d. Text zkracen.\n", MAX_LEN);
            }
            lines[row%n][MAX_LEN - 2] = '\n';
            while (c != '\n' && c != EOF) // "odhozeni" zbytku radku po limitu
            {
                c = fgetc(fp);
            }
        }
        row++;
    }

    // tisk poslednich n radku ze souboru
    for (int i = row - n; i < row; i++) // %(row - n) = ziskani posledniho radku, kde jsme zapisovali
    {
        // osetreni, pokud soubor ma mene radku nez jsme chteli nacist
        if (i < 0)
            i = 0;
        printf("%s", lines[i%n]);
    }

    // uvolneni radku
    for (int i = 0; i < n; i++)
    {
        free(lines[i]);
    }
    free (lines);

    fclose(fp);

    return 0;
}
