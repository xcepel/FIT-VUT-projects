// wordcount.c
// Reseni IJC-DU2, priklad 2), 20. 4. 2022
// Autor: Katerina Cepelkova, FIT
// Prelozeno: gcc 11.2


#include "htab.h"
#include "io.h"

#define MAX_WORD_LEN 127

void print(htab_pair_t *data)
{
    printf("%s %d\n", data->key, data->value);
}


int main(int argc, char *argv[])  
{
    FILE *fp;
    htab_t *table = htab_init(2); 
    if (table == NULL)
    {
        fprintf(stderr, "Nepovedena alokace.\n");
        return 1;
    }

    size_t size1 = htab_size(table);
    size_t bucket = htab_bucket_count(table);

    printf("Size = %ld.\n", size1);
    printf("Arr_size = %ld.\n", bucket);
    
    // 1. vlozeni
    htab_key_t word = "Ahoj";
    htab_pair_t *ahoj = htab_lookup_add(table, word);
    if (ahoj == NULL)
    {
        fprintf(stderr, "Chyba.\n");
        return 1;
    }
    ahoj->value++;
    printf("'Ahoj' bylo napsano %dx\n", ahoj->value);
    
    printf("Size = %ld\n", htab_size(table));
 
    // 2. vlozeni

    ahoj = htab_lookup_add(table, word);
    if (ahoj == NULL)
    {
        fprintf(stderr, "Chyba.\n");
        return 1;
    }
    ahoj->value++;
    printf("'Ahoj' bylo napsano %dx\n", ahoj->value);
    
    printf("Size = %ld\n", htab_size(table));
    
    // htab_find
    htab_pair_t *check = htab_find(table, word);
    if (check == NULL)
    {
        fprintf(stderr, "Chyba.\n");
        return 1;
    }
    else
        printf("'Ahoj' bylo napsano %dx\n", check->value);

    // htab_erase
    htab_key_t word1 = "cau";
    htab_pair_t *cau = htab_lookup_add(table, word1);
    if (cau == NULL)
    {
        fprintf(stderr, "Chyba.\n");
        return 1;
    }
    cau->value++;
    printf("'cau' bylo napsano %dx\n", cau->value);
    
    printf("Size = %ld\n", htab_size(table));
    
    if (htab_erase(table, word1))
        printf("odstraneno\n");

    printf("Size = %ld\n", htab_size(table));
   
    //htab_resize 
    cau = htab_lookup_add(table, word1);
    if (cau == NULL)
    {
        fprintf(stderr, "Chyba.\n");
        return 1;
    }
    cau->value++;
    htab_key_t word2 = "nazdar";
    htab_pair_t *nazdar = htab_lookup_add(table, word2);
    if (nazdar == NULL)
    {
        fprintf(stderr, "Chyba.\n");
        return 1;
    }
    nazdar->value++;
    htab_resize(table, 4);
    ahoj = htab_find(table, word);
    if (ahoj == NULL)
    {
        fprintf(stderr, "Chyba.\n");
        return 1;
    }
    printf("'Ahoj' bylo nalezeno a jeho value je %dx\n", ahoj->value);
    printf("Size = %ld\n", htab_bucket_count(table));
   
    htab_for_each(table, &print);
    // vycisteni cele tabulky
    htab_clear(table);
    printf("Size = %ld\n", htab_size(table));

    // uvolneni tabulky
    htab_free(table);
    
    // testova read_word
    printf("\n\n");
    
    char str1[10];
    char str2[10];
    char str3[10];
    char str4[10];
    fp = fopen(argv[1], "r");
    if (fp == NULL)
    {
        fprintf(stderr, "Soubor nelze otevrit.\n");
        return 1;
    }

    read_word(str1, 10, fp);
    printf("%s\n",str1);
    read_word(str2, 10, fp);
    printf("%s\n",str2);
    read_word(str3, 10, fp);
    printf("%s\n",str3);
    read_word(str4, 10, fp);
    printf("%s\n",str4);
    return 0;
}
