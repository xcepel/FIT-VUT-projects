// htab_clear.c
// Reseni IJC-DU2, priklad 2), 19. 4. 2022
// Autor: Katerina Cepelkova, FIT
// Prelozeno: gcc 11.2


#include "htab_full.h"

void htab_clear(htab_t * t)
{
    size_t size = htab_bucket_count(t);
    struct htab_item *item;
    struct htab_item *cache; // mezipamet pro ukladani next

    for (size_t i = 0; i < size; i++)
    {   
        item = t->arr_ptr[i];
        while (item != NULL)
        {
            cache = item->next;
            free((void *)item->data.key);
            free((void *)item);
            item = cache;
        }
    }
    
    // osetreni pred double free
    for (size_t i = 0; i < size; i++)
        t->arr_ptr[i] = NULL;
    t->size = 0;
}
