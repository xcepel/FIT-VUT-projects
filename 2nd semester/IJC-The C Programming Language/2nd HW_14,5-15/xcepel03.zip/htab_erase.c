// htab_erase.c
// Reseni IJC-DU2, priklad 2), 19. 4. 2022
// Autor: Katerina Cepelkova, FIT
// Prelozeno: gcc 11.2


#include "htab_full.h"

bool htab_erase(htab_t *t, htab_key_t key)
{
    size_t idx = htab_hash_function(key) % htab_bucket_count(t);
    
    struct htab_item *prev = t->arr_ptr[idx];
    struct htab_item *removed = t->arr_ptr[idx];
   
    // pokud prvek neexistuje nemuze byt odstranen
    if (removed == NULL)
        return false;
    
    // kontrola 1. polozky
    if (!strcmp(removed->data.key, key))
    {
        t->arr_ptr[idx] = removed->next;
        t->size--;
        free((void *)removed->data.key);
        free((void *)removed);
        // prumer < AVG_LEN_MIN -> resize na 1/2
        if (htab_size(t)/htab_bucket_count(t) < AVG_LEN_MIN)
            htab_resize(t, (htab_bucket_count(t)/2));
        return true;
    }
    
    // kontrola zbyteku polozek
    removed = removed->next;
    while(removed != NULL)
    {
        if(!strcmp(removed->data.key, key))
        {
            prev->next = removed->next;
            t->size--;
            free((void *)removed->data.key);
            free((void *)removed);
            // prumer < AVG_LEN_MIN -> resize na 1/2
            if (htab_size(t)/htab_bucket_count(t) < AVG_LEN_MIN)
                htab_resize(t, (htab_bucket_count(t)/2));
            return true;
        }
        prev = removed;
        removed = removed->next;
    }    

    // prvek nebyl nalezen, proto nemuze byt odstranen
    return false;
}
