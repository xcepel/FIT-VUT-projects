// htab_lookup_add.c
// Reseni IJC-DU2, priklad 2), 19. 4. 2022
// Autor: Katerina Cepelkova, FIT
// Prelozeno: gcc 11.2


#include "htab_full.h"

htab_pair_t *htab_lookup_add(htab_t *t, htab_key_t key)
{
    // vyhledani v jiz existujicich
    size_t idx = htab_hash_function(key) % htab_bucket_count(t);
 
    struct htab_item *searched = t->arr_ptr[idx];
    while(searched != NULL)
    {
        if (!strcmp(searched->data.key, key))
            return &searched->data;
        searched = searched->next;
    }
   
    // pokud zaznam nebyl nalezen je vytvoren novy
    struct htab_item *item = malloc(sizeof(struct htab_item));
    char *str = malloc(strlen(key) + 1);
    if (!item || !str)
    {
        free(str);
        free(item);
        return NULL;
    }

    strcpy(str, key);
    item->data.key = str;
    item->data.value = 0; // pocet vyskytu bude pridan az pozdeji (jen lookup)

    // ukladani zaznamu na zacatek seznamu
    item->next = t->arr_ptr[idx];
    t->arr_ptr[idx] = item;
    t->size++; // pridan novy zaznam

    //prumer > AVG_LEN_MAX -> resize na 2x vic
    if (htab_size(t)/htab_bucket_count(t) > AVG_LEN_MAX)
        htab_resize(t, (htab_bucket_count(t)*2));

    return &item->data;
}
