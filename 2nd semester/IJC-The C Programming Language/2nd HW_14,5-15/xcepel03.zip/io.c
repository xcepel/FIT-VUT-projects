// io.c
// Reseni IJC-DU2, priklad 2), 19. 4. 2022
// Autor: Katerina Cepelkova, FIT
// Prelozeno: gcc 11.2


#include "io.h"

int read_word(char *s, int max, FILE *f)
{
    int c = fgetc(f); 
    int char_count = 0;
    static bool too_long = false;
    
    while (isspace(c) || c == EOF) // odstraneni prebyvajicich whitespace
    {
        c = fgetc(f);
        if (c == EOF)
            return EOF;
    }
    
    s[0] = c; // ulozeni prvniho pismenka slova, co jsem nacetla
    for (char_count = 1; char_count < max-1; char_count++)
    {   
        c = fgetc(f);
        if (isspace(c)) // pokud jsme narazili na white space
            break;
        s[char_count] = c;
    }
    s[char_count] = '\0'; // ukonceni stringu

    if (!isspace(c) || c == EOF) // odhozeni presahu slova
    {
        if (!too_long)
        { 
            fprintf(stderr, "Delka slova presahla implementacni limit. Slovo zkraceno.\n");
            too_long = true;
        }
        while (!isspace(c))
            c = fgetc(f);
    }

    if (c == EOF)
        return EOF;

    return char_count;
}
