// htab_size.c
// Reseni IJC-DU2, priklad 2), 19. 4. 2022
// Autor: Katerina Cepelkova, FIT
// Prelozeno: gcc 11.2


#include "htab_full.h"

size_t htab_size(const htab_t *t)
{
    return t->size;
}
