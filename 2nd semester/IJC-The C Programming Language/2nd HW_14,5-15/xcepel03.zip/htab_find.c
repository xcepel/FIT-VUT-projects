// htab_find.c
// Reseni IJC-DU2, priklad 2), 19. 4. 2022
// Autor: Katerina Cepelkova, FIT
// Prelozeno: gcc 11.2


#include "htab_full.h"

htab_pair_t *htab_find(htab_t *t, htab_key_t key)
{
    size_t idx = (htab_hash_function(key) % htab_bucket_count(t));
    
    struct htab_item *searched = t->arr_ptr[idx];
    while(searched != NULL)
    {
        if (!strcmp(searched->data.key, key))
        {
            return &searched->data;
        }
        searched = searched->next;
    }

    return NULL;
}
