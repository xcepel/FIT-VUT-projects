// io.h
// Reseni IJC-DU2, priklad 2), 19. 4. 2022
// Autor: Katerina Cepelkova, FIT
// Prelozeno: gcc 11.2


#ifndef __IO_H__
#define __IO_H__

#include <ctype.h>
#include <stdio.h>
#include <stdbool.h>

int read_word(char *s, int max, FILE *f);

#endif
