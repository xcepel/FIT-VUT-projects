// htab_full.h
// Reseni IJC-DU2, priklad 2), 19. 4. 2022
// Autor: Katerina Cepelkova, FIT
// Prelozeno: gcc 11.2


#ifndef __HTAB_FULL_H__
#define __HTAB_FULL_H__

#include "htab.h"

typedef struct htab {
        unsigned int size; //pocet zaznamu
        unsigned int arr_size; // velikost pole ukazatelu
        struct htab_item **arr_ptr;
} htab_t;

typedef struct htab_item {
    htab_pair_t data;
    struct htab_item *next;
} htab_item_t;

#endif
