#include "htab_full.h"

void htab_resize(htab_t *t, size_t newn)
{
    size_t oldn = htab_bucket_count(t);
    // newn = 0 -> nastavit na minimalni velikost
    
    if (newn == 0)
        newn = ARR_LEN_MIN;
    if (oldn == newn)
        return;
    else
    {
        // vytvoreni nove htab
        struct htab_item **new_arr_ptr = calloc(newn, sizeof(sizeof(struct htab_item)));
        if (new_arr_ptr == NULL)
            return;
        
        //presunuti starych zaznamu do noveho arr_ptr
        size_t idx;
        struct htab_item *item;
        struct htab_item *next_item;
        for (size_t i = 0; i < oldn; i++)
        {
            item = t->arr_ptr[i];
            while (item != NULL)
            {
                next_item = item->next; // ulozeni dalsiho itemu na presun
                idx = htab_hash_function(item->data.key) % newn; // idx podle nove velikosti
                item->next = new_arr_ptr[idx]; 
                new_arr_ptr[idx] = item;
                item = next_item;
            }
        }

        //uvolneni stare tabulky
        free(t->arr_ptr);
        t->arr_ptr = new_arr_ptr;
        t->arr_size = newn;
    }
}
