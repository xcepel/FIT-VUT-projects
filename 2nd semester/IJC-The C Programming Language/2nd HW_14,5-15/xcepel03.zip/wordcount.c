// wordcount.c
// Reseni IJC-DU2, priklad 2), 20. 4. 2022
// Autor: Katerina Cepelkova, FIT
// Prelozeno: gcc 11.2


#include "htab.h"
#include "io.h"

#define MAX_WORD_LEN 127

// tisk slova a poctu jeho vyskytu
void print(htab_pair_t *data)
{
    printf("%s %d\n", data->key, data->value);
}


int main()  
{
    FILE *fp = stdin; //nacteni vstupu
    int word_check; // vystup z read_word
    char key[MAX_WORD_LEN]; // nactene slovo
    htab_pair_t *loaded; // aktualne spracovavany pair
    htab_t *table; // tabulka

    table = htab_init(ARR_LEN_MIN);
    if (table == NULL)
    {
        fprintf(stderr, "Chybna alokace tabulky.\n");
        return 1;
    }

    // zapis do tabulky
    word_check = read_word(key, MAX_WORD_LEN, fp);

    while (word_check != EOF)
    {
        loaded = htab_lookup_add(table, key);
        if (loaded == NULL)
        {
            fprintf(stderr, "Chybna alokace noveho itemu.\n");
            return 1;
        }
        loaded->value++; // pridani hodnoty
        
        // nacteni dalsiho slova
        word_check = read_word(key, MAX_WORD_LEN, fp);
    }

    // vypsani vysledku
    htab_for_each(table, &print);

    htab_free(table);
    return 0;
}
