// htab_init.c
// Reseni IJC-DU2, priklad 2), 19. 4. 2022
// Autor: Katerina Cepelkova, FIT
// Prelozeno: gcc 11.2


#include "htab_full.h"

htab_t *htab_init(size_t n)
{
    if (n < ARR_LEN_MIN)
        n = ARR_LEN_MIN;
    htab_t *t = calloc(1, sizeof(struct htab));
    if (t == NULL)
        return NULL;
    
    t->arr_ptr = calloc (n, sizeof(t->arr_ptr));
    if (t->arr_ptr == NULL)
    {
        free(t);
        return NULL;
    }
    
    t->arr_size = n;
    return t;
}
