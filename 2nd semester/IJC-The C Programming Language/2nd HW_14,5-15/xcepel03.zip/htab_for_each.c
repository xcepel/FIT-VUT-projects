// htab_for_each.c
// Reseni IJC-DU2, priklad 2), 19. 4. 2022
// Autor: Katerina Cepelkova, FIT
// Prelozeno: gcc 11.2


#include "htab_full.h"

void htab_for_each(const htab_t * t, void (*f)(htab_pair_t *data))
{
    size_t size = htab_bucket_count(t);
    struct htab_item *item;

    for (size_t i = 0; i < size; i++)
    {   
        item = t->arr_ptr[i];
        while (item != NULL)
        {
            f(&item->data);
            item = item->next;
        }
    }
    return;
}
