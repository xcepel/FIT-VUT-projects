// htab_free.c
// Reseni IJC-DU2, priklad 2), 19. 4. 2022
// Autor: Katerina Cepelkova, FIT
// Prelozeno: gcc 11.2


#include "htab_full.h"

void htab_free(htab_t * t)
{
    htab_clear(t);
    free(t->arr_ptr);
    free(t);
}
