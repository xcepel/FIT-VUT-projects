// eratosthenes.h
// Reseni IJC-DU1, priklad a), 22. 3. 2022
// Autor: Katerina Cepelkova, FIT
// Prelozeno: gcc 11.2
//


#include "bitset.h"

#ifndef __ERATOSTHENES_H__
#define __ERATOSTHENES_H__

void Eratosthenes(bitset_t pole);

#endif
