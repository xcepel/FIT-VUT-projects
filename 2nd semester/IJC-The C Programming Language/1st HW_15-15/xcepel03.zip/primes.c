// primes.c
// Reseni IJC-DU1, priklad a), 22. 3. 2022
// Autor: Katerina Cepelkova
// Prelozeno: gcc 11.2
//


#include "eratosthenes.h"
#include "bitset.h"
#include "error.h"
#include <stdio.h>
#include <time.h>


int main()
{ 
    clock_t start = clock();

    bitset_create(pole, 300000000);
    Eratosthenes(pole);
   
    unsigned long i = bitset_size(pole) - 1; //index
    int j = 0; //pocitadlo pro nalezeni 1. z poslednich 10
    //Cyklus hleda odzadu 10 cisel, na i zustane hodnota s 10 cislem od zadu
    for (; j < 10 && i > 0; i--)
    {
        if (!bitset_getbit(pole, i))
            j++;
    }
    
    //Cyklus na tisk poslednich 10 cisel od indexu i
    for (unsigned long k = i; k < bitset_size(pole); k++)
    {   
        if (!bitset_getbit(pole, k))
            printf("%lu\n", k);
    }

    fprintf(stderr, "Time=%.3g\n", (double)(clock()-start)/CLOCKS_PER_SEC);

    return 0;
}
