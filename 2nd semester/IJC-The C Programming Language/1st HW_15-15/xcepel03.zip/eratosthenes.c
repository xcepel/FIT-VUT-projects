// eratosthenes.c
// Reseni IJC-DU1, priklad a), 22. 3. 2022
// Autor: Katerina Cepelkova, FIT
// Prelozeno: gcc 11.2
//


#include "bitset.h"
#include <math.h>


void Eratosthenes(bitset_t pole)
{
    unsigned long top = sqrt(bitset_size(pole));

    bitset_setbit(pole, 0, 1); //0 neni prvocislo
    bitset_setbit(pole, 1, 1); //1 neni prvocislo
    
    //Odstraneni sudych cisel
    for (unsigned long i = 4; i < bitset_size(pole); i += 2) //2 je suda, dalsi suda je 4
    {
        bitset_setbit(pole, i, 1);
    }
    
    //Procisteni zbytku neprvocisel (vsechny nasobky prvocisla vetsi nez jeho 2. mocnina jsou nasteveny na 1)
    for (unsigned long i = 3; i <= top; i +=2)
    {
        if (!bitset_getbit(pole, i))
        {
            for (unsigned long n = i * i; n < bitset_size(pole); n += i) 
            {
                bitset_setbit(pole, n, 1);
            }
        }
    }
}
