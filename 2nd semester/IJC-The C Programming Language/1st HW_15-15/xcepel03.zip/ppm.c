// ppm.c
// Reseni IJC-DU1, priklad b), 22. 3. 2022
// Autor: Katerina Cepelkova, FIT
// Prelozeno: gcc 11.2
//


#include <stdio.h>
#include <stdlib.h>
#include "ppm.h"
#include "error.h"

//Nacte obsah ppm souboru do alokovane struktury ppm
struct ppm *ppm_read(const char *filename)
{
    FILE *fp = fopen(filename, "r");
    if (fp == NULL)
    {    
        warning_msg("ppm_read: Soubor %s se nepodarilo otevrit.\n", filename);
        return NULL;
    }

    unsigned x = 0;
    unsigned y = 0;

    if (fscanf(fp, "P6 %u %u 255 ", &x, &y) != 2)
    {
        warning_msg("ppm_read: Chybny format souboru %s.\n", filename);
        fclose(fp);
        return NULL;
    }

    struct ppm *img = malloc(sizeof(struct ppm) + 3 * x * y);
    img->xsize = x;
    img->ysize = y;
    if (fread(img->data, 1, 3 * x * y, fp) != 3 * x * y)
    {
        warning_msg("ppm_read: Chybne cteni souboru %s.\n", filename);
        fclose(fp);
        return NULL;
    }

    fclose(fp);
    return img;
}

void ppm_free(struct ppm *p)
{
    free(p);
}
