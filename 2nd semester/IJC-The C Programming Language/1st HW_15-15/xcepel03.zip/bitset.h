// bitset.h
// Reseni IJC-DU1, priklad a), 22. 3. 2022
// Autor: Katerina Cepelkova, FIT
// Prelozeno: gcc 11.2
//


#include "error.h"
#include <assert.h>
#include <limits.h>
#include <stdlib.h>

#ifndef __BITSET_H__
#define __BITSET_H__

typedef unsigned long bitset_t[]; //typ bitoveho pole
typedef unsigned long bitset_index_t; //typ indexu bitoveho pole

#define ULONG_BIT (sizeof(unsigned long) * CHAR_BIT)

//velikost pole(zaokrouhleno) + ([0] = velikost)
#define ARR_LEN(velikost) (velikost / ULONG_BIT + (velikost % ULONG_BIT ? 1 : 0) + 1)

//staticky alokuje bitove pole s nazvem jmeno_pole a velikosti velikost, na nultou pozici ulozi jeho velikost v bitech
#define bitset_create(jmeno_pole, velikost) static_assert(velikost > 0, "Zadan chybny vstup - parametr 'velikost' bitoveho pole\n");\
    unsigned long jmeno_pole[ARR_LEN(velikost)] = {velikost}

//dynamicky alokuje bitove pole s nazvem jmeno_pole a velikosti velikost, na nultou pozici ulozi jeho velikost v bitech
#define bitset_alloc(jmeno_pole, velikost) assert(velikost > 0);\
    unsigned long *jmeno_pole = calloc(ARR_LEN(velikost), sizeof(*jmeno_pole)); jmeno_pole[0] = velikost

#ifdef USE_INLINE

inline void bitset_free(bitset_t jmeno_pole)
{
    free(jmeno_pole);
}

//vrati deklarovanou velikost pole v bitech
inline bitset_index_t bitset_size(bitset_t jmeno_pole)
{
    return jmeno_pole[0];
}

//nastavi zadany bit v poli (index) na hodnotu zadanou vyrazem - nulovy vyraz == 0, nenulovy == 1
inline int bitset_setbit(bitset_t jmeno_pole, bitset_index_t index, int vyraz)
{
    return (index >= jmeno_pole[0] ? error_exit("bitset_getbit: index %lu mimo rozsah 0..%lu", (unsigned long)index, (unsigned long)bitset_size(jmeno_pole)), 1 : (jmeno_pole[index / ULONG_BIT + 1] = (vyraz ? jmeno_pole[index / ULONG_BIT + 1] | (1UL << index % ULONG_BIT) : jmeno_pole[index / ULONG_BIT + 1] & (~(1UL << index % ULONG_BIT)))));
}

//ziska hodnotu zadaneho bitu (0 nebo 1)
inline bitset_index_t bitset_getbit(bitset_t jmeno_pole, bitset_index_t index)
{
    return (index >= jmeno_pole[0] ? error_exit("bitset_getbit: Index %lu mimo rozsah 0..%lu", (unsigned long)index, (unsigned long)bitset_size(jmeno_pole)), 1 : (jmeno_pole[index / ULONG_BIT + 1] & (1UL << index % ULONG_BIT)));
}

#else

#define bitset_free(jmeno_pole) free(jmeno_pole)

//vrati deklarovanou velikost pole v bitech
#define bitset_size(jmeno_pole) jmeno_pole[0]

//nastavi zadany bit v poli (index) na hodnotu zadanou vyrazem - nulovy vyraz == 0, nenulovy == 1
#define bitset_setbit(jmeno_pole, index, vyraz) (index >= jmeno_pole[0] ?\
    error_exit("bitset_getbit: index %lu mimo rozsah 0..%lu", (unsigned long)index, (unsigned long)bitset_size(jmeno_pole)), 1 :\
    (jmeno_pole[index / ULONG_BIT + 1] = (vyraz ? \
        jmeno_pole[index / ULONG_BIT + 1] | (1UL << index % ULONG_BIT) :\
        jmeno_pole[index / ULONG_BIT + 1] & (~(1UL << index % ULONG_BIT)))))

//ziska hodnotu zadaneho bitu (0 nebo 1)
#define bitset_getbit(jmeno_pole, index) (index >= jmeno_pole[0] ?\
    error_exit("bitset_getbit: Index %lu mimo rozsah 0..%lu", (unsigned long)index, (unsigned long)bitset_size(jmeno_pole)), 1 :\
    ((jmeno_pole[index / ULONG_BIT + 1] & (1UL << index % ULONG_BIT))))

#endif
#endif
