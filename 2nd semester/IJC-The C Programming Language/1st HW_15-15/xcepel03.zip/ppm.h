// ppm.h
// Reseni IJC-DU1, priklad b), 22. 3. 2022
// Autor: Katerina Cepelkova, FIT
// Prelozeno: gcc 11.2
//


#ifndef __PPM_H__
#define __PPM_H__

struct ppm {
    unsigned xsize;
    unsigned ysize;
    char data[];    // RGB bajty, celkem 3*xsize*ysize
};


struct ppm *ppm_read(const char *filename);

void ppm_free(struct ppm *p);

#endif
