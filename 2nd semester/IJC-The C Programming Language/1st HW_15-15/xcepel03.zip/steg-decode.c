// steg-decode.c
// Reseni IJC-DU1, priklad b), 22. 3. 2022
// Autor: Katerina Cepelkova, FIT
// Prelozeno: gcc 11.2
//

#include "error.h"
#include "ppm.h"
#include "eratosthenes.h"
#include "bitset.h"
#include <stdio.h>
#include <stdbool.h>


int main(int argc, char *argv[])
{
    if (argc != 2)
        error_exit("steg_decode: Chybny pocet argumentu = %d.\n", argc);
    
    struct ppm *img = ppm_read(argv[1]);
    if (img == NULL) 
        error_exit("steg_decode: Chybne cteni souboru = %s.\n", argv[1]);

    bitset_alloc(bitarr, img->xsize * img->ysize * 3);
    if (bitarr == NULL)
    {
        ppm_free(img);
        error_exit("steg_decode: Chybna alokace pameti - bitarr.\n");
    }
    Eratosthenes(bitarr);

    unsigned size = bitset_size(bitarr);
    char c = 0; 
    int j = 0;
    bool escape = false;
    //Cyklus vyhleda prvocislo (pocinaje od 29), a vypise z nej LSB na pozici char c, danou pocitadlem j - kdyz j dojde na 8, c se vytiskne
    for (unsigned i = 29; i < size; i++)
    {
        if (!bitset_getbit(bitarr, i))
        {
            c |= (img->data[i] & 1) << j;
            j++;
        }

        if (j == 8)
        {
            if (c == '\0')
            {
                escape = true;
                break;
            }

            putc(c, stdout);
            c = 0;
            j = 0;
        }
    }

    if (!escape)
    {
        bitset_free(bitarr);
        ppm_free(img);
        
        error_exit("steg_decode: Chybny format souboru - zprava neni korektne ukoncena.\n");
    }

    putc('\n', stdout);
    bitset_free(bitarr);
    ppm_free(img);
    return 0;
}
