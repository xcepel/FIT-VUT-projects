// bitset.c
// Reseni IJC-DU1, priklad a), 22. 3. 2022
// Autor: Katerina Cepelkova, FIT
// Prelozeno: gcc 11.2
//


#include "bitset.h"

#ifdef USE_INLINE

extern inline void bitset_free(bitset_t jmeno_pole);

extern inline bitset_index_t bitset_size(bitset_t jmeno_pole);

extern inline int bitset_setbit(bitset_t jmeno_pole, bitset_index_t index, int vyraz);

extern inline bitset_index_t bitset_getbit(bitset_t jmeno_pole, bitset_index_t index);

#endif
