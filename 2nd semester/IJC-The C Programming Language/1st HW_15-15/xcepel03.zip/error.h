// error.h
// Reseni IJC-DU1, priklad b), 22. 3. 2022
// Autor: Katerina Cepelkova, FIT
// Prelozeno: gcc 11.2
//


#ifndef __ERROR_H__
#define __ERROR_H__

void warning_msg(const char *fmt, ...);
void error_exit(const char *fmt, ...);

#endif
