
Otevreni dokumentace (API): v adresari doc otevrete v prohlizeci soubor index.html

Kompilace s vyuzitim JUnit:
javac -cp .:junit-platform-console-standalone-1.6.0.jar ija/ija2022/homework1/Homework1Test.java 

Spusteni testu s vyuzitim JUnit:
java -cp .:junit-platform-console-standalone-1.6.0.jar org.junit.runner.JUnitCore ija.ija2022.homework1.Homework1Test
