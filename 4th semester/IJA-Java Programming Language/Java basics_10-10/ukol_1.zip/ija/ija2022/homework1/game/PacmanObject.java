// Trida pro chraktrer Pacman.
package ija.ija2022.homework1.game;

import ija.ija2022.homework1.common.Field;
import ija.ija2022.homework1.common.MazeObject;

public class PacmanObject implements MazeObject {
    Field field = null; // pozice
    public PacmanObject(Field field) { // Konstruktor
        this.field = field;
    }

    public boolean canMove(Field.Direction dir) { // Ověří, zda je možné se přesunout zadaným směrem.
        return (this.field.nextField(dir).canMove() && this.field.nextField(dir).isEmpty());
    }
    public boolean move(Field.Direction dir) { // Přesune objekt na pole v zadaném směru, pokud je to možné.
        if (this.canMove(dir)) {
            Field nextField = this.field.nextField(dir);
            this.field.remove(this);
            this.field = nextField;
            this.field.put(this);
            return true;
        }
        return false;
    }

    public String toString() { // ? TODO
        return null;
    }
}
