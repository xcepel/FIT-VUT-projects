// Třída pro sestaveni a vytvoreni mapového podkladu.
package ija.ija2022.homework1.game;

import ija.ija2022.homework1.common.Maze;
import ija.ija2022.homework1.common.Field;

public class PacmanMaze implements Maze {
    int rows;
    int cols;
    Field[][] board;

    public PacmanMaze(int rows, int cols) { // Konstruktor
        this.rows = rows + 2; // + zdi
        this.cols = cols + 2; // + zdi

        // Pridani ohraniceni
        this.board = new Field[this.rows][this.cols];
        for (int col = 0; col < this.cols; col++) {
            board[0][col] = new WallField(0,col);
            board[this.rows - 1][col] = new WallField(this.rows - 1, col);
        }
        for (int row = 1; row < this.rows - 1; row++) { // prvni i posledni radek jiz ozdovan
            board[row][0] = new WallField(row, 0);
            board[row][this.cols - 1] = new WallField( row,this.cols - 1);
        }
    }

    public static Maze create(int rows, int cols, Field[][] board) {
        PacmanMaze maze = new PacmanMaze(rows, cols);
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                maze.board[row + 1][col + 1] = board[row][col];
            }
        }

        // Svazani poli s bludistem
        for (int row = 0; row < rows + 2; row++) {
            for (int col = 0; col < cols + 2; col++) {
                maze.board[row][col].setMaze(maze);
            }
        }
        return maze;
    }

    public Field getField(int row, int col) { // Navraceni typu Field na dane pozici
        if (row < this.rows && col < this.cols)
            return this.board[row][col];
        return null;
    }

    public int numRows() { // Vrati pocet rad mapoveho pole.
        return this.rows;
    }

    public int numCols() { // Vrati pocet sloupcu mapoveho pole.
        return this.cols;
    }
}
