// Třída pro načtení mapového podkladu a vytvoření hry (bludiště).
package ija.ija2022.homework1.game;

import ija.ija2022.homework1.common.Field;
import ija.ija2022.homework1.common.Maze;

import java.util.ArrayList;

public class MazeConfigure {
    int rows = 0;
    int cols = 0;
    int read_rows = 0; // Pocitadlo prectenych radku
    MazeConfigure.State state; // Stav cteni
    ArrayList<String> map = new ArrayList<String>();

    public static enum State {
        CREATED, ERROR, FINISHED, PROCESSING
    }
    // implicitne pridano compilerem:
    // values = vrati pole obsahujici vsechny hodnoty
    // valueOf = vrati enum konstantu specifikovaneho enum typu

    public MazeConfigure() { // Konstruktor
        this.state = MazeConfigure.State.CREATED;
    }

    public void startReading(int rows, int cols) { // Zahájí čtení mapového podkladu zadaného rozměru (bez zdi).
        this.rows = rows;
        this.cols = cols;
        this.state = MazeConfigure.State.PROCESSING;
    }
    public boolean processLine(String line) { // Načte 1 řádek mapového podkladu.
        if (line.length() == cols && line.matches("^([XS.])+$") && this.read_rows <= rows && state != MazeConfigure.State.ERROR) {
            this.map.add(line);
            this.read_rows++;
            return true;
        }
        this.state = MazeConfigure.State.ERROR;
        return false;
    }

    public boolean stopReading() { // Ukončí čtení mapového podkladu.
        if (this.read_rows == this.rows && this.state != MazeConfigure.State.ERROR) {
            this.state = MazeConfigure.State.FINISHED;
            return true;
        }
        this.state = MazeConfigure.State.ERROR;
        return false;
    }

    //public static Maze createMaze()
    public Maze createMaze() { // Vytvoří bludiště podle načteného mapového podkladu.
       if (this.state != MazeConfigure.State.FINISHED) {
            return null;
       }

        Field[][] board = new Field[this.rows][this.cols];
        // Prirazovani policek podle zadani mapy
        for (int row = 0; row < this.rows; row++) {
            for (int col = 0; col < this.cols; col++) {
                if (this.map.get(row).charAt(col) == 'X')
                    board[row][col] = new WallField(row + 1, col + 1);
                else if (this.map.get(row).charAt(col) == '.')
                    board[row][col] = new PathField(row + 1, col + 1);
                else { // Pacman
                    board[row][col] = new PathField(row + 1, col + 1);
                    board[row][col].put(new PacmanObject(board[row][col]));
                }
            }
        }
        return PacmanMaze.create(this.rows, this.cols, board);
    }
}
