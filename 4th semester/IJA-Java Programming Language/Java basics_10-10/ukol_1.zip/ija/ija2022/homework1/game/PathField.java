// Třída reprezentující políčko na cestě v bludišti.
// Na políčko lze vložit objekt MazeObject.
package ija.ija2022.homework1.game;

import ija.ija2022.homework1.common.Field;
import ija.ija2022.homework1.common.Maze;
import ija.ija2022.homework1.common.MazeObject;

public class PathField implements Field {
    int col;
    int row;
    MazeObject object = null;
    Maze maze = null;

    public PathField(int row, int col) { // Konstruktor
        this.row = row;
        this.col = col;
    }

    @Override
    public void setMaze(Maze maze) { // Prirazeni policka k maze
        this.maze = maze;
    }

    @Override
    public Field nextField(Direction dirs) { // Vrati Field v danem smeru
        if (dirs == Direction.L)
            return this.maze.getField(this.row, this.col - 1);
        if (dirs == Direction.R)
            return this.maze.getField(this.row, this.col + 1);
        if (dirs == Direction.U)
            return this.maze.getField(this.row - 1, this.col);
        if (dirs == Direction.D)
            return this.maze.getField(this.row + 1, this.col);
        return null;
    }

    @Override
    public boolean put(MazeObject object) {
        if (this.canMove()) {
            this.object = object;
            return true;
        }
        return false;
    }

    @Override
    public boolean remove(MazeObject object) {
        if (this.object == object) {
            this.object = null;
            return true;
        }
        return false;
    }

    @Override
    public boolean isEmpty() { // Neni tam pacman = null
        return this.object == null;
    }

    @Override
    public MazeObject get() {
        return this.object;
    }

    @Override
    public boolean canMove() { // PacmanObject se tam muze pohnout
        return true;
    }

    public boolean equals(Object obj) { // Stejne, pokud stejny typ + stejna pozice
        if (obj instanceof PathField)
            return (this.col == ((PathField) obj).col && this.row == ((PathField) obj).row);
        return false;
    }
}
