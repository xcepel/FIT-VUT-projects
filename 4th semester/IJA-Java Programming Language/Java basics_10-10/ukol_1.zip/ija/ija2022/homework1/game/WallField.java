// Třída reprezentující zeď v bludišti.
package ija.ija2022.homework1.game;

import ija.ija2022.homework1.common.Field;
import ija.ija2022.homework1.common.Maze;
import ija.ija2022.homework1.common.MazeObject;

public class WallField implements Field {
    int row;
    int col;
    Maze maze = null;

    public WallField(int row, int col) {
        this.row = row;
        this.col = col;
    }

    @Override
    public void setMaze(Maze maze) {
        this.maze = maze;
    }

    @Override
    public Field nextField(Direction dirs) {
        throw new UnsupportedOperationException("Na policko zdi nelze vstoupit.");
    }

    @Override
    public boolean put(MazeObject object) {
        throw new UnsupportedOperationException("Na policko zdi nelze vstoupit.");
    }

    @Override
    public boolean remove(MazeObject object) {
        return false;
    }

    @Override
    public boolean isEmpty() {
        return true;
    } // Na policko nelze vstoupit.

    @Override
    public MazeObject get() {
        throw new UnsupportedOperationException("Na policko zdi nelze vstoupit.");
    }

    @Override
    public boolean canMove() { // Na policko nelze vstoupit.
        return false;
    }

    public boolean equals(Object obj) { // Stejne, pokud stejny typ + stejna pozice
        if (obj instanceof WallField)
            return (this.col == ((WallField) obj).col && this.row == ((WallField) obj).row);
        return false;
    }

}
