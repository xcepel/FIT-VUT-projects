// Trida pro chrakter Pacman
package ija.ija2022.homework2.game;

import ija.ija2022.homework2.tool.common.CommonField;
import ija.ija2022.homework2.tool.common.CommonMazeObject;
import ija.ija2022.homework2.tool.view.PacmanView;

public class PacmanObject implements CommonMazeObject {
    CommonField field;
    int lives = 3;
    PacmanView view;

    public PacmanObject(CommonField field) {
        this.field = field;
        this.view = new PacmanView(this.field.getView(), this);
    }

    // Objekt je pacman
    @Override
    public boolean isPacman() {
        return true;
    };

    // Ověří, zda je možné se přesunout zadaným směrem
    public boolean canMove(CommonField.Direction dir) {
        return this.field.nextField(dir).canMove();
    }

    // Přesune objekt na pole v zadaném směru, pokud je to možné
    public boolean move(CommonField.Direction dir) {
        if (this.canMove(dir))
            return false;

        // Pokud se potka s duchem, odebere si zivoty
        CommonField nextField = this.field.nextField(dir);
        if (!nextField.isEmpty() && nextField.get() instanceof GhostObject)
            this.removeLive();

        this.field.remove(this);
        nextField.put(this);
        this.field = nextField;

        return true;
    }

    @Override
    public CommonField getField() {
        return this.field;
    }

    @Override
    public PacmanView getView() {
        return this.view;
    }

    @Override
    public int getLives() {
        return this.lives;
    }

    public void removeLive() {
        this.lives--;
    }

    // TODO
    public String toString() {
        return "Pacman";
    }
}
