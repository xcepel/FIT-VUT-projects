// Trida prezentujici (vizualizujici) model bludiste v GUI (Swing)

package ija.ija2022.homework2.tool;

import ija.ija2022.homework2.tool.common.CommonMaze;
import ija.ija2022.homework2.tool.view.GridView;

import javax.swing.*;


public class MazePresenter {
    CommonMaze maze;
    public JFrame frame;

    public MazePresenter(CommonMaze maze) {
        this.maze = maze;
    };

    // Vytvoří a otevře GUI.
    public void open() {
        this.frame = new JFrame("PacMan");
        this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.frame.setSize(800, 600);

        GridView gridPanel = new GridView(maze, this.frame);
        this.frame.add(gridPanel);
        this.frame.setContentPane(gridPanel);

        this.frame.setLocationRelativeTo(null);
        this.frame.setVisible(true);
    };
}
