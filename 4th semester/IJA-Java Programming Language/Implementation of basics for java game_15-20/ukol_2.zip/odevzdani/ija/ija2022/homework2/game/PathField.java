// Trida reprezentujici policko na ceste v bludisti.
// Na policko lze vlozit objekt MazeObject.
package ija.ija2022.homework2.game;

import ija.ija2022.homework2.tool.common.*;
import ija.ija2022.homework2.tool.view.FieldView;

import java.util.ArrayList;
import java.util.List;

public class PathField extends AbstractObservableField implements CommonField {
    int col;
    int row;
    List<CommonMazeObject> objects = new ArrayList<>();
    CommonMaze maze = null;
    FieldView view;

    public PathField(int row, int col) {
        this.row = row;
        this.col = col;

        this.view = new FieldView(this);
        this.addObserver(this.view);
    }

    // Svazani pole s maze
    @Override
    public void setMaze(CommonMaze maze) { // Prirazeni policka k maze
        this.maze = maze;
    }

    public CommonMaze getMaze() {
        return this.maze;
    }

    // Vrati Field v danem smeru
    @Override
    public CommonField nextField(Direction dirs) {
        if (dirs == Direction.L)
            return this.maze.getField(this.row, this.col - 1);
        if (dirs == Direction.R)
            return this.maze.getField(this.row, this.col + 1);
        if (dirs == Direction.U)
            return this.maze.getField(this.row - 1, this.col);
        if (dirs == Direction.D)
            return this.maze.getField(this.row + 1, this.col);

        return null;
    }

    // Polozeni objektu na pole (pridani do seznamu objektu)
    @Override
    public boolean put(CommonMazeObject object) {
        if (this.canMove()) {
            this.objects.add(object);
            this.view.update(this);
            return true;
        }
        return false;
    }

    // Odebrani objektu z pole (odebrani ze seznamu objektu)
    @Override
    public boolean remove(CommonMazeObject object) {
        if (this.objects.contains(object)) {
            this.objects.remove(object);
            this.view.update(this);
            return true;
        }
        return false;
    }

    // Neni tam objekt = null -> je to prazdne
    @Override
    public boolean isEmpty() {
        return this.objects == null || this.objects.size() == 0;
    }

    @Override
    // Vrati prvni objekt na policku
    public CommonMazeObject get() {
        if (!this.maze.getField(this.row, this.col).isEmpty())
            return this.objects.get(0);
        return null;
    }

    // PacmanObject se muze pohnout na cestu
    @Override
    public boolean canMove() {
        return true;
    }

    @Override
    // Testuje, zda políčko obsahuje specifikovaný objekt (zda je na políčku umístěn).
    public boolean contains(CommonMazeObject obj) {
        if (this.maze.getField(this.row, this.col) != null) {
            for (CommonMazeObject object : this.objects) {
                if (object == obj)
                    return true;
            }
        }
        return false;
    }

    // Stejne, pokud stejny typ + stejna pozice
    public boolean equals(Object obj) {
        if (obj instanceof PathField)
            return (this.col == ((PathField)obj).col && this.row == ((PathField)obj).row);
        return false;
    }

    public FieldView getView() {
        return this.view;
    }

    public int getCol() {
        return this.col;
    }

    public int getRow() {
        return this.row;
    }
}
