// Trida pro nacteni mapového podkladu a vytvoreni hry (bludiste)
package ija.ija2022.homework2.game;

import ija.ija2022.homework2.tool.common.CommonField;
import ija.ija2022.homework2.tool.common.CommonMaze;

import java.util.ArrayList;

public class MazeConfigure {
    int rows = 0;
    int cols = 0;
    int read_rows = 0; // pocitadlo prectenych radku
    MazeConfigure.State state; // stav cteni
    ArrayList<String> map = new ArrayList<String>();

    public static enum State {
        CREATED, ERROR, FINISHED, PROCESSING
    }

    // Implicitne pridano compilerem:
    // values = vrati pole obsahujici vsechny hodnoty
    // valueOf = vrati enum konstantu specifikovaneho enum typu

    public MazeConfigure() {
        this.state = MazeConfigure.State.CREATED;
    }

    // Zahájí čtení mapového podkladu zadaného rozměru (bez zdi)
    public void startReading(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
        this.state = MazeConfigure.State.PROCESSING;
    }

    // Nacte 1 radek mapového podkladu
    public boolean processLine(String line) {
        if (line.length() == cols && line.matches("^([XGS.])+$") && this.read_rows <= rows && state != MazeConfigure.State.ERROR) {
            this.map.add(line);
            this.read_rows++;
            return true;
        }
        this.state = MazeConfigure.State.ERROR;
        return false;
    }

    // Ukonci cteni mapového podkladu - true/false podle toho zda je nacteno vse
    public boolean stopReading() {
        if (this.read_rows == this.rows && this.state != MazeConfigure.State.ERROR) {
            this.state = MazeConfigure.State.FINISHED;
            return true;
        }
        this.state = MazeConfigure.State.ERROR;
        return false;
    }

    // Vytvorí bludiste podle nacteného mapového podkladu
    public CommonMaze createMaze() {
       if (this.state != MazeConfigure.State.FINISHED) {
            return null;
       }

        CommonField[][] board = new CommonField[this.rows][this.cols];
        // Prirazovani policek (Field) a jejich objektu podle zadani mapy
        for (int row = 0; row < this.rows; row++) {
            for (int col = 0; col < this.cols; col++) {
                if (this.map.get(row).charAt(col) == 'X')
                    board[row][col] = new WallField(row + 1, col + 1);
                else if (this.map.get(row).charAt(col) == '.')
                    board[row][col] = new PathField(row + 1, col + 1);
                else if (this.map.get(row).charAt(col) == 'G') {
                    board[row][col] = new PathField(row + 1, col + 1);
                    board[row][col].put(new GhostObject(board[row][col]));
                    board[row][col].getView().clearChanged();
                }
                else { // Pacman
                    board[row][col] = new PathField(row + 1, col + 1);
                    board[row][col].put(new PacmanObject(board[row][col]));
                    board[row][col].getView().clearChanged();
                }
            }
        }
        return PacmanMaze.create(this.rows, this.cols, board);
    }
}
