// Trida pro chrakter Duch.
package ija.ija2022.homework2.game;

import ija.ija2022.homework2.tool.common.CommonField;
import ija.ija2022.homework2.tool.common.CommonMazeObject;
import ija.ija2022.homework2.tool.view.GhostView;

public class GhostObject implements CommonMazeObject {
    CommonField field;
    GhostView view;

    public GhostObject(CommonField field) {
        this.field = field;
        this.view = new GhostView(this.field.getView(), this);
    }

    // Ověří, zda je možné se přesunout zadaným směrem
    public boolean canMove(CommonField.Direction dir) {
        return this.field.nextField(dir).canMove();
    }

    // Přesune objekt na pole v zadaném směru, pokud je to možné
    public boolean move(CommonField.Direction dir) {
        if (!this.canMove(dir))
            return false;

        CommonField nextField = this.field.nextField(dir);
        // Odebrání životu pacmanovi při setkání s ním
        if (!nextField.isEmpty() && nextField.get().isPacman()) {
            nextField.get().removeLive();
        }

        this.field.remove(this);
        nextField.put(this);
        this.field = nextField;

        return true;
    }

    @Override
    public CommonField getField() {
        return this.field;
    }

    @Override
    public GhostView getView() {
        return this.view;
    }

    // Duch nemá životy => 0
    @Override
    public int getLives() {
        return 0;
    }

    // Duchovi nejdou odebrat životy
    @Override
    public void removeLive() {
    }

    public String toString() {
        return "Ghost";
    }
}