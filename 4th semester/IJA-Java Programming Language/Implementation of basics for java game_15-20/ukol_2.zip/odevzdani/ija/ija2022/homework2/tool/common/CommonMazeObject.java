package ija.ija2022.homework2.tool.common;

import ija.ija2022.homework2.tool.view.ComponentView;
import ija.ija2022.homework2.tool.view.FieldView;

public interface CommonMazeObject {
    boolean canMove(CommonField.Direction dir);

    boolean move(CommonField.Direction dir);

    default boolean isPacman() {
        return false;
    };

    CommonField getField();

    int getLives();

    void removeLive();

    ComponentView getView();
}
