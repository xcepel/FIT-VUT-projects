// Trida reprezentujici zed v bludisti.
// Na policko nelze vstoupit.
package ija.ija2022.homework2.game;

import ija.ija2022.homework2.tool.common.CommonField;
import ija.ija2022.homework2.tool.common.CommonMaze;
import ija.ija2022.homework2.tool.common.CommonMazeObject;
import ija.ija2022.homework2.tool.view.FieldView;

public class WallField implements CommonField {
    int row;
    int col;
    CommonMaze maze = null;
    FieldView view;


    public WallField(int row, int col) {
        this.row = row;
        this.col = col;
        this.view = new FieldView(this);
    }

    // Svazani pole s maze
    @Override
    public void setMaze(CommonMaze maze) {
        this.maze = maze;
    }

    public CommonMaze getMaze() {
        return this.maze;
    }

    @Override
    public CommonField nextField(Direction dirs) {
        throw new UnsupportedOperationException("Na policko zdi nelze vstoupit.");
    }

    @Override
    public boolean put(CommonMazeObject object) {
        throw new UnsupportedOperationException("Na policko zdi nelze vstoupit.");
    }

    @Override
    public boolean remove(CommonMazeObject object) {
        return false;
    }

    @Override
    public boolean isEmpty() {
        return true;
    }

    @Override
    public CommonMazeObject get() {
        throw new UnsupportedOperationException("Na policko zdi nelze vstoupit.");
    }

    @Override
    public boolean canMove() { // Na policko nelze vstoupit.
        return false;
    }

    @Override
    public boolean contains(CommonMazeObject obj) {
        return false;
    }

    @Override
    public FieldView getView() {
        return this.view;
    }

    // Stejne, pokud stejny typ + stejna pozice
    public boolean equals(Object obj) {
        if (obj instanceof WallField)
            return (this.col == ((WallField) obj).col && this.row == ((WallField) obj).row);
        return false;
    }

    public int getCol() {
        return this.col;
    }

    public int getRow() {
        return this.row;
    }
}
