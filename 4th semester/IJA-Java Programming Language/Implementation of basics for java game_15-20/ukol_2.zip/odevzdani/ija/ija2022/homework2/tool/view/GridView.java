// Trida reprezentujici grafickou podobu hraciho pole

package ija.ija2022.homework2.tool.view;

import ija.ija2022.homework2.tool.common.CommonField;
import ija.ija2022.homework2.tool.common.CommonMaze;

import javax.swing.*;
import java.awt.*;

public class GridView extends JPanel {
    CommonMaze grid; // pole pro ukládání typu policek

    public GridView(CommonMaze maze, JFrame frame) {
        this.grid = maze;
        maze.setFrame(frame);
    }

    @Override
    protected void paintComponent(Graphics g) {
        CommonField field;
        super.paintComponent(g);

        // Vykresleni vycentrovane mapy slozene z ctvercu
        int cellWidth = getWidth() / grid.numCols();
        int cellHeight = getHeight() / grid.numRows();
        int offsetX = 0;
        int offsetY = 0;
        if (cellWidth > cellHeight) {
            cellWidth = cellHeight;
            offsetX = (getWidth() - cellWidth * grid.numCols()) / 2;
        } else {
            cellHeight = cellWidth;
            offsetY = (getHeight() - cellHeight * grid.numRows()) / 2;
        }

        // Nastavovani offsetu vsem polickam
        for (int row = 0; row < grid.numRows(); row++) {
            for (int col = 0; col < grid.numCols(); col++) {
                field = grid.getField(row, col);
                field.getView().setSize(cellWidth, cellHeight);
                // Centrovani objektu + policka
                field.getView().setOffsetX(offsetX);
                field.getView().setOffsetY(offsetY);

                field.getView().paintComponent(g);
            }
        }
    }
}
