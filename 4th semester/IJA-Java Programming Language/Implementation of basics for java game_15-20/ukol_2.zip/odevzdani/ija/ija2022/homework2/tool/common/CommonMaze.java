package ija.ija2022.homework2.tool.common;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public interface CommonMaze {
    CommonField getField(int row, int col);

    int numRows();

    int numCols();

    List<CommonMazeObject> ghosts();

    void setFrame(JFrame frame);
    JFrame getFrame();
}
