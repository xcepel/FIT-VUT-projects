package ija.ija2022.homework2.tool.view;

import java.awt.*;

public interface ComponentView {
    void paintComponent(Graphics g);
}
