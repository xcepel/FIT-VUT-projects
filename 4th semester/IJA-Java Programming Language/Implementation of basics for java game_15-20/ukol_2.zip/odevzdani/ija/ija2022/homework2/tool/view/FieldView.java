// Trida reprezentujici grafickou podobu policka.
// Implementuje Observable.Observer, muze byt notifikovan o zmene stavu policka.
package ija.ija2022.homework2.tool.view;

import javax.swing.*;
import java.awt.*;

import ija.ija2022.homework2.game.PathField;
import ija.ija2022.homework2.game.WallField;
import ija.ija2022.homework2.tool.common.CommonField;
import ija.ija2022.homework2.tool.common.Observable;

public class FieldView extends JPanel implements Observable.Observer {
    int updates = 0;
    CommonField model;
    int offsetX = 0;
    int offsetY = 0;

    public FieldView(CommonField model) {
        this.model = model;
    }

    // Vykresli grafickou podobu policka do grafického kontextu g.
    protected void paintComponent(Graphics g) {
        if (this.model instanceof PathField) {
            g.setColor(Color.WHITE);
        } else if (this.model instanceof WallField) {
            g.setColor(Color.BLACK);
        }

        // Zobrazovani policka jako ctverec
        g.fillRect(this.model.getCol() * this.getWidth() + this.getOffsetX(),
                   this.model.getRow() * this.getHeight() + this.getOffsetY(),
                   this.getWidth(), this.getHeight());

        // Vykresleni objektu na cestu
        if (!this.model.isEmpty()) {
            this.model.get().getView().paintComponent(g);
        }
    }

    // Zpracovava notifikaci o zmene v objektu Observable.
    @Override
    public void update() {};
    public final void update(Observable field) {
        field.notifyObservers();
        if (this.model.getMaze() != null && this.model.getMaze().getFrame() != null) {
            this.model.getMaze().getFrame().repaint();
        }
        this.updates++;
    }

    // Vraci pocet notifikaci objektu z Observable.
    public int numberUpdates() {
        return this.updates;
    }

    // Vynuluje informaci o poctu notifikaci objektu z Observable.
    public void clearChanged() {
        this.updates = 0;
    }

    // Vraci objekt policka, ktere je zobrazovano timto pohledem.
    public CommonField getField() {
        return this.model;
    }

    // Metody pro udavani rozmeru:
    public int getOffsetX() {
        return this.offsetX;
    }

    public void setOffsetX(int offsetX) {
        this.offsetX = offsetX;
    }

    public int getOffsetY() {
        return this.offsetY;
    }

    public void setOffsetY(int offsetY) {
        this.offsetY = offsetY;
    }
}
