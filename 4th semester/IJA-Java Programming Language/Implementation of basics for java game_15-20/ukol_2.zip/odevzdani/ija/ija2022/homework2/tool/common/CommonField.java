package ija.ija2022.homework2.tool.common;

import ija.ija2022.homework2.tool.view.FieldView;

public interface CommonField {

    public static enum Direction {
        L, R, U, D
    };

    void setMaze(CommonMaze maze);

    CommonMaze getMaze();

    CommonField nextField(CommonField.Direction dirs);

    boolean put(CommonMazeObject object);

    boolean remove(CommonMazeObject object);

    boolean isEmpty();

    CommonMazeObject get();

    boolean canMove();

    boolean contains(CommonMazeObject obj);

    FieldView getView();

    int getCol();

    int getRow();
}
