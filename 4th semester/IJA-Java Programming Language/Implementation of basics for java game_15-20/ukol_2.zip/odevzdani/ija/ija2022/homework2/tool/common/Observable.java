package ija.ija2022.homework2.tool.common;

public interface Observable {
    void addObserver(Observable.Observer o);

    void removeObserver(Observable.Observer o);

    void notifyObservers();

    interface Observer {
        void update();
    }
}
