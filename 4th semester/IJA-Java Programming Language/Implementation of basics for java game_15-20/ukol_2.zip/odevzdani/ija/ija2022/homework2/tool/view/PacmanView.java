// Trida reprezentujici grafickou podobu pacmana.
// Pacman je zobrazen jako kolecko zelene barvy s informací o počtu životů.
package ija.ija2022.homework2.tool.view;

import ija.ija2022.homework2.tool.common.CommonMazeObject;

import java.awt.*;

public class PacmanView implements ComponentView {
    FieldView parent;
    CommonMazeObject object;

    public PacmanView(FieldView parent, CommonMazeObject m) {
        this.parent = parent;
        this.object = m;
    };

    // Vykresli grafickou podobu objektu do grafickeho kontextu g.
    public void paintComponent(Graphics g) {
        int col = this.object.getField().getCol();
        int row = this.object.getField().getRow();

        int cellWidth = this.parent.getWidth();
        int cellHeight = this.parent.getHeight();

        g.setColor(Color.GREEN);
        g.fillOval(col * cellWidth + this.parent.offsetX,
                   row * cellHeight + this.parent.offsetY, cellWidth, cellHeight);
    };
}
