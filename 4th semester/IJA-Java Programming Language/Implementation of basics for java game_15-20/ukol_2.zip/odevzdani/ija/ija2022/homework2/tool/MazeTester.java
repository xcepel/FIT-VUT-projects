// Trida overujici implementaci vzoru Observer nad bludistem.
// Simuluje objekty presenteru (view), ktere jsou schopny prijimat notifikace.
// Overuje notifikace spravnych objektu (policek) a spravny pocet notifikaci.

package ija.ija2022.homework2.tool;

import ija.ija2022.homework2.game.PathField;
import ija.ija2022.homework2.tool.common.CommonField;
import ija.ija2022.homework2.tool.common.CommonMaze;
import ija.ija2022.homework2.tool.common.CommonMazeObject;

public class MazeTester {
    CommonMaze maze;
    public MazeTester(CommonMaze maze) {
        this.maze = maze;
    };

    // Overi, že zadne policko (cesty) nebylo notifikovano
    public boolean checkEmptyNotification() {
        for (int row = 1; row < this.maze.numRows() - 1; row++) {
            for (int col = 1; col < this.maze.numCols() - 1; col++) {
                if (this.maze.getField(row, col) instanceof PathField) {
                    if (this.maze.getField(row, col).getView().numberUpdates() > 0)
                        return false;
                }
            }
        }
        return true;
    };

    // Overi spravny prubeh notifikace pri presunu objektu mezi policky - tato policka generuji notifikace o zmenach.
    // O zmene musi notifikovat policka current a previous. Overuje, zda notifikaci zaslala spravna policka ve spravnem poctu.
    // Po overeni smaze zaznamy o notifikacich (odpovida stavu zadne policko nebylo notifikovano).
    public boolean checkNotification(StringBuilder msg, CommonMazeObject obj, CommonField current, CommonField previous) {
        if (current.getView().numberUpdates() == 1 && previous.getView().numberUpdates() == 1) {
            current.getView().clearChanged();
            previous.getView().clearChanged();
            return true;
        }

        msg.append(obj.toString());
        return false;
    };
}
