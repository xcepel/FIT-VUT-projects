// Trida reprezentujici grafickou podobu ducha.
// Duch je zobrazen jako kolečko zlute barvy.

package ija.ija2022.homework2.tool.view;

import ija.ija2022.homework2.tool.common.CommonMazeObject;

import java.awt.*;

public class GhostView implements ComponentView {
    FieldView parent; // policko, na kterem se nachazi
    CommonMazeObject object; // objekt, ktery zobrazuje

    public GhostView(FieldView parent, CommonMazeObject m) {
        this.parent = parent;
        this.object = m;
    };

    // Vykresli grafickou podobu objektu do grafického kontextu g.
    public void paintComponent(Graphics g) {
        int col = this.object.getField().getCol();
        int row = this.object.getField().getRow();

        // Kopiruje velikost od rodicovskeho policka
        int cellWidth = this.parent.getWidth();
        int cellHeight = this.parent.getHeight();

        g.setColor(Color.BLUE);
        g.fillOval(col * cellWidth + this.parent.offsetX,
                   row * cellHeight + this.parent.offsetY, cellWidth, cellHeight);
    };
}
