/**
 * @file FruitView.java
 * @brief Trida reprezentujici grafickou podobu ovoce
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 1, 2023
 */

package tool.view;

import tool.common.CommonMazeObject;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

public class FruitView implements ComponentView {
    FieldView parent; // policko, na kterem se nachazi
    CommonMazeObject object; // objekt, ktery zobrazuje
    private BufferedImage image;

    /**
     * Vyvori novy graficky pohled pro ovoce
     * @param parent FieldView na kterem se ovoce zobrazuje
     * @param m CommonMazeObject = FruitObject, ktery je zobrazovan pomoci tohoto pohledu
     */
    public FruitView(FieldView parent, CommonMazeObject m) {
        this.parent = parent;
        this.object = m;
    }

    /**
     * Vykresli grafickou podobu FruitObject do grafickeho kontextu g
     * @param g <code>Graphics</code>
     */
    public void paintComponent(Graphics g) {
        // Rozmery objektu podle rozmeru pole
        int col = this.object.getField().getCol();
        int row = this.object.getField().getRow();

        // Kopiruje velikost od rodicovskeho policka
        int cellWidth = this.parent.getWidth();
        int cellHeight = this.parent.getHeight();

        try {
            image = ImageIO.read(new File("lib/pic/worm.png"));
        } catch (Exception e) {
            e.printStackTrace();
        }

        g.drawImage(image, col * cellWidth + this.parent.offsetX, row * cellHeight + this.parent.offsetY,
                cellWidth, cellHeight, null);
    }
}

