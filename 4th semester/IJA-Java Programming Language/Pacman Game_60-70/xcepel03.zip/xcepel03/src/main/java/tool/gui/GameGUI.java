/**
 * @file GameGUI.java
 * @brief Trida pro vykresleni a upravu GUI pro menu a mod hrani
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 2, 2023
 */

package tool.gui;


import func.GameFunc;
import func.ReplayFunc;
import tool.common.CommonField;
import tool.common.CommonMaze;
import tool.common.CommonMazeObject;
import tool.view.GridView;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;

public class GameGUI extends JFrame implements KeyListener, ActionListener {
    CommonMaze maze;
    String level;
    StatsGUI statsView;
    GameFunc func;
    private JPanel gameScreen;
    private JLabel scoreLabel, ipLabel;
    private CardLayout cardLayout;
    private JButton startSingleButton, startHostButton, startClientButton, quitButton, replayButton, mapsButton;

    /**
     * Zalozi nove GUI pro menu a a mod hrani
     * @param func trida resici funkcnost hranych her
     * @param level hranna mapa
     */
    public GameGUI(GameFunc func, String level) {
        super("PacMan");
        this.func = func;
        this.maze = this.func.getMaze();
        this.level = level;
        setLayout(new BorderLayout());
    }

    /**
     * Vytvori a otevre GUI
     */
    public void open() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 800);
        setFocusable(true);

        // Menu
        JPanel menuScreen = new JPanel();
        menuScreen.setLayout(new BoxLayout(menuScreen, BoxLayout.Y_AXIS));
        menuScreen.setBackground(Color.BLACK);
        menuScreen.setPreferredSize(new Dimension(1000, 770));

        // Vytvoří logo = JLabel s PNG obrázkem
        ImageIcon titleIcon = new ImageIcon("lib/pic/pacman_logo.png");
        JLabel titleLabel = new JLabel(titleIcon);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        menuScreen.add(titleLabel);
        menuScreen.add(Box.createVerticalGlue());

        try {
            Font customFont = Font.createFont(Font.TRUETYPE_FONT, new File("lib/font/RetroGaming.ttf")).deriveFont(35f);
            Font mediumFont = customFont.deriveFont(25f);

            // Zobrazovani score -> pred spustenim hry se nezobrazuje
            scoreLabel = new JLabel("");
            scoreLabel.setForeground(Color.WHITE);
            scoreLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            scoreLabel.setFont(mediumFont);

            // Tlacitka menu
            mapsButton = new JButton("Maps");
            setupButton(mapsButton, customFont);
            startSingleButton = new JButton("Single Player");
            setupButton(startSingleButton, customFont);
            replayButton = new JButton("Replay Game");
            setupButton(replayButton, customFont);
            quitButton = new JButton("Quit");
            setupButton(quitButton , customFont);

            // Cast menu pro vice hracu
            JPanel multiplayerPanel = new JPanel();
            multiplayerPanel.setLayout(new BoxLayout(multiplayerPanel, BoxLayout.X_AXIS));
            multiplayerPanel.setBackground(Color.BLACK);

            startHostButton = new JButton("Host Game");
            setupButton(startHostButton, customFont);
            startClientButton = new JButton("Join Game");
            setupButton(startClientButton, customFont);

            multiplayerPanel.add(Box.createHorizontalGlue());
            multiplayerPanel.add(startHostButton);
            multiplayerPanel.add(Box.createRigidArea(new Dimension(50, 0)));
            multiplayerPanel.add(startClientButton);
            multiplayerPanel.add(Box.createHorizontalGlue());

            menuScreen.add(Box.createVerticalGlue());
            menuScreen.add(scoreLabel);
            menuScreen.add(Box.createVerticalGlue());
            menuScreen.add(mapsButton);
            menuScreen.add(Box.createVerticalGlue());
            menuScreen.add(startSingleButton);
            menuScreen.add(Box.createVerticalGlue());
            menuScreen.add(multiplayerPanel);
            menuScreen.add(Box.createVerticalGlue());
            menuScreen.add(replayButton);
            menuScreen.add(Box.createVerticalGlue());
            menuScreen.add(quitButton);
            menuScreen.add(Box.createVerticalGlue());
            menuScreen.add(Box.createHorizontalGlue());

            // Prebarvení jednotlivých tlačítek při najetí myší
            for (JButton button : new JButton[] {startSingleButton, startHostButton, startClientButton, replayButton, quitButton, mapsButton}) {
                button.addMouseListener(new MouseAdapter() {
                    /**
                     * Nastavuje barvu tlacitka na modrou
                     * @param e akce tlacitka
                     */
                    @Override
                    public void mouseEntered(MouseEvent e) {
                        button.setForeground(Color.BLUE);
                    }
                    /**
                     * Nastavuje barvu tlacitka na bilou
                     * @param e akce tlacitka
                     */
                    @Override
                    public void mouseExited(MouseEvent e) {
                        button.setForeground(Color.WHITE);
                    }
                });
            }
        } catch (FontFormatException | IOException e) {
            System.out.println("Error loading custom font: " + e.getMessage());
        }

        // Hra
        this.gameScreen = new JPanel();

        this.cardLayout = new CardLayout();
        getContentPane().setLayout(this.cardLayout);
        getContentPane().add(menuScreen, "menu");
        getContentPane().add(this.gameScreen, "game");
        pack();

        // Zobrazi obrazovku Menu
        this.cardLayout.show(getContentPane(), "menu");
        setVisible(true);
    }

    /**
     * Po dohrani hry vraci pohled obrazovky zpet na Menu a zobrazi skore
     */
    public void backToMenu(boolean client) {
        this.cardLayout.show(getContentPane(), "menu");
        updateScoreLabel(client);
    }

    /**
     * Aktualizuje skore po kazdé odehrane hre
     */
    public void updateScoreLabel(boolean client) {
        CommonMazeObject pacman = this.maze.getPacmen().get(0);
        if (client) {
            pacman = this.maze.getPacmen().get(1);
        }
        int lives = pacman.getLives();
        int steps = pacman.getSteps();
        int fruitPicked = pacman.getFruits();

        // Rovnice na vypocet score
        int score = ((1 / steps) * 1000 + lives * 10 + fruitPicked) * 128;

        scoreLabel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.WHITE),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        if (this.func.getResult().equals("LOST")) { // Pri prohrane hre = 0
            scoreLabel.setText("You " + this.func.getResult() + " - Score: 0");
        } else {
            scoreLabel.setText("You " + this.func.getResult() + " - Score: " + score);
        }
    }

    /**
     * Aktualizuje zbyvajici zivoty a nasbirane ovoce behem hry
     */
    public void updateScore(boolean client) {
        CommonMazeObject pacman = this.maze.getPacmen().get(0);
        if (client) {
            pacman = this.maze.getPacmen().get(1);
        }
        this.statsView.getKeysLabel().setText("Picked keys: " + pacman.getKeys() + "/" + this.maze.numKeys());
        this.statsView.getLivesLabel().setText("Lives left: " + pacman.getLives());
    }

    /**
     * Aktualizace herni plochy a panelu statistik
     */
    private void updateGameScreen(boolean isServer) {
        // Vycisteni starych
        this.gameScreen.removeAll();
        this.gameScreen.setLayout(new BoxLayout(this.gameScreen, BoxLayout.Y_AXIS));

        // Aktualizace vykresleni mapy
        GridView gamePanel = new GridView(this.maze, this);
        gamePanel.setBackground(Color.BLACK);
        gamePanel.setPreferredSize(new Dimension(1000, 770));

        if (this.func.isMultiplayer()) {
            this.statsView = new StatsGUI(this.maze, "multi.txt");
        } else {
            this.statsView = new StatsGUI(this.maze, this.level);
        }
        JPanel statisticsPanel = this.statsView.create();

        this.gameScreen.add(gamePanel);
        this.gameScreen.add(statisticsPanel);
        if (isServer) {
            try {
                Font customFont = Font.createFont(Font.TRUETYPE_FONT, new File("lib/font/RetroGaming.ttf")).deriveFont(20f);

                JPanel ipAddressPanel = new JPanel();
                ipAddressPanel.setBackground(Color.BLACK);
                this.ipLabel = new JLabel("Your IP: " + this.func.getIP());
                this.ipLabel.setForeground(Color.LIGHT_GRAY);
                this.ipLabel.setFont(customFont);
                ipAddressPanel.add(ipLabel);
                this.gameScreen.add(ipAddressPanel);
            } catch (IOException | FontFormatException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Po uspesnem pripojeni prepise IP adresu na potvrzeni o spojeni
     */
    public void updateIpLabel() {
        this.ipLabel.setText("Connection established");
    }

    /**
     * Nastavi vlastnosti tlacitka a prida ho do zadaneho panelu
     * @param button nastavovane tlacitko
     * @param font vybrany font
     */
    private void setupButton(JButton button, Font font) {
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setBackground(Color.BLACK);
        button.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        button.setForeground(Color.WHITE);
        button.setFont(font);
        button.addActionListener(this);
    }

    /**
     * Pohyby pacmana (0 pro single player a server, 1 pro klienta)
     * @param event akce
     */
    @Override
    public void keyPressed(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.VK_LEFT || Character.toUpperCase(event.getKeyChar()) == 'A') {
            if (this.func.isMultiplayer() && !this.func.isServer()) {
                this.maze.getPacmen().get(1).saveLastDir(CommonField.Direction.L);
            } else {
                this.maze.getPacmen().get(0).saveLastDir(CommonField.Direction.L);
            }
        } else if (event.getKeyCode() == KeyEvent.VK_RIGHT || Character.toUpperCase(event.getKeyChar()) == 'D') {
            if (this.func.isMultiplayer() && !this.func.isServer()) {
                this.maze.getPacmen().get(1).saveLastDir(CommonField.Direction.R);
            } else {
                this.maze.getPacmen().get(0).saveLastDir(CommonField.Direction.R);
            }
        } else if (event.getKeyCode() == KeyEvent.VK_UP || Character.toUpperCase(event.getKeyChar()) == 'W') {
            if (this.func.isMultiplayer() && !this.func.isServer()) {
                this.maze.getPacmen().get(1).saveLastDir(CommonField.Direction.U);
            } else {
                this.maze.getPacmen().get(0).saveLastDir(CommonField.Direction.U);
            }
        } else if (event.getKeyCode() == KeyEvent.VK_DOWN || Character.toUpperCase(event.getKeyChar()) == 'S') {
            if (this.func.isMultiplayer() && !this.func.isServer()) {
                this.maze.getPacmen().get(1).saveLastDir(CommonField.Direction.D);
            } else {
                this.maze.getPacmen().get(0).saveLastDir(CommonField.Direction.D);
            }
        }
    }

    /**
     * Tato metoda se vola, kdyz uzivatel uvolni klavesu - nevyuzita
     * @param event akce klavesy
     */
    @Override
    public void keyReleased(KeyEvent event) {
    }

    /**
     * Tato metoda se vola, kdyz uzivatel napsal klavesu - nevyuzita
     * @param event akce klavesy
     */
    @Override
    public void keyTyped(KeyEvent event) {
    }

    /**
     * Zpracovava funkcionalitu jednotlivych tlacitek
     * @param e akce tlacitka
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == startSingleButton) {
            this.func.setMaze(this.level);
            this.maze = this.func.getMaze();
            this.func.gameState(true);

            addKeyListener(this);
            updateGameScreen(false);
            this.cardLayout.show(getContentPane(), "game");
        } else if (e.getSource() == startHostButton) {
            this.func.setMaze("multi.txt");
            this.maze = this.func.getMaze();
            this.func.setIsServer(true);
            this.func.setMultiplayer(true);
            this.func.gameState(true);

            addKeyListener(this);
            updateGameScreen(true);
            this.cardLayout.show(getContentPane(), "game");
        } else if (e.getSource() == startClientButton) {
            String userInput = JOptionPane.showInputDialog(null, "Enter host IP:");
            if (userInput != null) {
                this.func.saveHost(userInput);
                this.func.setMaze("multi.txt");
                this.maze = this.func.getMaze();
                this.func.setMultiplayer(true);
                this.func.gameState(true);

                addKeyListener(this);
                updateGameScreen(false);
                this.cardLayout.show(getContentPane(), "game");
            }
        } else if (e.getSource() == replayButton) {
            ReplayFunc replay = new ReplayFunc();
            replay.replay();
        } else if (e.getSource() == quitButton) {
            dispose();
            System.exit(0);
            // Popup menu pro mapu
        } else if (e.getSource() == mapsButton) {
            JPopupMenu mapsPopupMenu = new JPopupMenu();

            // Ziska seznam map
            File mapsFolder = new File("lib/map");
            File[] files = mapsFolder.listFiles();

            // Projde soubory a pridaje jako itemy menu
            if (files != null) {
                for (File file : files) {
                    if (file.isFile()) {
                        // Mapa pro multiplayer se nezobrazuje ve vyberu pro singleplayer
                        if (file.getName().equals("multi.txt")) {
                            continue;
                        }
                        JMenuItem menuItem = new JMenuItem(file.getName());
                        mapsPopupMenu.add(menuItem).addActionListener(e1 -> GameGUI.this.level = file.getName());
                    }
                }
            }

            // Zobrazi popup menu
            mapsPopupMenu.setBackground(Color.BLACK);
            mapsPopupMenu.show(mapsButton, mapsButton.getWidth()/4, mapsButton.getHeight());
        }
    }
}
