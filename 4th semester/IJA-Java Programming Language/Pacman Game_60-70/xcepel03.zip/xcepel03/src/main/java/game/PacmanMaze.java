/**
 * @file  PacmanMaze.java
 * @brief Trida pro sestaveni a vytvoreni mapového podkladu
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 2, 2023
 */

package game;

import game.field.WallField;
import tool.common.CommonField;
import tool.common.CommonMaze;
import tool.common.CommonMazeObject;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class PacmanMaze implements CommonMaze {
    int rows;
    int cols;
    int keysNum;
    int fruitsNum;
    JFrame frame;
    CommonField[][] board;
    private final List<CommonMazeObject> ghosts = new ArrayList<>();
    private final List<CommonMazeObject> pacmans = new ArrayList<>();

    private final List<CommonMazeObject> keys = new ArrayList<>();

    private final List<CommonMazeObject> fruits = new ArrayList<>();

    ArrayList<String> map = new ArrayList<>();

    /**
     * Vytvori ram zdi jako mapu bludiste pro nove CommmonMaze
     * @param rows rady
     * @param cols sloupce
     */
    public PacmanMaze(int rows, int cols) {
        this.rows = rows + 2; // + zdi
        this.cols = cols + 2; // + zdi

        // Pridani ohraniceni
        this.board = new CommonField[this.rows][this.cols];
        for (int col = 0; col < this.cols; col++) {
            board[0][col] = new WallField(0,col);
            board[this.rows - 1][col] = new WallField(this.rows - 1, col);
        }
        for (int row = 1; row < this.rows - 1; row++) { // prvni i posledni radek jiz ozdovan
            board[row][0] = new WallField(row, 0);
            board[row][this.cols - 1] = new WallField( row,this.cols - 1);
        }
    }

    /**
     * Vytvori ze zadanych parametru plnohodnotne bludiste
     * @param rows rady
     * @param cols sloupce
     * @param board hraci pole
     * @param keys pocet klicu
     * @param fruits pocet ovoce na mape
     * @return <code>CommonMaze</code>
     */
    public static CommonMaze create(int rows, int cols, CommonField[][] board, int keys, int fruits) {
        PacmanMaze maze = new PacmanMaze(rows, cols);
        for (int row = 0; row < rows; row++) {
            if (cols >= 0) System.arraycopy(board[row], 0, maze.board[row + 1], 1, cols);
        }

        // Svazani poli s bludistem
        for (int row = 0; row < rows + 2; row++) {
            for (int col = 0; col < cols + 2; col++) {
                maze.board[row][col].setMaze(maze);
            }
        }
        maze.keysNum = keys;
        maze.fruitsNum = fruits;
        return maze;
    }

    /**
     * Navraceni typu CommonField na dane pozici
     * @param row rada
     * @param col sloupec
     * @return <code>CommonField</code> hledane pole CommonField
     */
    public CommonField getField(int row, int col) {
        if (row < this.rows && col < this.cols)
            return this.board[row][col];

        return null;
    }

    /**
     * Vrati pocet rad mapoveho pole
     * @return <code>int</code>
     */
    public int numRows() {
        return this.rows;
    }

    /**
     * Vrati pocet sloupcu mapoveho pole
     * @return <code>int</code>
     */
    public int numCols() {
        return this.cols;
    }

    /**
     * Navraceni seznamu vsech duchu v bludisti
     * @return seznamu vsech duchu v bludisti
     */
    @Override
    public List<CommonMazeObject> getGhosts() {
        return this.ghosts;
    }

    public void setGhosts() {
        for (int row = 1; row < this.rows - 1; row++) {
            for (int col = 1; col < this.cols - 1 ; col++) {
                // true pokud na pathfield stoji objekt (zed je vzdy volna) -> vyber pouze duchu
                if (!board[row][col].isEmpty() && board[row][col].getObj("Ghost") != null) {
                    this.ghosts.add(board[row][col].getObj("Ghost"));
                }
            }
        }
    }

    public List<CommonMazeObject> getPacmen() {
        return this.pacmans;
    }

    public void setPacmen() {
        for (int row = 1; row < this.rows - 1; row++) {
            for (int col = 1; col < this.cols - 1 ; col++) {
                // true pokud na pathfield stoji objekt (zed je vzdy volna) -> vyber pouze duchu
                if (!board[row][col].isEmpty() && board[row][col].getObj("Pacman") != null) {
                    this.pacmans.add(board[row][col].getObj("Pacman"));
                }
            }
        }
    }

    /**
     * Vrati pocet klicu mapoveho pole
     * @return <code>int</code> pocet klicu mapoveho pole
     */
    public int numKeys() {
        return this.keysNum;
    } // TODO sizeof

    /**
     * Vrati seznam klicu mapoveho pole
     * @return <code>List s CommonMazeObject</code> seznam klicu mapoveho pole
     */
    public List<CommonMazeObject> getKeys() {
        return this.keys;
    }

    @Override
    public void setKeys() {
        for (int row = 1; row < this.rows - 1; row++) {
            for (int col = 1; col < this.cols - 1 ; col++) {
                if (!board[row][col].isEmpty() && board[row][col].getObj("Key") != null) {
                    this.keys.add(board[row][col].getObj("Key"));
                }
            }
        }
    }

    /**
     * Vrati pocet ovoce mapoveho pole
     * @return <code>int</code> pocet ovoce mapoveho pole
     */
    public int numFruits() {
        return this.fruitsNum;
    } // TODO sizeof

    /**
     * Vrati seznam ovoce mapoveho pole
     * @return <code>List s CommonMazeObject</code> seznam ovoce mapoveho pole
     */
    public List<CommonMazeObject> getFruits() {
        return this.fruits;
    }

    @Override
    public void setFruits() {
        for (int row = 1; row < this.rows - 1; row++) {
            for (int col = 1; col < this.cols - 1 ; col++) {
                if (!board[row][col].isEmpty() && board[row][col].getObj("Fruit") != null) {
                    this.fruits.add(board[row][col].getObj("Fruit"));
                }
            }
        }
    }

    /**
     * Nastaveni okna, ve kterem se bude mapove pole vykreslovat
     * @param frame okna, ve kterem se ma mapove pole vykreslovat
     */
    public void setFrame(JFrame frame) {
        this.frame = frame;
    }

    /**
     * Vrati okno, ve kterem se ma mapove pole vykreslovat
     * @return okno, ve kterem se ma mapove pole vykreslovat
     */
    public JFrame getFrame() {
        return this.frame;
    }

    /**
     * Ulozeni mapoveho planu mapoveho pole
     * @param map mapovy plan
     */
    public void setMap(ArrayList<String> map) {
        int rowsTXT = this.rows - 2;
        int colsTXT = this.cols - 2;
        this.map.add(rowsTXT + " " + colsTXT);
        this.map.addAll(new ArrayList<>(map));
    }

    @Override
    public String getGameProgress(boolean pickedFruit, boolean pickedKey, boolean lostLive) {
        StringBuilder gameProgress = new StringBuilder();
        for (CommonMazeObject fruit : this.fruits) {
            gameProgress.append("F,").append(fruit.getOrder()).append(",").append(fruit.getPos().get(fruit.getPos().size() - 1).toString()).append(" ");
        }
        for (CommonMazeObject ghost : this.ghosts) {
            gameProgress.append("G,").append(ghost.getOrder()).append(",").append(ghost.getPos().get(ghost.getPos().size() - 1).toString()).append(" ");
        }
        for (CommonMazeObject key : this.keys) {
            gameProgress.append("K,").append(key.getOrder()).append(",").append(key.getPos().get(key.getPos().size() - 1).toString()).append(" ");
        }
        for (CommonMazeObject pacman : this.pacmans) {
            String pickedF = "-";
            String pickedK = "-";
            String lostL = "-";
            if (pickedFruit) {
                pickedF = "+";
            }
            if (pickedKey) {
                pickedK = "+";
            }
            if (lostLive) {
                lostL = "+";
            }
            if (pacman.getOrder() == 1) {
                gameProgress.append("P,").append(pacman.getOrder()).append(",").append(pacman.getPos().get(pacman.getPos().size() - 1).toString()).append(",").append(pacman.lastDirToString()).append(",").append(pickedF).append(",").append(pickedK).append(",").append(lostL).append(" ");
            } else {
                gameProgress.append("P,").append(pacman.getOrder()).append(",").append(pacman.getPos().get(pacman.getPos().size() - 1).toString()).append(",").append(pacman.lastDirToString()).append(" ");
            }
        }
        return gameProgress.toString();
    }

    @Override
    public void changeGameProgress(String progress) {
        String[] progressList = progress.split(" ");

        for (String obj : progressList) {
            List<String> objInfo = Arrays.asList(obj.split(","));
            String type = objInfo.get(0);
            int order = Integer.parseInt(objInfo.get(1));
            int x = Integer.parseInt(objInfo.get(2));
            int y = Integer.parseInt(objInfo.get(3));

            switch (type) {
                case "F" -> // [F, order, x, y]
                        this.fruits.get(order).replace(this.getField(x, y));
                case "G" -> // [G, order, x, y]
                        this.ghosts.get(order).replace(this.getField(x, y));
                case "K" -> // [K, order, x, y]
                        this.keys.get(order).replace(this.getField(x, y));
                case "P" -> {  // [P, order, x, y, dir]
                    this.pacmans.get(order).replace(this.getField(x, y));
                    if (order == 0) {
                        this.pacmans.get(order).saveLastDir(this.pacmans.get(order).stringToDir(objInfo.get(4)));
                    } else {
                        if (Objects.equals(objInfo.get(5), "+")) {
                            this.pacmans.get(order).addFruit();
                        }
                        if (Objects.equals(objInfo.get(6), "+")) {
                            this.pacmans.get(order).addKey();
                        }
                        if (Objects.equals(objInfo.get(7), "+")) {
                            this.pacmans.get(order).removeLive();
                        }
                    }
                }
            }
        }
    }

    /**
     * Ziskani mapoveho planu
     * @return mapovy plan
     */
    public ArrayList<String> getMap() {
        return this.map;
    }
}
