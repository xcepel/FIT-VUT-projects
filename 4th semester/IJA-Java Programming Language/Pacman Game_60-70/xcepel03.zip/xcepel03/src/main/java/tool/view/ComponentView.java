/**
 * @file ComponentView.java
 * @brief Interface pro vytvoreni pohledu
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 1, 2023
 */

package tool.view;

import java.awt.*;

public interface ComponentView {
    void paintComponent(Graphics g);
}
