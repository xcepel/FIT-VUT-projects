/**
 * @file GhostView.java
 * @brief Trida reprezentujici grafickou podobu ducha.
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 1, 2023
 */

package tool.view;

import tool.common.CommonMazeObject;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Random;

public class GhostView implements ComponentView {
    FieldView parent; // policko, na kterem se nachazi
    CommonMazeObject object; // objekt, ktery zobrazuje
    private BufferedImage image;
    private final int color;

    /**
     * Vyvori novy graficky pohled pro ducha
     * @param parent FieldView na kterem se duch zobrazuje
     * @param m CommonMazeObject = GhostObject, ktery je zobrazovan pomoci tohoto pohledu
     */
    public GhostView(FieldView parent, CommonMazeObject m) {
        this.parent = parent;
        this.object = m;
        // Nahodny vyber barvy ducha
        Random rand = new Random();
        this.color = rand.nextInt(3);
    }

    /**
     * Vykresli grafickou podobu GhostObject do grafického kontextu g.
     * @param g <code>Graphics</code>
     */
    public void paintComponent(Graphics g) {
        // Rozmery objektu podle rozmeru pole
        int col = this.object.getField().getCol();
        int row = this.object.getField().getRow();

        // Kopiruje velikost od rodicovskeho policka
        int cellWidth = this.parent.getWidth();
        int cellHeight = this.parent.getHeight();

        String path = "lib/pic/squid_pink.png";
        if (this.color == 1) {
            path = "lib/pic/squid_orange.png";
        } else if (this.color == 2) {
            path = "lib/pic/squid_green.png";
        }

        try {
            image = ImageIO.read(new File(path));
        } catch (Exception e) {
            e.printStackTrace();
        }

        g.drawImage(image, col * cellWidth + this.parent.offsetX, row * cellHeight + this.parent.offsetY,
                cellWidth, cellHeight, null);
    }
}
