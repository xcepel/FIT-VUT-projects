/**
 * @file ReplayFunc.java
 * @brief Trida pro funkcnost modu prehravani
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 1, 2023
 */

package func;

import game.MazeConfigure;
import game.MazeSave;
import game.object.FruitObject;
import game.object.GhostObject;
import game.object.KeyObject;
import game.object.PacmanObject;
import tool.common.CommonField;
import tool.common.CommonMaze;
import tool.common.CommonMazeObject;
import tool.gui.ReplayGUI;
import tool.others.Pair;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class ReplayFunc {
    List<Pair<CommonMazeObject, List<Pair<Integer, Integer>>>> objsMovement;
    CommonMaze lastMaze;

    /**
     * Funkce pro prehravani posledni zahrane hry
     */
    public void replay() {
        try {
            this.lastMaze = Objects.requireNonNull(mazeLoad()).createMaze();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        ReplayGUI presenter = new ReplayGUI(this.lastMaze,this);
        presenter.open();

        MazeSave save = new MazeSave();
        try {
            save.loadFromFile();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        Map<String, List<Pair<Integer, Integer>>> objs = save.getObjsMovement();
        Set<String> keys = objs.keySet();

        this.objsMovement = new ArrayList<>();

        // Nacteni do objMovement a vytvoreni CommonMazeObject
        for (String key : keys) {
            String keyReplace = key.replaceAll("\\d", "");
            switch(keyReplace) {
                case("Pacman") -> {
                    List<Pair<Integer, Integer>> pos = objs.get(key);
                    CommonField field = this.lastMaze.getField(pos.get(0).getFirst(), pos.get(0).getSecond());
                    CommonMazeObject obj = new PacmanObject(field);
                    this.objsMovement.add(new Pair<>(obj, pos));
                    field.put(obj);
                }
                case("Ghost") -> {
                    List<Pair<Integer, Integer>> pos = objs.get(key);
                    CommonField field = this.lastMaze.getField(pos.get(0).getFirst(), pos.get(0).getSecond());
                    CommonMazeObject obj = new GhostObject(field);
                    this.objsMovement.add(new Pair<>(obj, pos));
                    field.put(obj);
                }
                case("Key") -> {
                    List<Pair<Integer, Integer>> pos = objs.get(key);
                    CommonField field = this.lastMaze.getField(pos.get(0).getFirst(), pos.get(0).getSecond());
                    CommonMazeObject obj = new KeyObject(field);
                    this.objsMovement.add(new Pair<>(obj, pos));
                    field.put(obj);
                }
                case("Fruit") -> {
                    List<Pair<Integer, Integer>> pos = objs.get(key);
                    CommonField field = this.lastMaze.getField(pos.get(0).getFirst(), pos.get(0).getSecond());
                    CommonMazeObject obj = new FruitObject(field);
                    this.objsMovement.add(new Pair<>(obj, pos));
                    field.put(obj);
                }
            }
        }
    }

    //

    /**
     * Krok - zobrazeni stavu vsech objektu v urcity okamzik
     * @param pos okamzik pro zobrazeni
     */
    public void step(int pos) {
        for (Pair<CommonMazeObject, List<Pair<Integer, Integer>>> pair : this.objsMovement) {
            if (this.objsMovement.size() != 0) {
                CommonField field = this.lastMaze.getField(pair.getSecond().get(pos).getFirst(), pair.getSecond().get(pos).getSecond());
                pair.getFirst().replace(field);
            }
        }
    }

    /**
     * Delka hry
     * @return delka hry
     */
    public int maxTime() {
        return this.objsMovement.get(0).getSecond().size() - 1;
    }

    /**
     * Nacteni, zpracovani a zalozeni bludiste
     * @return <code>MazeConfigure</code>
     * @throws IOException spatne nacteni
     */
    public static MazeConfigure mazeLoad () throws IOException {

        BufferedReader reader = new BufferedReader(new FileReader("lib/saves/savedMap.txt"));

        // Nacteni poctu sloupcu a radku
        String line = reader.readLine();
        String[] dimensions = line.split(" ");
        int numRows = Integer.parseInt(dimensions[0]);
        int numCols = Integer.parseInt(dimensions[1]);

        // Nacteni mapy
        MazeConfigure cfg = new MazeConfigure();
        cfg.startReading(numRows, numCols);
        for (int i = 0; i < numRows; i++) {
            line = reader.readLine();
            cfg.processLine(line);
        }

        if (!cfg.stopReading()) {
            // TODO ERROR
            return null;
        }

        reader.close();
        return cfg;
    }
}

