/**
 * @file KeyView.java
 * @brief Trida reprezentujici grafickou podobu klice
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 1, 2023
 */

package tool.view;

import tool.common.CommonMazeObject;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

public class KeyView implements ComponentView {
    FieldView parent; // policko, na kterem se nachazi
    CommonMazeObject object; // objekt, ktery zobrazuje
    private BufferedImage image;

    /**
     * Vyvori novy graficky pohled pro klic
     * @param parent FieldView na kterem se klic zobrazuje
     * @param m CommonMazeObject = KeyObject, ktery je zobrazovan pomoci tohoto pohledu
     */
    public KeyView(FieldView parent, CommonMazeObject m) {
        this.parent = parent;
        this.object = m;
    }

    /**
     * Vykresli grafickou podobu KeyObject do grafického kontextu g
     * @param g <code>Graphics</code>
     */
    public void paintComponent(Graphics g) {
        // Rozmery objektu podle rozmeru pole
        int col = this.object.getField().getCol();
        int row = this.object.getField().getRow();

        int cellWidth = this.parent.getWidth();
        int cellHeight = this.parent.getHeight();

        try {
            image = ImageIO.read(new File("lib/pic/star.png"));
        } catch (Exception e) {
            e.printStackTrace();
        }

        g.drawImage(image, col * cellWidth + this.parent.offsetX, row * cellHeight + this.parent.offsetY,
                cellWidth, cellHeight, null);
    }
}
