/**
 * @file ReplayGUI.java
 * @brief Trida pro vykresleni a upravu GUI pro mod prehravani
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 1, 2023
 */

package tool.gui;

import func.ReplayFunc;
import tool.common.CommonMaze;
import tool.view.GridView;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;

public class ReplayGUI extends JFrame implements ActionListener {
    int time;
    CommonMaze maze;
    ReplayFunc func;
    private JButton startButton, endButton, stepForwardButton, stepBackwardButton, walkForwardButton, walkBackwardButton;
    Font customFont;

    /**
     * Vytvoreni ReplayGUI
     * @param maze mapa
     * @param func funkcionalita
     */
    public ReplayGUI(CommonMaze maze, ReplayFunc func) {
        super("PacMan - Replay");
        setLayout(new BorderLayout());
        this.func = func;
        this.maze = maze;
    }

    /**
     * Vytvori a otevre GUI
     */
    public void open() {
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 800);
        setFocusable(true);

        // Game
        GridView gamePanel = new GridView(this.maze, this);
        //JPanel gamePanel = new JPanel();
        gamePanel.setBackground(Color.BLACK);
        gamePanel.setPreferredSize(new Dimension(1000, 700));

        try {
            this.customFont = Font.createFont(Font.TRUETYPE_FONT, new File("lib/font/RetroGaming.ttf")).deriveFont(20f);

            JPanel topButtonPanel = new JPanel(new GridLayout(1, 2));
            startButton = new JButton("Start");
            setupButton(startButton, topButtonPanel);
            endButton = new JButton("End");
            setupButton(endButton, topButtonPanel);

            JPanel bottomButtonPanel = new JPanel(new GridLayout(1, 4));
            stepForwardButton = new JButton("Step Forward");
            setupButton(stepForwardButton, bottomButtonPanel);
            stepBackwardButton = new JButton("Step Backward");
            setupButton(stepBackwardButton, bottomButtonPanel);
            walkForwardButton = new JButton("Walk Forward");
            setupButton(walkForwardButton, bottomButtonPanel);
            walkBackwardButton = new JButton("Walk Backward");
            setupButton(walkBackwardButton, bottomButtonPanel);

            JPanel buttonPanel = new JPanel(new GridLayout(2, 1));
            buttonPanel.setPreferredSize(new Dimension(1000, 100));
            buttonPanel.add(topButtonPanel);
            buttonPanel.add(bottomButtonPanel);

            JPanel gameScreen = new JPanel();
            gameScreen.setLayout(new BoxLayout(gameScreen, BoxLayout.Y_AXIS));
            gameScreen.add(gamePanel);
            gameScreen.add(buttonPanel);

            add(gameScreen);
            setVisible(true);

            addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent e) {
                    dispose();
                }
            });
        } catch (FontFormatException | IOException e) {
            System.out.println("Error loading custom font: " + e.getMessage());
        }
    }

    /**
     * Nastavi vlastnosti tlacitka a prida ho do zadaneho JPanel
     * @param button nastavovane tlacitko
     * @param panel umisteni tlacitka
     */
    private void setupButton(JButton button, JPanel panel) {
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setBackground(Color.BLACK);
        button.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        button.setForeground(Color.WHITE);
        button.setFont(this.customFont);
        button.addActionListener(this);
        panel.add(button);
    }

    /**
     * Zpracovava funkcionalitu jednotlivych tlacitek
     * @param e akce tlacitka
     */
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == startButton) {
            this.time = 0;
            this.func.step(this.time);
        } else if (e.getSource() == endButton) {
            this.time = func.maxTime();
            this.func.step(this.time);
        } else if (e.getSource() == stepForwardButton) {
            if (this.time < func.maxTime()) {
                this.time++;
                this.func.step(this.time);
            }
        } else if (e.getSource() == stepBackwardButton) {
            if (this.time > 0) {
                this.time--;
                this.func.step(this.time);
            }
        } else if (e.getSource() == walkForwardButton) {
            //TODO
            System.out.println("walkForwardButton");
        } else if (e.getSource() == walkBackwardButton) {
            //TODO
            System.out.println("walkBackwardButton");
        }
    }
}
