/**
 * @file Observable.java
 * @brief Interface pro Observable
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 1, 2023
 */

package tool.common;

public interface Observable {
    void addObserver(Observable.Observer o);

    void removeObserver(Observable.Observer o);

    void notifyObservers();

    interface Observer {
        void update();
    }
}
