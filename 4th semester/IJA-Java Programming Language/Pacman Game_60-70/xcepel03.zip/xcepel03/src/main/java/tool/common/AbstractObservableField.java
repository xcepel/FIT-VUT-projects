/**
 * @file AbstractObservableField.java
 * @brief Abstraktni trida implementujici operace rozhrani Observable.
 * Umoznuje vkladat a rusit observery a notifikovat registrovane observery o zmenach.
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 1, 2023
 */

package tool.common;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractObservableField implements CommonField, Observable {
    List<Observer> observers = new ArrayList<>();

    public AbstractObservableField() {}

    // Registruje novy observer
    public void addObserver(Observable.Observer o){
        this.observers.add(o);
    }

    // Odregistruje observer
    public void removeObserver(Observable.Observer o){
        this.observers.remove(o);
    }

    // Notifikuje (informuje) registrovane observery, že doslo ke zmene stavu objektu
    public void notifyObservers(){
        for (Observer observer : this.observers) {
            observer.update();
        }
    }
}
