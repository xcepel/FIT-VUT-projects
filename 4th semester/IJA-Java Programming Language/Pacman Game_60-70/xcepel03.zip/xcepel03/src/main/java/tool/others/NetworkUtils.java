/**
 * @file NetworkUtils.java
 * @brief Util trida pro odesilani/prijimani zprav mezi serverem a klientem
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 2, 2023
 */

package tool.others;

import java.io.IOException;
import java.net.*;

public class NetworkUtils {

    /**
     * Vytvoreni server socketu
     * @return server socket
     */
    public static DatagramSocket createServerSocket() {
        try {
            return new DatagramSocket(4242);
        } catch (SocketException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Vytvoreni klient socketu
     * @return klient socket
     */
    public static DatagramSocket createClientSocket () {
        try {
            return new DatagramSocket();
        } catch (SocketException e) {
            throw new RuntimeException(e);
        }
    }


    /**
     * Zaslani zpravy klientovi od serveru
     * @param serverSocket odesilatel
     * @param clientAddress prijemce
     * @param clientPort prijemcuv port
     * @param message zprava
     */
    public static void sendDataServer (DatagramSocket serverSocket, InetAddress clientAddress, int clientPort,
                                       String message) {
        byte[] sendData = message.getBytes();
        DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, clientAddress, clientPort);
        try {
            serverSocket.send(sendPacket);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Prijeti zpravy od klienta
     * @param serverSocket prijemce
     * @return <code>Pair<</code>ziskana zprava, client packet<code>></code>
     */
    public static Pair<String, DatagramPacket> receiveDataServer (DatagramSocket serverSocket) {
        byte[] receiveData = new byte[1024];
        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
        try {
            serverSocket.receive(receivePacket);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return new Pair<>(new String(receivePacket.getData(), 0, receivePacket.getLength()), receivePacket);
    }

    /**
     * Zaslani zpravy serveru od klienta
     * @param clientSocket odesilatel
     * @param serverIP prijemce (IP adresa serveru)
     * @param message zprava
     */
    public static void sendDataClient (DatagramSocket clientSocket, String serverIP, String message) {
        byte[] sendData = message.getBytes();
        InetAddress serverAddress;
        try {
            // Ziskani adresy serveru
            serverAddress = InetAddress.getByName(serverIP);
        } catch (UnknownHostException e) {
            throw new RuntimeException(e);
        }
        DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverAddress, 4242);
        try {
            clientSocket.send(sendPacket);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Prijeti zpravy od serveru
     * @param clientSocket prijemce
     * @return prijata zprava
     */
    public static String receiveDataClient (DatagramSocket clientSocket) {
        byte[] receiveData = new byte[1024];
        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
        try {
            clientSocket.receive(receivePacket);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return new String(receivePacket.getData(), 0, receivePacket.getLength());
    }
}
