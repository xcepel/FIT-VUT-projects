/**
 * @file StatsGUI.java
 * @brief Trida pro vytvoreni a upravu panelu statistik ve hre
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 1, 2023
 */

package tool.gui;

import tool.common.CommonMaze;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;

public class StatsGUI {
    CommonMaze maze;
    String level;
    JPanel statisticsPanel;
    JLabel keysLabel, levelLabel, livesLabel;

    /**
     * Zalozi novy panel statistik a priradi k nemu potrebne hodnoty
     * @param maze bludiste hrane hry
     * @param level jmeno aktualniho bludiste
     */
    public StatsGUI(CommonMaze maze, String level) {
        this.maze = maze;
        this.level = level;
    }

    /**
     * Vytvori panel statistika
     * @return <code>JPanel</code> panel statistika
     */
    public JPanel create() {
        this.statisticsPanel = new JPanel();
        this.statisticsPanel.setBackground(Color.BLACK);

        this.keysLabel = labelCreate("Picked keys: " + "0/" + this.maze.numKeys());
        this.keysLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 50));
        this.levelLabel = labelCreate("LEVEL: " + level);
        this.levelLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 50));
        this.livesLabel = labelCreate("Lives left: 3");

        this.statisticsPanel.add(this.keysLabel);
        this.statisticsPanel.add(levelLabel);
        this.statisticsPanel.add(this.livesLabel);
        this.statisticsPanel.setPreferredSize(new Dimension(1000, 50));

        return this.statisticsPanel;
    }

    /**
     * Vytvori popisky na herni plose, zmena fontu
     * @return <code>JLabel</code> vytvoreny popisek
     */
    public JLabel labelCreate(String string) {
        Font font = null;
        try {
            font = Font.createFont(Font.TRUETYPE_FONT, new File("lib/font/RetroGaming.ttf"));
            font = font.deriveFont(Font.PLAIN, 30);
        } catch (IOException | FontFormatException e) {
            e.printStackTrace();
        }
        JLabel label = new JLabel(string);
        label.setFont(font);
        label.setForeground(Color.LIGHT_GRAY);
        return label;
    }

    /**
     * Ziskani popisku klicu
     * @return <code>JLabel</code> popisek klicu
     */
    public JLabel getKeysLabel() {
        return this.keysLabel;
    }

    /**
     * Ziskani popisku zivotu
     * @return <code>JLabel</code> popisek zivotu
     */
    public JLabel getLivesLabel() {
        return this.livesLabel;
    }
}
