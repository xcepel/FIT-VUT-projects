/**
 * @file GhostObject.java
 * @brief Trida pro charakter Ghost
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 1, 2023
 */

package game.object;

import tool.common.CommonField;
import tool.common.CommonMazeObject;
import tool.others.Pair;
import tool.view.GhostView;

import java.util.ArrayList;
import java.util.List;

public class GhostObject implements CommonMazeObject {
    CommonField field;
    GhostView view;

    CommonField.Direction lastDir = null;

    List<Pair<Integer, Integer>> positions = new ArrayList<>();

    int order = 0;

    /**
     * Vytvori GhostObject a priradi mu pole, na kterem stoji a pohled GhostView
     * @param field <code>CommonField<code/> na kterem ma stat
     */
    public GhostObject(CommonField field) {
        this.field = field;
        this.view = new GhostView(this.field.getView(), this);
    }


    /**
     * Ověří, zda je možné se přesunout zadaným směrem
     * @param dir smer pohybu
     * @return true = na vedlejsi pole v danem smeru se muze pohnout
     */
    @Override
    public boolean canMove(CommonField.Direction dir) {
        return this.field.nextField(dir).canMove();
    }

    /**
     * Přesune objekt na pole v zadaném směru, pokud je to možné
     * @param dir smer pohybu
     * @return true = uspesny pohyb zadanym smerem
     */
    @Override
    public boolean move(CommonField.Direction dir) {
        if (dir == null || !this.canMove(dir))
            return false;

        CommonField nextField = this.field.nextField(dir);
        // Odebrání životu pacmanovi při setkání s ním
        if (!nextField.isEmpty() && nextField.getObj("Pacman") != null) {
            nextField.getObj("Pacman").removeLive();
        }

        this.field.remove(this);
        nextField.put(this);
        this.field = nextField;

        return true;
    }

    /**
     * Presun objektu na jine pole CommonField
     * @param newField pole presunu z aktualniho
     */
    @Override
    public void replace(CommonField newField) {
        this.field.remove(this);
        newField.put(this);
        this.field = newField;
    }

    /**
     * Ziskani pole, na kterem se objekt nachazi
     * @return pole, na kterem se objekt nachazi
     */
    @Override
    public CommonField getField() {
        return this.field;
    }

    /**
     * Ziskani pohledu, ktery Ghosta vykresluje
     * @return pohled, ktery Ghosta vykresluje
     */
    @Override
    public GhostView getView() {
        return this.view;
    }

    /**
     * Ulozeni aktualni pozice objektu
     * @param x rada
     * @param y sloupec
     */
    @Override
    public void savePos(int x, int y) {
        this.positions.add(new Pair<>(x, y));
    }

    /**
     * Vrati seznam vsech pozic, na kterych se objekt za hru nachazel v sestupnem poradi
     * @return pozice objektu, od zacatku hry az do zavolani funkce
     */
    @Override
    public List<Pair<Integer, Integer>> getPos() {
        return this.positions;
    }

    /**
     * Nastaveni poradi objektu
     * @param order <code>int</code> poradi objektu
     */
    @Override
    public void setOrder(int order) {
        this.order = order;
    }

    /**
     * Vrati poradi objektu
     * @return <code>int</code> poradi objektu
     */
    @Override
    public int getOrder() {
        return this.order;
    }

    /**
     * Prevedeni stringu na CommonField.Direction - Duch se nepohybuje
     * @param direction smer
     * @return null
     */
    @Override
    public CommonField.Direction stringToDir(String direction) {
        return null;
    }

    /**
     * Prevedeni CommonField.Direction na string - Duch nema smer
     * @return null
     */
    @Override
    public String lastDirToString() {
        return null;
    }

    /**
     * Pricteni fruit - Duch nesbira ovoce
     */
    @Override
    public void addFruit() {}

    /**
     * Pricteni key - Duch nesbira klic
     */
    @Override
    public void addKey() {}

    /**
     * Vrati pocet zivotu Ghosta
     * @return 0 -> Ghost nema zivoty
     */
    @Override
    public int getLives() {
        return 0;
    }

    /**
     * Vrati pocet kroku Ducha
     * @return 0 -> duchovi se nepocitaji zivoty
     */
    @Override
    public int getSteps() {
        return 0;
    }

    /**
     * Duchovi nelze odebrat zivoty
     */
    @Override
    public void removeLive() {
    }

    /**
     * Ducha nelze sebrat
     * @return false
     */
    @Override
    public boolean remove() {
        return false;
    }

    /**
     * Vrati pocet nasbiranych klicu Ghosta
     * @return 0 -> Ghost nesbira klice
     */
    @Override
    public int getKeys() {
        return 0;
    }

    /**
     * Vrati pocet nasbiraneho ovoce Ghosta
     * @return 0 -> Ghost nesbira ovoce
     */
    @Override
    public int getFruits() {
        return 0;
    }

    /**
     * Ulozi smer, kterym se chce objekt vydat
     * @param dir smer, kterym se chce objekt vydat
     */
    @Override
    public void saveLastDir(CommonField.Direction dir) {
        this.lastDir = dir;
    }

    /**
     * Vrati smer, kterym se objekt naposledy pohnul
     * @return smer, kterym se objekt naposledy pohnul
     */
    @Override
    public CommonField.Direction getLastDir() {
        return this.lastDir;
    }

    /**
     * Prevedeni na string
     * @return "Ghost"
     */
    public String toString() {
        return "Ghost";
    }
}
