/**
 * @file  MazeSave.java
 * @brief Trida pro spravu a ukladani odehrane hry
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 1, 2023
 */

package game;

import tool.common.CommonMazeObject;
import tool.others.Pair;

import java.io.*;
import java.util.*;

public class MazeSave {
    ArrayList<String> map = new ArrayList<>();
    Map<String, List<Pair<Integer, Integer>>> objsMovement = new HashMap<>();

    public MazeSave(){}

    /**
     * Nacteni vysledku odehrane hry z hry
     * @param allObjs <code>List s CommonMazeObject</code> se vsemi objekty ve hre
     * @param map <code>ArrayList<String></code> mapa, na ktere se hra odehravala
     */
    public void loadToSave(List<CommonMazeObject> allObjs, ArrayList<String> map) {
        // Zredukovani mapy pouze na zdi a cesty
        for (String line : map) {
            line.replaceAll("[SGKF]", ".");
        }
        this.map = map;

        // Prirazovani listu s pohyby k objektum
        List<Pair<Integer, Integer>> movement  = new ArrayList<>();
        int objCnt = 0;
        for (CommonMazeObject object:allObjs) {
            movement.clear();
            movement.addAll(object.getPos());
            this.objsMovement.put(object.toString() + objCnt, new ArrayList<>(movement));
            objCnt++;
        }
        try {
            loadToFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Prepsani vysledku hry z promenych do souboru
     * @throws IOException spatna prace se souborem
     */
    public void loadToFile() throws IOException {
        File fileObjs = new File("lib/saves/savedObjs.txt");
        FileWriter fwObjs = new FileWriter(fileObjs);
        BufferedWriter bwObjs = new BufferedWriter(fwObjs);

        // Ulozeni pozic vsech objektu ve formatu: Objekt[cislo]\n seznam pozic
        Set<String> keys = this.objsMovement.keySet();
        for (String key : keys) {
            bwObjs.write(key);
            bwObjs.newLine();
            bwObjs.write(this.objsMovement.get(key).toString());
            bwObjs.newLine();
        }

        // Ulozeni odehrane mapy
        File fileMap = new File("lib/saves/savedMap.txt");
        FileWriter fwMap = new FileWriter(fileMap);
        BufferedWriter bwMap = new BufferedWriter(fwMap);
        for (String line : this.map) {
            line = line.replaceAll("[SGKF]", ".");
            bwMap.write(line);
            bwMap.newLine();
        }

        bwMap.close();
        fwMap.close();
        bwObjs.close();
        fwObjs.close();
    }

    /**
     * Nacteni historie pohybu a mapy posledni hry ze souboru
     * @throws IOException spatna prace se souborem
     */
    public void loadFromFile() throws IOException {
        FileReader frObjs = new FileReader("lib/saves/savedObjs.txt");
        BufferedReader brObjs = new BufferedReader(frObjs);
        String obj;
        String value;
        List<Pair<Integer, Integer>> pairs = new ArrayList<>();

        while ((obj = brObjs.readLine()) != null) {
            value = brObjs.readLine();
            value = value.replace("[", "").replace("]", "").replace(" ", "");
            String[] values = value.split(",");
            for (int i = 0; i < values.length; i += 2) {
                pairs.add(new Pair<>(Integer.valueOf(values[i]), Integer.valueOf(values[i + 1])));
            }
            this.objsMovement.put(obj, new ArrayList<>(pairs));
            pairs.clear();
        }

        FileReader frMap = new FileReader("lib/saves/savedMap.txt");
        BufferedReader brMap = new BufferedReader(frMap);

        String line;
        while ((line = brMap.readLine()) != null) {
            line = line.replaceAll("[SGKF]", ".");
            this.map.add(line);
        }

        brObjs.close();
        frObjs.close();

        brMap.close();
        frMap.close();
    }

    /**
     * Vrati list s informacemi o objektech a jejich pohybech
     * @return Map<String, List<Pair<Integer, Integer>>>
     */
    public Map<String, List<Pair<Integer, Integer>>> getObjsMovement() {
        return this.objsMovement;
    }
}
