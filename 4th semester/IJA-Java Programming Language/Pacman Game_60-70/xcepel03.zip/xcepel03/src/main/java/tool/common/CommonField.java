/**
 * @file CommonField.java
 * @brief Interface pro CommonField
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 1, 2023
 */

package tool.common;

import tool.view.FieldView;

import java.util.List;

public interface CommonField {

    enum Direction {
        L, R, U, D
    }

    void setMaze(CommonMaze maze);

    CommonMaze getMaze();

    CommonField nextField(CommonField.Direction dirs);

    boolean put(CommonMazeObject object);

    boolean remove(CommonMazeObject object);

    boolean isEmpty();

    boolean canMove();

    CommonMazeObject getObj(String obj_type);

    List<CommonMazeObject> getObjs();

    FieldView getView();

    int getCol();

    int getRow();
}
