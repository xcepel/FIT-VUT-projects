/**
 * @file Pair.java
 * @brief Trida pro vytvoreni pair
 * = drzi 2 hodnoty urciteho typu
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 1, 2023
 */

package tool.others;


public class Pair<T, U> {
    private final T x;
    private final U y;

    /**
     * Vytvoreni paru
     * @param x prvni hodnota
     * @param y druha hodnota
     */
    public Pair(T x, U y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Navraceni prvni hodnoty paru
     * @return prvni hodnota paru
     */
    public T getFirst() {
        return x;
    }

    /**
     * Navraceni druhe hodnoty
     * @return druha hodnota paru
     */
    public U getSecond() {
        return y;
    }

    /**
     * Navraceni paru jako Stringu pro tisk
     * @return <code>String</code>
     */
    @Override
    public String toString() {
        return x + "," + y;
    }
}
