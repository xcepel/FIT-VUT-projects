/**
 * @file CommonMazeObject.java
 * @brief Interface pro CommonMazeObject
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 1, 2023
 */

package tool.common;

import tool.others.Pair;
import tool.view.ComponentView;

import java.util.List;

public interface CommonMazeObject {

    boolean canMove(CommonField.Direction dir);

    boolean move(CommonField.Direction dir);

    void replace(CommonField newField);

    default boolean isPacman() {
        return false;
    }

    CommonField getField();

    int getLives();

    int getSteps();

    void removeLive();

    boolean remove();

    int getKeys();

    int getFruits();

    void saveLastDir(CommonField.Direction dir);

    CommonField.Direction getLastDir();

    ComponentView getView();

    void savePos(int x, int y);

    List<Pair<Integer, Integer>> getPos();

    void setOrder(int order);

    int getOrder();

    CommonField.Direction stringToDir(String direction);

    String lastDirToString();

    void addFruit();

    void addKey();
}
