/**
 * @file PacmanObject.java
 * @brief Trida pro charakter Pacman
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 2, 2023
 */

package game.object;


import tool.common.CommonField;
import tool.common.CommonMazeObject;
import tool.others.Pair;
import tool.view.PacmanView;

import java.util.ArrayList;
import java.util.List;

public class PacmanObject implements CommonMazeObject {
    CommonField field;
    int lives = 3;
    int keys = 0;
    int fruits = 0;
    int steps = 0;
    PacmanView view;
    CommonField.Direction Dir = null;
    List<Pair<Integer, Integer>> positions = new ArrayList<>();
    int order = 0;

    /**
     * Vytvori PacmanObject a priradi mu pole, na kterem stoji a pohled PacmanView
     * @param field <code>CommonField<code/> na kterem ma stat
     */
    public PacmanObject(CommonField field) {
        this.field = field;
        this.view = new PacmanView(this.field.getView(), this);
    }

    /**
     * Objekt je pacman
     * @return true
     */
    @Override
    public boolean isPacman() {
        return true;
    }

    /**
     * Ověří, zda je možné se přesunout zadaným směrem
     * @param dir smer pohybu
     * @return true = na vedlejsi pole v danem smeru se muze pohnout
     */
    @Override
    public boolean canMove(CommonField.Direction dir) {
        return this.field.nextField(dir).canMove();
    }

    /**
     * Přesune objekt na pole v zadaném směru, pokud je to možné
     * @param dir smer pohybu
     * @return true = uspesny pohyb zadanym smerem
     */
    @Override
    public boolean move(CommonField.Direction dir) {
        this.steps++;
        if (!this.canMove(dir))
            return false;

        // Pokud se potka s duchem, odebere si zivoty
        CommonField nextField = this.field.nextField(dir);
        if (!nextField.isEmpty() && nextField.getObj("Ghost") != null)
            this.removeLive();

        // Sebrani klice
        if (!nextField.isEmpty() && nextField.getObj("Key") != null) {
            nextField.getObj("Key").removeLive();
            nextField.getObj("Key").remove();
            this.addKey();
            // Sebrani ovoce
        } else if (!nextField.isEmpty() && nextField.getObj("Fruit") != null) {
            nextField.getObj("Fruit").removeLive();
            nextField.getObj("Fruit").remove();
            this.addFruit();
        }

        this.field.remove(this);
        nextField.put(this);
        this.field = nextField;

        return true;
    }

    /**
     * Presun objektu na jine pole CommonField
     * @param newField pole presunu z aktualniho
     */
    @Override
    public void replace(CommonField newField) {
        this.field.remove(this);
        newField.put(this);
        this.field = newField;
        this.steps++;
    }

    /**
     * Ziskani pole, na kterem se objekt nachazi
     * @return pole, na kterem se objekt nachazi
     */
    @Override
    public CommonField getField() {
        return this.field;
    }

    /**
     * Ziskani pohledu, ktery Pacmana vykresluje
     * @return pohled, ktery Pacmana vykresluje
     */
    @Override
    public PacmanView getView() {
        return this.view;
    }

    /**
     * Ulozeni aktualni pozice objektu
     * @param x rada
     * @param y sloupec
     */
    @Override
    public void savePos(int x, int y) {
        this.positions.add(new Pair<>(x, y));
    }

    /**
     * Vrati seznam vsech pozic, na kterych se objekt za hru nachazel v sestupnem poradi
     * @return pozice objektu, od zacatku hry az do zavolani funkce
     */
    @Override
    public List<Pair<Integer, Integer>> getPos() {
        return this.positions;
    }

    /**
     * Nastaveni poradi objektu
     * @param order <code>int</code> poradi objektu
     */
    @Override
    public void setOrder(int order) {
        this.order = order;
    }

    /**
     * Vrati poradi objektu
     * @return <code>int</code> poradi objektu
     */
    @Override
    public int getOrder() {
        return this.order;
    }

    /**
     * Prevedeni stringu na CommonField.Direction
     * @param direction smer
     * @return null
     */
    @Override
    public CommonField.Direction stringToDir(String direction) {
        return switch (direction) {
            case "U" -> CommonField.Direction.U;
            case "R" -> CommonField.Direction.R;
            case "D" -> CommonField.Direction.D;
            case "L" -> CommonField.Direction.L;
            default -> this.getLastDir();
        };
    }

    /**
     * Prevedeni CommonField.Direction na string - Key se nepohybuje
     * @return null
     */
    @Override
    public String lastDirToString() {
        if (this.getLastDir() == CommonField.Direction.U) {
            return "U";
        } else if (this.getLastDir() == CommonField.Direction.R) {
            return "R";
        } else if (this.getLastDir() == CommonField.Direction.D) {
            return "D";
        } else if (this.getLastDir() == CommonField.Direction.L) {
            return "L";
        }
        return null;
    }

    /**
     * Vrati pocet zivotu Pacmana
     * @return pocet zivotu Pacmana
     */
    @Override
    public int getLives() {
        return this.lives;
    }

    /**
     * Vrati pocet kroku Pacmana
     * @return pocet kroku Pacmana
     */
    @Override
    public int getSteps() {
        return this.steps;
    }

    /**
     * Vrati pocet nasbiranych klicu Pacmana
     * @return pocet nasbiranych klicu
     */
    @Override
    public int getKeys() {
        return this.keys;
    }

    /**
     * Vrati pocet nasbiraneho ovoce Pacmana
     * @return pocet nasbiraneho ovoce
     */
    @Override
    public int getFruits() {
        return this.fruits;
    }

    /**
     * Ulozi smer, kterym se chce objekt vydat
     * @param dir smer, kterym se chce objekt vydat
     */
    @Override
    public void saveLastDir(CommonField.Direction dir) {
        this.Dir = dir;
    }

    /**
     * Vrati smer, kterym se objekt naposledy pohnul
     * @return smer, kterym se objekt naposledy pohnul
     */
    @Override
    public CommonField.Direction getLastDir() {
        return this.Dir;
    }

    /**
     * Odecte Pacmanovi 1 zivot
     */
    @Override
    public void removeLive() {
        this.lives--;
    }

    /**
     * Pacman nelze odebrat z mapy
     * @return false
     */
    @Override
    public boolean remove() {
        return false;
    }

    /**
     * Prevedeni na string
     * @return "Pacman"
     */
    @Override
    public String toString() {
        return "Pacman";
    }


    /**
     * Pricteni fruit
     */
    public void addFruit() {
        this.fruits++;
    }


    /**
     * Pricteni key
     */
    public void addKey() {
        this.keys++;
    }
}
