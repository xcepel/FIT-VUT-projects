/**
 * @file PacmanView.java
 * @brief Trida reprezentujici grafickou podobu pacmana
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 1, 2023
 */

package tool.view;

import tool.common.CommonField;
import tool.common.CommonMazeObject;

import java.awt.*;
import java.io.File;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

public class PacmanView implements ComponentView {
    FieldView parent; // policko, na kterem se nachazi
    CommonMazeObject object;  // objekt, ktery zobrazuje
    private BufferedImage image;

    /**
     * Vyvori novy graficky pohled pro pacmana
     * @param parent FieldView na kterem se pacman zobrazuje
     * @param m CommonMazeObject = PacmanObject, ktery je zobrazovan pomoci tohoto pohledu
     */
    public PacmanView(FieldView parent, CommonMazeObject m) {
        this.parent = parent;
        this.object = m;
    }

    /**
     * Vykresli grafickou podobu PacmanObject do grafickeho kontextu g
     * @param g <code>Graphics</code>
     */
    public void paintComponent(Graphics g) {
        // Rozmery objektu podle rozmeru pole
        int col = this.object.getField().getCol();
        int row = this.object.getField().getRow();

        int cellWidth = this.parent.getWidth();
        int cellHeight = this.parent.getHeight();

        // Rozliseni barvy pacmana pro vice hracu
        String picture = "pacman";
        if (this.object.getOrder() != 0) {
            picture = "nemo";
        }
        // Vyber smeru pohledu pacmana
        CommonField.Direction dir = this.object.getLastDir();
        String path = "lib/pic/" + picture + "_R.png";
        if (dir == CommonField.Direction.D) {
            path = "lib/pic/" + picture + "_D.png";
        } else if (dir == CommonField.Direction.U) {
            path = "lib/pic/" + picture + "_U.png";
        } else if (dir == CommonField.Direction.L) {
            path = "lib/pic/" + picture + "_L.png";
        }

        try {
            image = ImageIO.read(new File(path));
        } catch (Exception e) {
            e.printStackTrace();
        }

        g.drawImage(image, col * cellWidth + this.parent.offsetX, row * cellHeight + this.parent.offsetY,
                cellWidth, cellHeight, null);
    }
}
