/**
 * @file GameFunc.java
 * @brief Trida pro funkcnost modu hrani a prepinani mezi nim
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 2, 2023
 */

package func;

import com.sun.tools.javac.Main;
import game.MazeConfigure;
import game.MazeSave;
import game.field.TargetField;
import tool.common.CommonField;
import tool.common.CommonMaze;
import tool.common.CommonMazeObject;
import tool.gui.GameGUI;
import tool.others.NetworkUtils;
import tool.others.Pair;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GameFunc {
    boolean gameState = false;
    boolean isServer = false;
    boolean multiplayer = false;
    CommonMaze maze;
    private String map, host, result;
    GameGUI presenter;

    InetAddress ip;

    /**
     * Metoda ridici vyber modu hrani a prechod z/do menu
     */
    public void setup() {
        this.presenter = new GameGUI(this, this.map);
        this.presenter.open();

        // Ziskani vlastni IP adresy
        try {
            this.ip = InetAddress.getLocalHost();
        } catch (UnknownHostException e) {
            System.out.println("Error getting IP address: " + e.getMessage());
        }

        while (true) {
            // Cekani na spusteni modu hrani
            while (!this.gameState) {
                sleep(1);
            }

            if (this.multiplayer) {
                if (this.isServer) {
                    playServer();
                    this.presenter.backToMenu(false);
                } else {
                    playClient();
                    this.presenter.backToMenu(true);
                }
            } else {
                playSingle();
                this.presenter.backToMenu(false);
            }
            // Prechod zpatky do menu
            setMultiplayer(false);
            setIsServer(false);
            this.presenter.removeKeyListener(this.presenter);
        }
    }

    /**
     * Funkce na hrani pro jednoho hrace
     */
    public void playSingle() {
        List<CommonMazeObject> allObjs = new ArrayList<>();
        List<CommonMazeObject> ghosts = this.maze.getGhosts();
        // Vyber hlavniho pacmana
        CommonMazeObject pacman = this.maze.getPacmen().get(0);

        // Cekani do stisku prvni klavesy
        while (pacman.getLastDir() == null) {
            sleep(1);
        }

        // Ukladani objektu pro replay
        allObjs.add(this.maze.getPacmen().get(0));
        allObjs.addAll(this.maze.getGhosts());
        allObjs.addAll(this.maze.getKeys());
        allObjs.addAll(this.maze.getFruits());

        // Hra spustena
        while (true) {
            // Ukladani pozic objektu
            for (CommonMazeObject obj:allObjs) {
                obj.savePos(obj.getField().getRow(), obj.getField().getCol());
            }

            pacman.move(pacman.getLastDir());
            for (CommonMazeObject ghost:ghosts) {
                ghostMovement(ghost);
            }

            this.presenter.updateScore(false);

            // Kontrola konce hry
            if (pacman.getLives() == 0) {
                this.result = "LOST";
                break;
            }
            if (pacman.getKeys() == this.maze.numKeys() && pacman.getField() instanceof TargetField) {
                this.result = "WON";
                break;
            }

            sleep(300);
        }

        // Finalni ulozeni objektu pro replay
        for (CommonMazeObject obj : allObjs) {
            obj.savePos(obj.getField().getRow(), obj.getField().getCol());
        }

        MazeSave save = new MazeSave();
        save.loadToSave(allObjs, this.maze.getMap());

        this.gameState(false);
        sleep(1000);
    }

    /**
     * Funkce pro multiplayer -> hrac je server
     */
    public void playServer() {
        CommonMazeObject pacmanS = this.maze.getPacmen().get(0);
        CommonMazeObject pacmanC = this.maze.getPacmen().get(1);

        // Ustanoveni spojeni
        DatagramSocket serverSocket = NetworkUtils.createServerSocket();
        Pair<String, DatagramPacket> received = NetworkUtils.receiveDataServer(serverSocket);
        String receivedMessage = received.getFirst();
        DatagramPacket clientPacket = received.getSecond();
        pacmanC.saveLastDir(pacmanC.stringToDir(receivedMessage));

        List<CommonMazeObject> allObjs = new ArrayList<>();
        List<CommonMazeObject> ghosts = this.maze.getGhosts();

        this.presenter.updateIpLabel();

        // Cekani do stisku prvni klavesy
        while (pacmanS.getLastDir() == null) {
            sleep(1);
        }

        // Informovani klienta o zacatku hry
        NetworkUtils.sendDataServer(serverSocket, clientPacket.getAddress(), clientPacket.getPort(),
                "Starting the game!");

        allObjs.addAll(this.maze.getPacmen());
        allObjs.addAll(this.maze.getGhosts());
        allObjs.addAll(this.maze.getKeys());
        allObjs.addAll(this.maze.getFruits());

        // Hra spustena
        while (true) {
            // Ukladani stavu klienta pro kontrolu
            int pacmanCKeys = pacmanC.getKeys();
            int pacmanCFruit = pacmanC.getFruits();
            int pacmanCLives = pacmanC.getLives();
            boolean pickedFruit = false;
            boolean pickedKey = false;
            boolean lostLive = false;

            for(CommonMazeObject obj:allObjs) {
                obj.savePos(obj.getField().getRow(), obj.getField().getCol());
            }

            pacmanS.move(pacmanS.getLastDir());
            pacmanC.move(pacmanC.getLastDir());
            for (CommonMazeObject ghost:ghosts) {
                ghostMovement(ghost);
            }

            this.presenter.updateScore(false);

            // Kontrola vyhry P1 = Serveru
            if (pacmanC.getLives() == 0 || (pacmanS.getKeys() >= 1 && pacmanS.getField() instanceof TargetField)) {
                this.result = "WON";
                NetworkUtils.sendDataServer(serverSocket, clientPacket.getAddress(), clientPacket.getPort(), "LOST");
                break;
            }

            // Kontrola vyhry P2 = Klienta
            if (pacmanS.getLives() == 0 || (pacmanC.getKeys() >= 1 && pacmanC.getField() instanceof TargetField)) {
                this.result = "LOST";
                NetworkUtils.sendDataServer(serverSocket, clientPacket.getAddress(), clientPacket.getPort(), "WON");
                break;
            }

            // Kontrola pro update klient Pacmana
            if (pacmanCKeys < pacmanC.getKeys()) {
                pickedKey = true;
            }
            if (pacmanCFruit < pacmanC.getFruits()) {
                pickedFruit = true;
            }
            if (pacmanCLives > pacmanC.getLives()) {
                lostLive = true;
            }
            // Odeslani stavu hry klientovi
            NetworkUtils.sendDataServer(serverSocket, clientPacket.getAddress(), clientPacket.getPort(),
                    this.maze.getGameProgress(pickedFruit,pickedKey, lostLive));

            // Prijeti pohybu klienta
            received = NetworkUtils.receiveDataServer(serverSocket);
            receivedMessage = received.getFirst();
            clientPacket = received.getSecond();
            pacmanC.saveLastDir(pacmanC.stringToDir(receivedMessage));

            sleep(300);
        }

        for(CommonMazeObject obj : allObjs) {
            obj.savePos(obj.getField().getRow(), obj.getField().getCol());
        }

        MazeSave save = new MazeSave();
        save.loadToSave(allObjs, this.maze.getMap());

        this.gameState(false);
        sleep(1000);

        serverSocket.close();
    }

    /**
     * Funkce pro multiplayer -> hrac je klient
     */
    public void playClient() {
        boolean gameOn = false;
        CommonMazeObject pacman = this.maze.getPacmen().get(1);
        List<CommonMazeObject> allObjs = new ArrayList<>();

        DatagramSocket clientSocket = NetworkUtils.createClientSocket();

        // Cekani do stisku prvni klavesy
        while (pacman.getLastDir() == null) {
            sleep(1);
        }

        // Zaslani prvniho pohybu
        NetworkUtils.sendDataClient(clientSocket, this.host,pacman.lastDirToString());

        allObjs.addAll(this.maze.getPacmen());
        allObjs.addAll(this.maze.getGhosts());
        allObjs.addAll(this.maze.getKeys());
        allObjs.addAll(this.maze.getFruits());

        // Ziskani informace o zacatku hry
        String receivedMessage = NetworkUtils.receiveDataClient(clientSocket);
        if (receivedMessage.equals("Starting the game!")) {
            gameOn = true;
        }
        while (gameOn) {
            // Zaslani pohybu
            NetworkUtils.sendDataClient(clientSocket, this.host,pacman.lastDirToString());

            for(CommonMazeObject obj:allObjs) {
                obj.savePos(obj.getField().getRow(), obj.getField().getCol());
            }

            this.presenter.updateScore(true);

            // Prijeti stavu hry
            receivedMessage = NetworkUtils.receiveDataClient(clientSocket);
            if (receivedMessage.equals("WON") || receivedMessage.equals("LOST")) {
                this.result = receivedMessage;
                break;
            }
            this.maze.changeGameProgress(receivedMessage);
        }

        for(CommonMazeObject obj : allObjs) {
            obj.savePos(obj.getField().getRow(), obj.getField().getCol());
        }

        MazeSave save = new MazeSave();
        save.loadToSave(allObjs, this.maze.getMap());
        clientSocket.close();

        this.gameState(false);
        sleep(1000);
    }

    /**
     * Pohyb duchu
     * @param ghost pohybovany duch
     */
    public static void ghostMovement(CommonMazeObject ghost) {
        Random rand = new Random();

        int rand_num = rand.nextInt(4);
        CommonField.Direction dir = CommonField.Direction.values()[rand_num];
        if (ghost.canMove(dir)) {
            ghost.move(dir);
            ghost.saveLastDir(dir);
        }
    }

    /**
     * Nacteni mapoveho podkladu
     * @param fileName nazev souboru s mapou
     * @return mapa
     * @throws IOException spatne nacteni mapy
     */
    public static MazeConfigure mazeLoad (String fileName) throws IOException {
        BufferedReader reader;
        String line;

        reader = new BufferedReader(new FileReader("lib/map/" + fileName));

        // Nacteni poctu sloupcu a radku
        line = reader.readLine();
        String[] dimensions = line.split(" ");
        int numRows = Integer.parseInt(dimensions[0]);
        int numCols = Integer.parseInt(dimensions[1]);

        // Nacteni mapy
        MazeConfigure cfg = new MazeConfigure();
        cfg.startReading(numRows, numCols);
        for (int i = 0; i < numRows; i++) {
            line = reader.readLine();
            cfg.processLine(line);
        }

        if (!cfg.stopReading()) {
            return null;
        }

        reader.close();
        return cfg;
    }

    /**
     * Nastaveni mapy
     * @param name nazev textoveho souboru s mapou
     */
    public void setMaze(String name) {
        this.map = name;
        try {
            this.maze = Objects.requireNonNull(mazeLoad(this.map)).createMaze();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Ziskani mapoveho podkladu
     * @return mapovy podklad
     */
    public CommonMaze getMaze() {
        return this.maze;
    }

    /**
     * Nastaveni stavu hry
     * @param state novy stav hry
     */
    public void gameState (boolean state) {
        this.gameState = state;
    }

    /**
     * Nastaveni serveru pro daneho hrace
     * @param server <code>boolean</code> true = server
     */
    public void setIsServer(boolean server) {
        this.isServer = server;
    }

    /**
     * Nastaveni multiplayeru
     * @param multiplayer <code>boolean</code> true = multiplayer
     */
    public void setMultiplayer(boolean multiplayer) {
        this.multiplayer = multiplayer;
    }

    /**
     * Vrati, zda je dany hrac server
     * @return <code>boolean</code> true = je server
     */
    public boolean isServer() {
        return this.isServer;
    }

    /**
     * Vrati, zda se dana hra hraje v multiplayeru
     * @return <code>boolean</code> true = multiplayer
     */
    public boolean isMultiplayer() {
        return this.multiplayer;
    }

    /**
     * Ziskani IP adresy hrace
     * @return IP adresa hrace
     */
    public String getIP () {
        return this.ip.getHostAddress();
    }

    /**
     * Ulozeni hostujiciho serveru
     * @param host hostujici server
     */
    public void saveHost(String host) {
        this.host = host;
    }

    /**
     * Ziskani vysledku hry
     * @return vysledek hry
     */
    public String getResult() {
        return this.result;
    }

    /**
     * Aktivni cekani v X ms
     * @param ms milisekundy cekani
     */
    public static void sleep(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

