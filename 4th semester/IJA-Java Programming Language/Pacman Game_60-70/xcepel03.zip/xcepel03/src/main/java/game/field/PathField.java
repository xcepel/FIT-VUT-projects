/**
 * @file  PathField.java
 * @brief Trida reprezentujici policko na ceste v bludisti.
 * Na policko lze vlozit objekt MazeObject.
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 1, 2023
 */

package game.field;

import game.object.FruitObject;
import game.object.GhostObject;
import game.object.KeyObject;
import game.object.PacmanObject;
import tool.common.AbstractObservableField;
import tool.common.CommonField;
import tool.common.CommonMaze;
import tool.common.CommonMazeObject;
import tool.view.FieldView;

import java.util.ArrayList;
import java.util.List;

public class PathField extends AbstractObservableField implements CommonField {
    int col;
    int row;
    List<CommonMazeObject> objects = new ArrayList<>();
    CommonMaze maze = null;
    FieldView view;

    /**
     * Vytvori novy PathField s jeho pohledem FieldView
     * @param row rada
     * @param col sloupec
     */
    public PathField(int row, int col) {
        this.row = row;
        this.col = col;

        this.view = new FieldView(this);
        this.addObserver(this.view);
    }

    /**
     * Svazani pole s bludistem
     * @param maze bludiste, na kterem se bude pole nachazet
     */
    @Override
    public void setMaze(CommonMaze maze) {
        this.maze = maze;
    }

    /**
     * Ziskani bludiste, na kterem se pole nachazi
     * @return <code>CommonMaze</code>
     */
    public CommonMaze getMaze() {
        return this.maze;
    }

    /**
     * Vrati Field v danem smeru
     * @param dirs smer pohybu
     * @return <code>CommonField</code>
     */
    @Override
    public CommonField nextField(Direction dirs) {
        if (dirs == Direction.L)
            return this.maze.getField(this.row, this.col - 1);
        if (dirs == Direction.R)
            return this.maze.getField(this.row, this.col + 1);
        if (dirs == Direction.U)
            return this.maze.getField(this.row - 1, this.col);
        if (dirs == Direction.D)
            return this.maze.getField(this.row + 1, this.col);
        return null;
    }

    /**
     * Polozeni objektu na pole (pridani do seznamu objektu)
     * @param object pokladany objekt
     * @return true = objekt byl uspesne polozen
     */
    @Override
    public boolean put(CommonMazeObject object) {
        if (this.canMove()) {
            this.objects.add(object);
            this.view.update(this);
            return true;
        }
        return false;
    }

    /**
     * Odebrani objektu z pole (odebrani ze seznamu objektu)
     * @param object odebirany objekt
     * @return true = objekt byl uspesne odebran
     */
    @Override
    public boolean remove(CommonMazeObject object) {
        if (this.objects.contains(object)) {
            this.objects.remove(object);
            this.view.update(this);
            return true;
        }
        return false;
    }

    /**
     * Zjisteni, zda je pole prazdne
     * @return Neni tam objekt = null -> je to prazdne
     */
    @Override
    public boolean isEmpty() {
        return this.objects == null || this.objects.size() == 0;
    }

    /**
     * CommonMazeObject se muze pohnout na cestu
     * @return true
     */
    @Override
    public boolean canMove() {
        return true;
    }

    /**
     * Najde a vrati prvni instanci hledaneho objektu na poli
     * @param obj_type hledany objekt (Fruit/Ghost/Key/Pacman)
     * @return hledany objekt na poli/null
     */
    @Override
    public CommonMazeObject getObj(String obj_type) {
        for (CommonMazeObject object : this.objects) {
            switch (obj_type) {
                case "Fruit" -> {
                    if (object instanceof FruitObject)
                        return object;
                }
                case "Ghost" -> {
                    if (object instanceof GhostObject)
                        return object;
                }
                case "Key" -> {
                    if (object instanceof KeyObject)
                        return object;
                }
                case "Pacman" -> {
                    if (object instanceof PacmanObject)
                        return object;
                }
                default -> {
                    return null;
                }
            }
        }
        return null;
    }

    /**
     * Ziskani vsech objektu na poli
     * @return seznam vsech objektu na PathField
     */
    @Override
    public List<CommonMazeObject> getObjs() {
        return this.objects;
    }

    /**
     * Kontrola, zda se zadany objekty rovna tomuto PathField
     * @param obj kontrolovany objekt
     * @return pokud se rovna -> true
     */
    public boolean equals(Object obj) {
        if (obj instanceof PathField)
            return (this.col == ((PathField)obj).col && this.row == ((PathField)obj).row);
        return false;
    }

    /**
     * Ziskani pohledu daneho pole
     * @return <code>FieldView</code>
     */
    public FieldView getView() {
        return this.view;
    }

    /**
     * Ziskani sloupce na kterem se PathField nachazi
     * @return sloupec, na kterem se PathField nachazi
     */
    public int getCol() {
        return this.col;
    }

    /**
     * Ziskani rady na kterem se PathField nachazi
     * @return rada, na ktere se PathField nachazi
     */
    public int getRow() {
        return this.row;
    }
}
