/**
 * @file  WallField.java
 * @brief Trida reprezentujici zed v bludisti.
 * Na policko nelze vstoupit.
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 1, 2023
 */

package game.field;

import tool.common.CommonField;
import tool.common.CommonMaze;
import tool.common.CommonMazeObject;
import tool.view.FieldView;

import java.util.List;

public class WallField implements CommonField {
    int row;
    int col;
    CommonMaze maze = null;
    FieldView view;

    /**
     * Vytvori novy WallField s jeho pohledem FieldView
     * @param row rada
     * @param col sloupec
     */
    public WallField(int row, int col) {
        this.row = row;
        this.col = col;
        this.view = new FieldView(this);
    }

    /**
     * Svazani pole s bludistem
     * @param maze bludiste, na kterem se bude pole nachazet
     */
    @Override
    public void setMaze(CommonMaze maze) {
        this.maze = maze;
    }

    /**
     * Ziskani bludiste, na kterem se pole nachazi
     * @return <code>CommonMaze</code>
     */
    public CommonMaze getMaze() {
        return this.maze;
    }

    /**
     * Vrati Field v danem smeru
     * @param dirs smer pohybu
     * @return THROW -> UnsupportedOperationException - Na policko zdi nelze vstoupit
     */
    @Override
    public CommonField nextField(Direction dirs) {
        throw new UnsupportedOperationException("Na policko zdi nelze vstoupit.");
    }

    /**
     * Polozeni objektu na pole (pridani do seznamu objektu)
     * @param object pokladany objekt
     * @return THROW -> UnsupportedOperationException - Na policko zdi nelze vstoupit
     */
    @Override
    public boolean put(CommonMazeObject object) {
        throw new UnsupportedOperationException("Na policko zdi nelze vstoupit.");
    }

    /**
     * Odebrani objektu z pole (odebrani ze seznamu objektu)
     * @param object odebirany objekt
     * @return false - Na policko zdi nelze vstoupit
     */
    @Override
    public boolean remove(CommonMazeObject object) {
        return false;
    }

    /**
     * Zjisteni, zda je pole prazdne
     * @return true -> vzdy prazdne
     */
    @Override
    public boolean isEmpty() {
        return true;
    }

    /**
     * CommonMazeObject se muze pohnout na cestu
     * @return false - Na policko zdi nelze vstoupit
     */
    @Override
    public boolean canMove() { // Na policko nelze vstoupit.
        return false;
    }

    /**
     * Najde a vrati prvni instanci hledaneho objektu na poli
     * @param obj_type hledany objekt (Fruit/Ghost/Key/Pacman)
     * @return null - Na policko zdi nelze vstoupit, proto tam ani nebudou zadne objekty
     */
    @Override
    public CommonMazeObject getObj(String obj_type) {
        return null;
    }

    /**
     * Ziskani vsech objektu na poli
     * @return null - Na policko zdi nelze vstoupit, proto tam ani nebudou zadne objekty
     */
    @Override
    public List<CommonMazeObject> getObjs() {
        return null;
    }

    /**
     * Kontrola, zda se zadany objekty rovna tomuto PathField
     * @param obj kontrolovany objekt
     * @return pokud se rovna -> true
     */
    public boolean equals(Object obj) {
        if (obj instanceof WallField)
            return (this.col == ((WallField) obj).col && this.row == ((WallField) obj).row);
        return false;
    }

    /**
     * Ziskani pohledu daneho pole
     * @return <code>FieldView</code>
     */
    @Override
    public FieldView getView() {
        return this.view;
    }

    /**
     * Ziskani sloupce na kterem se PathField nachazi
     * @return sloupec, na kterem se PathField nachazi
     */
    public int getCol() {
        return this.col;
    }

    /**
     * Ziskani rady na kterem se PathField nachazi
     * @return rada, na ktere se PathField nachazi
     */
    public int getRow() {
        return this.row;
    }
}
