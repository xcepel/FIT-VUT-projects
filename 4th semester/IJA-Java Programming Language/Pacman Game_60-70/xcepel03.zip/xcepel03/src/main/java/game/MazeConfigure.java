/**
 * @file MazeConfigure.java
 * @brief Trida pro nacteni mapového podkladu a vytvoreni hry (bludiste)
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 1, 2023
 */

package game;

import game.field.PathField;
import game.field.TargetField;
import game.field.WallField;
import game.object.FruitObject;
import game.object.GhostObject;
import game.object.KeyObject;
import game.object.PacmanObject;
import tool.common.CommonField;
import tool.common.CommonMaze;

import java.util.ArrayList;

public class MazeConfigure {
    int rows = 0;
    int cols = 0;
    int keys, fruits;
    int read_rows = 0; // pocitadlo prectenych radku
    MazeConfigure.State state; // stav cteni
    ArrayList<String> map = new ArrayList<>();

    /**
     * Stavy cteni
     */
    public enum State {
        CREATED, ERROR, FINISHED, PROCESSING
    }

    /**
     * Vytvoreni MazeConfigure a nastaveni stavu na CREATED
     */
    public MazeConfigure() {
        this.state = MazeConfigure.State.CREATED;
    }

    /**
     * Zahájí čtení mapového podkladu zadaného rozměru (bez zdi)
     * @param rows <code>int</code> pocet rad
     * @param cols <code>int</code> pocet sloupcu
     */
    public void startReading(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
        this.state = MazeConfigure.State.PROCESSING;
    }

    /**
     * Nacte 1 radek mapového podkladu
     * @param line 1 radek mapoveho podkladu
     * @return <code>boolean</code> znacici upesnost nacteni
     */
    public boolean processLine(String line) {
        if (line.length() == cols && line.matches("^([XGTFKS.])+$") && this.read_rows <= rows && state != MazeConfigure.State.ERROR) {
            this.map.add(line);
            this.read_rows++;
            return true;
        }
        this.state = MazeConfigure.State.ERROR;
        return false;
    }

    /**
     * Ukonci cteni mapového podkladu
     * @return  <code>boolean</code> podle toho zda je nacteno vse
     */
    public boolean stopReading() {
        if (this.read_rows == this.rows && this.state != MazeConfigure.State.ERROR) {
            this.state = MazeConfigure.State.FINISHED;
            return true;
        }
        this.state = MazeConfigure.State.ERROR;
        return false;
    }

    /**
     * Vytvorí bludiste podle nacteného mapového podkladu
     * @return <code>CommonMaze</code> hotove nactene bludiste
     */
    public CommonMaze createMaze() {
        if (this.state != MazeConfigure.State.FINISHED) {
            return null;
        }

        CommonField[][] board = new CommonField[this.rows][this.cols];
        int ghostsCnt = 0;
        int pacmansCnt = 0;
        int fruitsCnt = 0;
        int keysCnt = 0;
        // Prirazovani policek (Field) a jejich objektu podle zadani mapy
        for (int row = 0; row < this.rows; row++) {
            for (int col = 0; col < this.cols; col++) {
                if (this.map.get(row).charAt(col) == 'X')
                    board[row][col] = new WallField(row + 1, col + 1);
                else if (this.map.get(row).charAt(col) == 'T')
                    board[row][col] = new TargetField(row + 1, col + 1);
                else if (this.map.get(row).charAt(col) == '.')
                    board[row][col] = new PathField(row + 1, col + 1);
                else if (this.map.get(row).charAt(col) == 'G') {
                    board[row][col] = new PathField(row + 1, col + 1);
                    board[row][col].put(new GhostObject(board[row][col]));
                    board[row][col].getObj("Ghost").setOrder(ghostsCnt);
                    ghostsCnt++;
                    board[row][col].getView().clearChanged();
                } else if (this.map.get(row).charAt(col) == 'K') {
                    board[row][col] = new PathField(row + 1, col + 1);
                    board[row][col].put(new KeyObject(board[row][col]));
                    board[row][col].getObj("Key").setOrder(keysCnt);
                    keysCnt++;
                    this.keys++;
                } else if (this.map.get(row).charAt(col) == 'F') {
                    board[row][col] = new PathField(row + 1, col + 1);
                    board[row][col].put(new FruitObject(board[row][col]));
                    board[row][col].getObj("Fruit").setOrder(fruitsCnt);
                    fruitsCnt++;
                    this.fruits++;
                } else { // Pacman
                    board[row][col] = new PathField(row + 1, col + 1);
                    board[row][col].put(new PacmanObject(board[row][col]));
                    board[row][col].getObj("Pacman").setOrder(pacmansCnt);
                    pacmansCnt++;
                    board[row][col].getView().clearChanged();
                }
            }
        }
        CommonMaze maze = PacmanMaze.create(this.rows, this.cols, board, this.keys, this.fruits);
        maze.setMap(this.map);
        maze.setGhosts();
        maze.setPacmen();
        maze.setFruits();
        maze.setKeys();
        return maze;
    }
}

