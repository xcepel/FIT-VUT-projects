/**
 * @file CommonMaze.java
 * @brief Interface pro CommonMaze
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 1, 2023
 */

package tool.common;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public interface CommonMaze {
    CommonField getField(int row, int col);

    int numRows();

    int numCols();

    List<CommonMazeObject> getGhosts();

    void setGhosts();

    List<CommonMazeObject> getPacmen();

    void setPacmen();

    int numKeys();

    List<CommonMazeObject> getKeys();

    void setKeys();

    int numFruits();

    List<CommonMazeObject> getFruits();

    void setFruits();

    void setFrame(JFrame frame);
    JFrame getFrame();

    ArrayList<String> getMap();

    void setMap(ArrayList<String> map);

    String getGameProgress(boolean pickedFruit, boolean pickedKey, boolean lostLive);

    void changeGameProgress(String progress);
}
