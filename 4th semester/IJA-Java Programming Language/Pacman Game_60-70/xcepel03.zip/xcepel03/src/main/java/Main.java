/**
 * @file Main.java
 * @brief Soubor pro spousteni hry Pacman.
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 1, 2023
 */

import func.GameFunc;

public class Main {
    public static void main(String... args) {
        GameFunc func = new GameFunc();
        // Vychozi nastaveni mapy
        func.setMaze("test.txt");
        func.setup();
    }
}

