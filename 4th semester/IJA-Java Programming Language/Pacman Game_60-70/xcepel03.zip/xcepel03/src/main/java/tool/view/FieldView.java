/**
 * @file FieldView.java
 * @brief Trida reprezentujici grafickou podobu policek
 * Implementuje Observable.Observer, muze byt notifikovan o zmene stavu policka.
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 1, 2023
 */

package tool.view;

import game.field.TargetField;
import game.field.WallField;
import tool.common.CommonField;
import tool.common.CommonMazeObject;
import tool.common.Observable;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

public class FieldView extends JPanel implements Observable.Observer {
    int updates = 0;
    CommonField model;
    int offsetX = 0;
    int offsetY = 0;
    private BufferedImage image;

    /**
     * Vyvori novy graficky pohled pro pole
     * @param model <code>CommonField</code> vykreslovane pole
     */
    public FieldView(CommonField model) {
        this.model = model;
    }

    /**
     * Vykresli grafickou podobu policka do grafického kontextu g.
     * @param g <code>Graphics</code>
     */
    protected void paintComponent(Graphics g) {
        // Vychozi nastaveni pro vykresleni cesty PathField/target TargetField
        g.setColor(Color.BLACK);

        // Nastaveni pro vykresleni zdi WallField
        if (this.model instanceof WallField) {
            g.setColor(new Color(25, 25, 166));
        }

        // Zobrazovani policka jako ctverec
        g.fillRect(this.model.getCol() * this.getWidth() + this.getOffsetX(),
                this.model.getRow() * this.getHeight() + this.getOffsetY(),
                this.getWidth(), this.getHeight());

        // Vykresleni ciloveho policka TargetField
        if (this.model instanceof TargetField) {
            try {
                image = ImageIO.read(new File("lib/pic/target.png"));
            } catch (Exception e) {
                e.printStackTrace();
            }
            g.drawImage(image, this.model.getCol() * this.getWidth() + this.getOffsetX(),
                    this.model.getRow() * this.getHeight() + this.getOffsetY(),
                    this.getWidth(), this.getHeight(), null);
        }
        // Vykresleni policka zdi WallField
        if (this.model instanceof WallField) {
            g.setColor(Color.BLACK);
            g.fillRect(this.model.getCol() * this.getWidth() + this.getOffsetX() + this.getWidth()/4,
                    this.model.getRow() * this.getHeight() + this.getOffsetY() + this.getWidth()/4,
                    this.getWidth()/2, this.getHeight()/2);
        }

        // Vykresleni objektu (CommonMazeObject(s)) na cestu
        if (!this.model.isEmpty() && this.model.getObjs() != null) {
            for (CommonMazeObject obj : this.model.getObjs()) {
                obj.getView().paintComponent(g);
            }
        }
    }

    @Override
    public void update() {}
    /**
     * Zpracovava notifikaci o zmene v objektu Observable.
     * @param field <code>Observable</code>
     */
    public final void update(Observable field) {
        field.notifyObservers();
        if (this.model.getMaze() != null && this.model.getMaze().getFrame() != null) {
            this.model.getMaze().getFrame().repaint();
        }
        this.updates++;
    }

    /**
     * Vraci pocet notifikaci objektu z Observable.
     * @return <code>int</code>
     */
    public int numberUpdates() {
        return this.updates;
    }

    /**
     * Vynuluje informaci o poctu notifikaci objektu z Observable.
     */
    public void clearChanged() {
        this.updates = 0;
    }

    /**
     * Vraci objekt policka, ktere je zobrazovano timto pohledem.
     * @return <code>CommonField</code>
     */
    public CommonField getField() {
        return this.model;
    }

    /**
     * Metoda pro vraceni rozmeru offsetX
     * @return <code>int</code>
     */
    public int getOffsetX() {
        return this.offsetX;
    }

    /**
     * Metoda pro nastaveni rozmeru offsetX
     */
    public void setOffsetX(int offsetX) {
        this.offsetX = offsetX;
    }

    /**
     * Metoda pro vraceni rozmeru offsetY
     * @return <code>int</code>
     */
    public int getOffsetY() {
        return this.offsetY;
    }

    /**
     * Metoda pro nastaveni rozmeru offsetY
     */
    public void setOffsetY(int offsetY) {
        this.offsetY = offsetY;
    }
}
