/**
 * @file FruitObject.java
 * @brief Trida pro Fruit
 *
 * @author xcepel03, xebert00,xpiroh02
 * @date May 1, 2023
 */

package game.object;

import tool.common.CommonField;
import tool.common.CommonMazeObject;
import tool.others.Pair;
import tool.view.FruitView;

import java.util.ArrayList;
import java.util.List;

public class FruitObject implements CommonMazeObject {
    CommonField field;
    FruitView view;

    int lives = 1;

    List<Pair<Integer, Integer>> positions = new ArrayList<>();

    int order = 0;

    /**
     * Vytvori FruitObject a priradi mu pole, na kterem stoji a pohled FruitView
     * @param field <code>CommonField<code/> na kterem ma stat
     */
    public FruitObject(CommonField field) {
        this.field = field;
        this.view = new FruitView(this.field.getView(), this);
    }

    /**
     * Ověří, zda je možné se přesunout zadaným směrem
     * @param dir smer pohybu
     * @return false -> Fruit se nemuze hybat
     */
    @Override
    public boolean canMove(CommonField.Direction dir) {
        return false;
    }

    /**
     * Snaha o přesun objektu na pole v zadaném směru, pokud je to možné
     * @param dir smer pohybu
     * @return false -> Fruit se nemuze hybat
     */
    @Override
    public boolean move(CommonField.Direction dir) {
        return false;
    }

    /**
     * Presun objektu na jine pole CommonField
     * @param newField pole presunu z aktualniho
     */
    @Override
    public void replace(CommonField newField) {
        if (newField.getRow() == 0 && newField.getCol() == 0)
            this.field.remove(this);
    }

    /**
     * Ziskani pole, na kterem se objekt nachazi
     * @return pole, na kterem se objekt nachazi
     */
    @Override
    public CommonField getField() {
        return this.field;
    }

    /**
     * Ziskani pohledu, ktery Fruit vykresluje
     * @return pohled, ktery Fruit vykresluje
     */
    @Override
    public FruitView getView() {
        return this.view;
    }

    /**
     * Ulozeni aktualni pozice objektu
     * @param x rada
     * @param y sloupec
     */
    @Override
    public void savePos(int x, int y) {
        if (this.lives == 0) {
            this.positions.add(new Pair<>(0, 0));
        } else {
            this.positions.add(new Pair<>(x, y));
        }
    }

    /**
     * Vrati seznam vsech pozic, na kterych se objekt za hru nachazel v sestupnem poradi
     * @return pozice objektu, od zacatku hry az do zavolani funkce
     */
    @Override
    public List<Pair<Integer, Integer>> getPos() {
        return this.positions;
    }

    /**
     * Nastaveni poradi objektu
     * @param order <code>int</code> poradi objektu
     */
    @Override
    public void setOrder(int order) {
        this.order = order;
    }

    /**
     * Vrati poradi objektu
     * @return <code>int</code> poradi objektu
     */
    @Override
    public int getOrder() {
        return this.order;
    }

    /**
     * Prevedeni stringu na CommonField.Direction - ovoce se nepohybuje
     * @param direction smer
     * @return null
     */
    @Override
    public CommonField.Direction stringToDir(String direction) {
        return null;
    }

    /**
     * Prevedeni CommonField.Direction na string - ovoce se nepohybuje
     * @return null
     */
    @Override
    public String lastDirToString() {
        return null;
    }

    /**
     * Pricteni fruit - ovoce nesbira ovoce
     */
    @Override
    public void addFruit() {}

    /**
     * Pricteni key - ovoce nesbira klic
     */
    @Override
    public void addKey() {}

    /**
     * Vrati pocet zivotu Fruit
     * @return 1 pokud jeste nebyl sebrany, 0 kdyz jiz sebrany byl
     */
    @Override
    public int getLives() {
        return this.lives;
    }

    /**
     * Vrati pocet kroku Fruit
     * @return 0 -> Fruit se nehyba
     */
    @Override
    public int getSteps() {
        return 0;
    }

    /**
     * Odecte Fruit 1 zivot
     */
    @Override
    public void removeLive() {
        this.lives--;
    }

    /**
     * Odebrani Fruit z mapy po sebrani
     * @return true
     */
    @Override
    public boolean remove() {
        this.field.remove(this);
        return true;
    }

    /**
     * Vrati pocet nasbiranych klicu
     * @return 0 -> Fruit nesbira klice
     */
    @Override
    public int getKeys() {
        return 0;
    }

    /**
     * Vrati pocet nasbiraneho ovoce
     * @return 0 -> Fruit nesbira ovoce
     */
    @Override
    public int getFruits() {
        return 0;
    }

    /**
     * Ulozi smer, kterym se chce objekt vydat
     * Fruit se nemuze hybat
     * @param dir smer, kterym se chce objekt vydat
     */
    @Override
    public void saveLastDir(CommonField.Direction dir) {
    }

    /**
     * Vrati smer, kterym se objekt naposledy pohnul
     * @return null -> Fruit se nemuze hybat
     */
    @Override
    public CommonField.Direction getLastDir() {
        return null;
    }

    /**
     * Prevedeni na string
     * @return "Fruit"
     */
    @Override
    public String toString() {
        return "Fruit";
    }
}
