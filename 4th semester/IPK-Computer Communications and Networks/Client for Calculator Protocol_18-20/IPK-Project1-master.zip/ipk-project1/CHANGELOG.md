Changelog k 1. projektu IPK  -- Klient ke vzdálené kalkulačce</br>
Jméno a příjmení: Kateřina Čepelková</br>
Login: xcepel03

### Implementovaná funkcionalita
- Klient vzdáleně komunikuje se serverem pomocí uživatelem vybraného protokolu
- Klient reaguje na vypnutí pomocí signálu přerušení čistým ukončením spojení a programu
- EOF je bráno jako signál přerušení
- **Spuštění klienta:** 
	- `ipkcpc -h <host> -p <port> -m <mode>`
	- `host` = IPv4 adresa serveru, `port` = port serveru a `mode` = režim protokolu (TCP/UDP)
	- při chybném spuštění (např. špatný počet argumentů, špatný port,...) je klient ukončen s chybovým kódem a zprávou na standartním chybovém řádku
- **Uživatelské příkazy:**
	 - TCP: `HELLO`, `SOLVE (<operator> <number1> <number2>)`, `BYE`
		 - spojení musí začít příkazem `HELLO` od uživatele, jinak je klient ukončen s chybovým kódem a zprávou na standartním chybový výstup
		 - při chybném zadání příkazu je klient ukončen s chybovým kódem a zprávou na standartním chybový výstup
		 - klient může být ukončen pomocí `BYE` nebo signálem přerušení
	 - UDP: `(<operator> <number1> <number2>)`
	    - při chybném zadání příkazu je klient vypíše zprávou na standartním výstup a čeká na další příkaz
	    - klient je možné ukončit pouze pomocí signálu přerušení
	 - Operátory: `+`, `-`, `*`, `/`

### Známá omezení
- Omezené velikosti bufferů pro načítání příkazů od klienta i serveru
	- UDP - 259 bytů -- při snaze o poslání zprávy delší než 255 znaků je vypsáno chybové hlášení a a zpráva není odeslána serveru, klient zůstane spuštěný