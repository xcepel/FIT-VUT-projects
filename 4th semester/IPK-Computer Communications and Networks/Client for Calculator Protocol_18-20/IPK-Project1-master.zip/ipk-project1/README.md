Dokumentace k 1. projektu IPK  -- Klient ke vzdálené kalkulačce </br>
Jméno a příjmení: Kateřina Čepelková</br>
Login: xcepel03

### 1 Analýza požadavků
Zadáním úlohy byla implementace klienta ke vzdálené kalkulačce v programovacím jazyku C++.
Klient se spouští pomocí `ipkcpc -h <host> -p <port> -m <mode>`, kde `host` je IPv4 adresa serveru, `port` je port serveru a `mode` je režim protokolu (TCP nebo UDP).

Po spuštění se pomocí zadaného protokolu připojí na server a série příkazů ze standartního vstupu s ním komunikuje a tiskne odpovědi serveru na standartní výstup a chyby na standartní chybový výstup.
Klient také může reagovat na signál přerušení bezproblémovým ukončením spojení. 

Formát uživatelských příkazů:
 - TCP: `HELLO`, `SOLVE (<operator> <number1> <number2>)`, `BYE`
 - UDP: `(<operator> <number1> <number2>)`
 - operator: `+`, `-`, `*`, `/`

### 2 Teorie
Klient může operovat na jednom z dvou protokolů transportní vrstvy v sadě TCP/IP -- TCP nebo UDP.
![[1] Spojeni TCP a UDP](https://info-savvy.com/wp-content/uploads/2020/06/Introduction-to-TCP-and-UDP-infosavvy-1.png)
> [1] Spojeni TCP a UDP

#### 2.1 TCP 
 - spojení point-to-point
 - garantuje spolehlivé doručování díky zřetězenému přenosu segmentů, kumulativnímu ACK potvrzování a jednomu časovači znovu-zasílání [1]
#### 2.2 UDP
 - datagramová služba bez záruky doručení
 - nespojovaná služba (connection-less)
 - Formát datagramu: [2]
  <pre>
                   0      7 8     15 16    23 24    31
                 +--------+--------+--------+--------+
                 |     Source      |   Destination   |
                 |      Port       |      Port       |
                 +--------+--------+--------+--------+
                 |                 |                 |
                 |     Length      |    Checksum     |
                 +--------+--------+--------+--------+
                 |
                 |          data octets ...
                 +---------------- ...
  </pre>

### 3 Implementace
Kód klienta v jazyce C++ standardu 20 se nachází v souboru `ipkcpc.cpp`.  Je inspirován sadou souborů demonstrujících různé způsoby implementace klient-server dodané v zadání od pana docenta Ondřeje Ryšavého (rysavy@fit.vutbr.cz) a to konkrétně implementace klienta u TCP[1] a UDP[2]. EOF je bráno jako signál přerušení.

#### 3.1 Načítání parametrů
Po spuštění klienta je překontrolován počet argumentů a zkontrolováno jejich správné řazení.  Následně je z těchto argumentů získána adresa serveru a číslo portu, které jsou využity na nalezení IP adresy serveru a připojení se pomocí síťových knihoven c++.  Dále se získá z argumentů režim, ve kterém má klient operovat a podle něj se spustí jedna z funkcí `int tcp_connection(struct  sockaddr_in server_address)` nebo `int udp_connection(struct  sockaddr_in server_address)`.

#### 3.2 TCP spojení
Je zařizováno díky funkcím `int  tcp_connection(struct  sockaddr_in  server_address)`, zařizující komunikaci,  `void  signal_handler(int  signum)`, sloužící k detekci signálu přerušení pomocí `signal.h` knihovny a `int  tcp_terminator(int  exit,  int  client_socket,  int  bytestx,  int  bytesrx,  char  *buf)`, sloužící k ukončení propojení klienta se serverem.

Pro propojení je vytvořen síťový socket a následně začíná stav inicializace a je očekávané jako první příkaz "HELLO" na standartním vstupu od uživatele. Situace, kdy němu nedojde, a zároveň server není ukončen signálem přerušení, je brána jako chybná a je navrácen chybový kód 1. Pokud ale program "HELLO" obdrží přechází se do zavedeného stavu, kde už uživatel může zadávat příkazy na výpočet pomocí "SOLVE <příkaz>". Pro fungování načítání uživatelovy zprávy, odeslání ji a přijetí odpovědi je nutno vyžít `do-while` cyklus, který načítá ze standartního vstupu pomocí `fgets()` a je ukončen buď při přijetí signálu přerušení nebo "BYE" -- v tomto případě klient ukončí spojení se serverem. Spojení se serverem je ale také ukončeno, když uživatel zadá neznámý příkaz -- to je detekováno tak, že se kontroluje každá odpověď serveru a pokud byl zadán příkaz, který není "BYE" ale bylo navráceno "BYE" tak klient ukončí spojení se serverem a navrátí chybový kód 1.

Funkce `signal_handler()` funguje na principu, že po detekci signálu přerušení uzavře standartní vstup, čímž `fgets()` ve `while` cyklu ve funkci `tcp_connection` při dalším načtení načte `NULL` a díky tomu se daný cyklus ukončí a následně je zavolána funkce ukončující propojení klienta a serveru.

TCP spojení je implementované tak, že může nabrat neomezeně dlouhý (omezený pouze bufferem výpočetního serveru) řetězec příkazů `SOLVE (<operator> <number1> <number2>)` a to díky `while` smyčce, která kontroluje, zda opravdu načetla celý řetězec.

#### 3.3 UDP spojení
Je zařizováno díky funkci `int  udp_connection(struct  sockaddr_in  server_address)`.
Jelikož UDP protokol na rozdíl od TCP nevyžaduje žádný *handshake* může uživatel zasílat příkazy ihned po zprovoznění síťového socketu. Podobně jako ve funkci `udp_connection()` je zde na načítání příkazů uživatele použit cyklus `while` a `fgets()`.

Jelikož UDP ale využívá datagramy bylo důležité zde pomocí ukazatelové aritmetiky naimplementovat posunování bufferu, do kterého se načítá zpráva od klienta (první 2 byty jsou obsazené operačním kódem a délkou příkazu), a také bufferu, do kterého se načítá odpověď serveru (první 3 byty jsou obsazené operačním kódem, stavovým kódem a délkou příkazu). Podle stavového kódu se pak rozlišuje, zda byl příkaz správný (kód == 0), nebo chybný. Propojení přes UDP se dá ukončit pouze signálem přerušení. 

Důvod pro zvolení velikosti `UDP_BUFSIZE` jako 258 je takový, že potřebujeme započítat bajty pro *Opcode*, *Payload Length* a byty zprávy. Zpráva může být ale maximálně 256 (2^8) bytu velká, jelikož taková je maximální hodnota Payload Length, ale musíme ještě nechat 1 byte pro koncovou nulu zprávy, takže zpráva jako taková může mít pouze 255 bytů/znaků. Pokud tedy uživatel zašle příkaz delší než 255 znaků je vypsáno chybové hlášení a zpráva není serveru zaslána.

### 4 Testování
Klient byl testován na referenčním virtuálním serveru s operačním systémem Nix, přiloženém v zadání, s 64bitovým linuxovým jádrem na verzi 5.12.94 a přeložen pomocí Makefile s příkazem `g++`a parametry `-Wall -Wextra -std=c++20`.

#### 4.1 Testování propojení pomocí TCP
![1](https://user-images.githubusercontent.com/94400240/226141045-1cb15fdc-abb1-430d-b36e-367c4382fdc4.png)
> Spuštění klienta s "HELLO", výpočet příkladu 8 + 12, uzavření klienta pomocí "BYE"

![2](https://user-images.githubusercontent.com/94400240/226141084-a27854e4-c53a-468c-a95d-63a073cad88e.png)
> Snaha o zadání příkladu bez "HELLO"

![3](https://user-images.githubusercontent.com/94400240/226141093-9e14eed1-03ac-482f-9d2c-5d9d6e03c903.png)
> Spuštění klienta s "HELLO", zadání neznámého příkazu

![4](https://user-images.githubusercontent.com/94400240/226552712-240aecc3-1f36-41c0-8dcf-706b595f0bf6.png)
> Ukončení spojení přes signál přerušení

![5](https://user-images.githubusercontent.com/94400240/226166616-2e406310-dcbc-4238-8219-1c03e0dda534.png)
> Výpočet více příkladů za sebou

#### 4.2 Testování propojení pomocí UDP
![6](https://user-images.githubusercontent.com/94400240/226141120-40ce4a41-2fbc-4cfa-98de-ca366eb78f65.png)
> Spuštění klienta, výpočet příkladu 8 + 12, ukončení přes signál přerušení

![8](https://user-images.githubusercontent.com/94400240/226141137-2367ce75-d5d8-4da6-a5e0-e4641f9637d6.png)
> Spuštění klienta, zadání neznámého příkazu, výpočet 4 * 3

### 5 Bibliografie
Text:</br>
[1] RFC 793: Transmission Control Protocol . _» RFC Editor_ [online]. Dostupné z: [https://www.rfc-editor.org/rfc/rfc793](https://www.rfc-editor.org/rfc/rfc793)</br>
[2] RFC 768: User Datagram Protocol . _» RFC Editor_ [online]. Dostupné z: [https://www.rfc-editor.org/rfc/rfc768](https://www.rfc-editor.org/rfc/rfc768)

Obrázky:</br>
[1] Introduction to TCP and UDP | Infosavvy Security and IT Management Training. _Infosavvy Security And Management Training 2020-21 | Info-savvy_ [online]. Copyright © 2023 [cit. 18.03.2023]. Dostupné z: [https://info-savvy.com/introduction-to-tcp-and-udp/](https://info-savvy.com/introduction-to-tcp-and-udp/)

Kód: </br>
[1] IPK-Projekty/client.c at master - IPK-Projekty - FIT - VUT Brno - git. [online]. Dostupné z: [https://git.fit.vutbr.cz/NESFIT/IPK-Projekty/src/branch/master/Stubs/cpp/DemoTcp/client.c](https://git.fit.vutbr.cz/NESFIT/IPK-Projekty/src/branch/master/Stubs/cpp/DemoTcp/client.c)</br>
[2] IPK-Projekty/client.c at master - IPK-Projekty - FIT - VUT Brno - git. [online]. Dostupné z: [https://git.fit.vutbr.cz/NESFIT/IPK-Projekty/src/branch/master/Stubs/cpp/DemoUdp/client.c](https://git.fit.vutbr.cz/NESFIT/IPK-Projekty/src/branch/master/Stubs/cpp/DemoUdp/client.c)