/*
 *  ipkcpc.cpp
 *  Client for the IPK Calculator Protocol
 *  Copyright (C) 2023  Kate�ina �epelkov�, xcepel03@stud.fit.vutbr.cz
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *  
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <unistd.h>
#include <iostream>
#include <cstdlib>
#include <signal.h>

#define TCP_BUFSIZE 1024
#define UDP_BUFSIZE 259 // Bytes = 255 + \0 + Opcode + Payload Length
#define ERROR 1 // Error return value

using namespace std;


// Handler of interrupt signal - when signal called -> prevents from entering into stdin -> fgets get NULL -> terminates
void signal_handler(int signum) {
    fclose(stdin);
    (void)signum; // surpressing unused parametr
}

// Closes tcp communication with custom return value
int tcp_terminator(int exit, int client_socket, int bytestx, int bytesrx, char *buf) {
    bytestx = send(client_socket, "BYE\n", strlen("BYE\n"), 0);
    if (bytestx < 0) 
	fprintf(stderr, "ERROR: In sendto.\n");

    // Receiving answer from server and writing it out
    bzero(buf, TCP_BUFSIZE);
    bytesrx = recv(client_socket, buf, TCP_BUFSIZE, 0);
    if (bytesrx < 0) 
        fprintf(stderr, "ERROR: In recvfrom.\n");
    printf("%s", buf);

    close(client_socket);
    
    return exit; 
}


// Communication via TCP connection
int tcp_connection(struct sockaddr_in server_address)
{
    int client_socket;
    int bytestx = 0; 
    int bytesrx = 0;
    char buf[TCP_BUFSIZE];
   
    signal(SIGINT, signal_handler);

    // Creation of socket
    if ((client_socket = socket(AF_INET, SOCK_STREAM, 0)) <= 0) {
	fprintf(stderr, "ERROR: Creation of socket failed.\n");
        return 1;
    }

    // Connecting to server
    if (connect(client_socket, (const struct sockaddr *)&server_address, sizeof(server_address)) != 0) {
	fprintf(stderr, "ERROR: In connect.\n");
        return 1;
    }
    
    // Init state - expecting HELLO 
    if (fgets(buf, TCP_BUFSIZE, stdin) == NULL) { // ^C
        return tcp_terminator(0, client_socket, bytestx, bytesrx, buf);
    } else if (strcmp(buf, "HELLO\n")) { // no HELLO
	fprintf(stderr, "ERROR: Wrong init - missing HELLO.\n");
        return tcp_terminator(ERROR, client_socket, bytestx, bytesrx, buf);
    }

    // Established state = solving
    do {
        if (!strcmp(buf, "BYE\n") || !strcmp(buf, "BYE")) { // Terminating connection
            break;
        }

        // Sending message to the server
        bytestx = send(client_socket, buf, strlen(buf), 0);
        if (bytestx < 0) 
	    fprintf(stderr, "ERROR: In sendto.\n");

        // Checking if the whole request is read
        while (buf[strlen(buf) - 1] != '\n') {
            // send '\n' when EOF without '\n'reached
            if(fgets(buf, TCP_BUFSIZE, stdin) == NULL) {
                bytestx = send(client_socket, "\n", 1, 0);
                if (bytestx < 0) 
	            fprintf(stderr, "ERROR: In sendto.\n");
                break;
            }
            bytestx = send(client_socket, buf, strlen(buf), 0);
            if (bytestx < 0) 
	        fprintf(stderr, "ERROR: In sendto.\n");
        }
        
        // Receiving answer from server and writing it out
        bzero(buf, TCP_BUFSIZE);
        bytesrx = recv(client_socket, buf, TCP_BUFSIZE, 0);
        if (bytesrx < 0) 
	    fprintf(stderr, "ERROR: In recvfrom.\n");
        printf("%s", buf);
        
        while (buf[strlen(buf) - 1] != '\n') {
            bzero(buf, TCP_BUFSIZE);
            bytesrx = recv(client_socket, buf, TCP_BUFSIZE, 0);
            if (bytesrx < 0) 
	        fprintf(stderr, "ERROR: In recvfrom.\n");
            printf("%s", buf);
        }
        
        if (!strcmp(buf, "BYE\n")) {
	    fprintf(stderr, "ERROR: Unknown request.\n");
            return tcp_terminator(ERROR, client_socket, bytestx, bytesrx, buf);
        }
    } while (fgets(buf, TCP_BUFSIZE, stdin));

    // Finished solving - Terminating connection
    return tcp_terminator(0, client_socket, bytestx, bytesrx, buf);
}


// Communication via UDP connection
int udp_connection(struct sockaddr_in server_address)
{
    int client_socket, bytestx, bytesrx;
    socklen_t serverlen = sizeof(server_address);
    char recvbuf[UDP_BUFSIZE + 1] = {0}; // + Status Code
    char sendbuf[UDP_BUFSIZE] = {0};
     
    // Creation of socket
    if ((client_socket = socket(AF_INET, SOCK_DGRAM, 0)) <= 0) {
	fprintf(stderr, "ERROR: Creation of socket failed.\n");
        return 1;
    }

    // Connected to server
    while(fgets(sendbuf + 2, UDP_BUFSIZE - 2, stdin)) {
        sendbuf[1] = strlen(sendbuf + 2); // payload lenght
        if (sendbuf[sendbuf[1] + 1] == '\n') { 
            sendbuf[1]--; // sending one less byte (without \n)
        } else if (!feof(stdin) && fgetc(stdin) != '\n') { // if EOF or Line is too long
            while (!feof(stdin) && fgetc(stdin) != '\n'); // removing unread characters in line 
	    fprintf(stderr, "ERROR: Too long message - unable to send.\n");
            continue;
        }

        // Sending message to server
        bytestx = sendto(client_socket, sendbuf, sendbuf[1] + 2, 0, (struct sockaddr *)&server_address, serverlen);
        if (bytestx < 0) 
	    fprintf(stderr, "ERROR: In sendto.\n");
    
        // Receiving answer from server and writing it out
        bzero(recvbuf, UDP_BUFSIZE + 1);
        bytesrx = recvfrom(client_socket, recvbuf, UDP_BUFSIZE + 1, 0, (struct sockaddr *)&server_address, &serverlen);
        if (bytesrx < 0) 
	    fprintf(stderr, "ERROR: In recvfrom.\n");
        if (recvbuf[1] == 0) {
            printf("OK:%s\n", recvbuf + 3);
        } else {
            printf("ERR:%s\n", recvbuf + 3); 
        }
    }

    close(client_socket);
    return 0;
}


int main(int argc, char *argv[])
{
    int port_number;
    const char *server_host;
    struct hostent *server;
    struct sockaddr_in server_address;

    // Argument check
    if (argc != 7) {
        fprintf(stderr, "ERROR: Wrong number of arguments (%d).\n", argc);
        return 1;
    }

    if (strcmp(argv[1], "-h") || strcmp(argv[3], "-p") || strcmp(argv[5], "-m")) {
        fprintf(stderr, "ERROR: Wrong arguments.\n");
        return 1;
    }

    server_host = argv[2];
    port_number = atoi(argv[4]);
    
    // Obtaining the server address
    if ((server = gethostbyname(server_host)) == NULL) {
        fprintf(stderr,"ERROR: no such host as %s.\n", server_host);
        return 1;                        
    }

    // Finding the server IP address and init of the server_address
    bzero((char *)&server_address, sizeof(server_address));
    server_address.sin_family = AF_INET;
    bcopy((char *)server->h_addr, (char *)&server_address.sin_addr.s_addr, server->h_length);
    server_address.sin_port = htons(port_number);

    // Choosing the mod
    if (!strcmp(argv[6], "tcp"))
        return tcp_connection(server_address);

    if (!strcmp(argv[6], "udp"))
        return udp_connection(server_address);

    fprintf(stderr, "ERROR: Unknown mod.\n");
    return 1;
}
