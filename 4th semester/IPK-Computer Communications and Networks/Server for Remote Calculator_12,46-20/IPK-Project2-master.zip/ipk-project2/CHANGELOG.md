Dokumentace k 2. projektu IPK  -- IOTA: Server pro vzdálenou kalkulačku </br>
Jméno a příjmení: Kateřina Čepelková</br>
Login: xcepel03

### Implementovaná funkcionalita
- Server vzdáleně komunikuje s klienty pomocí uživatelem vybraného protokolu (UDP/TCP)
- Server reaguje na vypnutí pomocí signálu přerušení čistým ukončením spojení a programu
- **Spuštění serveru:** 
	- `ipkcpc -h <host> -p <port> -m <mode>`
	- `host` = IPv4 adresa serveru, `port` = port serveru a `mode` = režim protokolu (TCP/UDP)
	- při chybném spuštění (např. špatný počet argumentů, špatný port,...) je server ukončen s chybovým kódem a zprávou na standartním chybovém řádku

- **Uživatelské příkazy:**
	 - TCP: `HELLO`, `SOLVE expr` -> `SOLVE (<operator> <expr1> <expr2> ... <exprN)`, `BYE`
		 - spojení musí začít příkazem `HELLO` od klienta, jinak server zašle klientu zprávu `BYE\n` a ukončí spojení
		 - při získání chybného příkazu od klienta server klientu zašle klientu zprávu `BYE\n` a ukončí spojení
		 - při získání správého a spočitatelného příkazu server klientu zašle klientu zprávu `RESULT [výsledek]\n` a pokračuje ve spojení
		 - server je ukončen pomocí signálu přerušení, kdy ukončí komunikaci se všemi připojenými klienty
	 - UDP: `expr` -> `(<operator> <expr1> <expr2> ... <exprN)`
	    - při získání chybného příkazu server zašle klientu zprávu ve formátu `Opcode = 1, Status Code = 1, Payload Length, [error zprava]`
	    - při získání správného příkazu server zašle klientu zprávu ve formátu `Opcode = 1, Status Code = 0, Payload Length, [výsledek]`
	    - server je ukončen pomocí signálu přerušení
	 - Operátory: `+`, `-`, `*`, `/`

### Známá omezení
- Omezené velikosti bufferů pro načítání příkazů od klienta i serveru
	- UDP - 259 bytů -- při snaze o odeslání výsledku delší než 255 znaků je namísto toho zaslána klientu chybová zpráva `Opcode = 1, Status Code = 1, Payload Length, [error zprava]`
    - TCP - 1024 bytů