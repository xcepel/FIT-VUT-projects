/*
 *  ipkcpd.cpp
 *  Server for Remote Calculator - IPK
 *  Copyright (C) 2023  Katerina Cepelková, xcepel03@stud.fit.vutbr.cz
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *  
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <csignal>
#include <list>

#define TCP_BUFSIZE 1024
#define UDP_BUFSIZE 259 // Bytes = 255 + \0 + Opcode + Payload Lenght + Status code


// Interrupt signal handler
bool interrupted = false;
void signal_handler(int signum) {
    interrupted = true;
    printf("Server interrupted - shutting down\n");
    (void)signum; // supressing unused parametr
}


// Returns lenght of int
int intlen(int num) {
    int cnt = 0;
    while (num != 0) {
        cnt++;
        num /= 10;
    }

    return cnt;
}

// Finds start of the expression
int find_start_expr(const char *example)
{
    int pos = 0;

    // Skip old expression
    while (example[pos] && example[pos] != ' ' && example[pos] != ')') {
        pos++;
    }
    
    // Find next
    for (; example[pos]; pos++) {
        if ((example[pos] == '+' || example[pos] == '-') && (example[pos + 1] >= '0' && example[pos + 1] <= '9')) // signed number
            break;
        if (example[pos] == '(' || example[pos] == ')' || (example[pos] >= '0' && example[pos] <= '9'))
            break;
    }
    return pos;
}


// Finds end of the expression (skips through filling)
int find_end_expr(const char *example)
{
    int pos = 1;
    int brackets = 1; // bracket counter -> ( = first loaded
    while(example[pos] && brackets != 0) {
        pos++;
        if (example[pos] == '(')
            brackets++;
        if (example[pos] == ')')
            brackets--;
    }
    return pos;
}


// Returns result of example in format (symb value value) - if error occures return 0 and sets error bool to true
int calculate(char *example, bool *error)
{
    char oper = example[1]; // first operator
    int exprN;
    int pos = find_start_expr(example); // start at position of first expression
    int result;

    if (example[pos] == '(') { // format (op expr expr)
        result = calculate(&example[pos], error);
        pos += find_end_expr(&example[pos]);        
        pos++; // skip )
    } else { // format num
        result = atoi(&example[pos]);
        if (result < 0) { // removing signed numbers
            *error = true;
            return 0;
        }
    }
    
    pos += find_start_expr(example+pos); // find pos of next expression
    // Check if expr is right format
    if (example[pos] == ')') { 
        *error = true;
        return 0;
    }
    
    // Load next N operators and finish example
    while (example[pos] && example[pos] != ')' && !*error) {
        if (example[pos] == '(') { // format (op expr expr)
            exprN = calculate(&example[pos], error);
            pos += find_end_expr(&example[pos]);
            pos++; // skip )
        } else { // format num
            exprN = atoi(&example[pos]); // removing signed numbers
            if (exprN < 0) {
                *error = true;
                return 0;
            }
        }

        // Evaluation of the operator
        switch (oper) {
            case '+':
                result += exprN;
                break;
            case '-':
                result -= exprN;
                break;
            case '*':
                result *= exprN;
                break;
            case '/':
                if (exprN == 0) { // no dividing by 0
                    *error = true;
                    return 0;
                }
                result /= exprN;
                break;
            default:
                *error = true;
                return 0;
        }
        
        pos += find_start_expr(&example[pos]);
    }

    return result;
}


// Check if in example are only (), operators, spaces and numbers + number of ( and ) must be equal
bool example_check(const char *example) 
{
    int len = strlen(example);
    int left = 0; // counter of (
    int right = 0; // counter of )

    // Check for only allowed chars (operators, (, ), digits)
    for (int i = 0; i < len; i++) {
        char c = example[i]; 
        if (c == '(') {
            left++;
            continue;
        } else if (c == ')') {
            right++;
            continue;
        } else if (c == '+' || c == '-' || c == '*' || c == '/' || c == ' ' || isdigit((unsigned char)c)) {
            continue;
        }
        return false;
    }
   
    // Wrong number of () ?
    if (left != right)
        return false;

    return true;
}


int main(int argc, char *argv[])
{
    // TCP variables
    int rc;
    int welcome_socket;
    struct sockaddr_in6 sa;
    struct sockaddr_in6 sa_client;
    char str[INET6_ADDRSTRLEN];

    // UDP variables
    int server_socket, bytestx, bytesrx;
    socklen_t clientlen;
    struct sockaddr_in client_address, server_address;
    int optval;

    int port_number;

    // Argument check
    if (argc != 7) {
        fprintf(stderr, "ERROR: Wrong number of arguments (%d).\n", argc);
        return 1;
    }

    if (strcmp(argv[1], "-h") || strcmp(argv[3], "-p") || strcmp(argv[5], "-m")) {
        fprintf(stderr, "ERROR: Wrong arguments.\n");
        return 1;
    }

    char *mode = argv[6];
    port_number = atoi(argv[4]);

    //TCP server
    if ((strcmp(mode, "TCP") == 0) || (strcmp(mode, "tcp") == 0)) {
        std::list<pid_t> pid_list; // list for children processes
        
        // Creation of the socket
        socklen_t sa_client_len = sizeof(sa_client);
        if ((welcome_socket = socket(PF_INET6, SOCK_STREAM, 0)) < 0) {
            fprintf(stderr, "ERROR: socket");
            return 1;
        }
        
        // Suppress the default behavior of port reservation
        optval = 1;
        setsockopt(welcome_socket, SOL_SOCKET, SO_REUSEADDR, (const void *)&optval , sizeof(int));

        memset(&sa,0,sizeof(sa));
        sa.sin6_family = AF_INET6;
        sa.sin6_addr = in6addr_any;
        sa.sin6_port = htons(port_number);
        
        // Stabilise connection
        if ((rc = bind(welcome_socket, (struct sockaddr*)&sa, sizeof(sa))) < 0) {
            fprintf(stderr, "ERROR: bind");
            return 1;
        }
        if ((listen(welcome_socket, 1)) < 0) {
            fprintf(stderr, "ERROR: listen");
            return 1;
        }

        // Connection of clients
        while(!interrupted) {
            int comm_socket = accept(welcome_socket, (struct sockaddr*)&sa_client, &sa_client_len);
            if (comm_socket <= 0) {
                continue;
            }

            int pid = fork();
            if (pid < 0) {
                fprintf(stderr, "ERROR: fork() failed");
                return 1;
            }

            // New process to maintain client's requests
            if (pid == 0) {
                int child_pid = getpid();
                close(welcome_socket); // not necessary in child process
                printf("New connection (maintained by %d):\n", child_pid);
                if (inet_ntop(AF_INET6, &sa_client.sin6_addr, str, sizeof(str))) { 
                    printf("\tClient address is %s and port is %d\n", str, ntohs(sa_client.sin6_port));
                }

                bool handshake = false; // check if handshake was performed
                bool error_check = false;
                char question[TCP_BUFSIZE];
                memset(question, 0, sizeof(question));
                char answer[TCP_BUFSIZE];
                memset(answer, 0, sizeof(answer));
                int res = 0;
                int number;
                while (!interrupted) {
                    signal(SIGINT, signal_handler);
                    
                    // Receive request/question
                    res = recv(comm_socket, question, TCP_BUFSIZE, 0);
                    if (res <= 0 || interrupted)
                        break;
                    
                    // Check if handshake was performed (correctly)
                    if (!handshake) {
                        if ((strcmp(question, "HELLO\n") == 0)) { // HELLO received
                            handshake = true;
                            strcpy(answer, "HELLO\n");
                        } else { // no HELLO
                            strcpy(answer, "BYE\n");
                        }
                    
                    // Handshake received -> Connection secured
                    } else {
                        // SOLVE example
                        if ((strncmp(question, "SOLVE ", 6) == 0)) {
                            char example[TCP_BUFSIZE - 6]; 
                            strcpy(example, question + 6); // removing SOLVE_
                            example[strlen(example) - 1] = '\0'; // removing '\n'
                            
                            // Format checker + calculating if right format
                            if (!example_check(example)) { // wrong format
                                strcpy(answer, "BYE\n");
                            } else { // good format
                                number = calculate(example, &error_check);
                                if (error_check || number < 0) { // ERROR or negative result
                                    strcpy(answer, "BYE\n");
                                } else {
                                    strcpy(answer, "RESULT ");
                                    sprintf(example, "%d", number);
                                    strcat(answer, example);
                                    answer[strlen(answer)] = '\n';
                                }
                            } 
                        // Other formats then SOLVE_()
                        } else {
                            strcpy(answer, "BYE\n");
                        }  
                    }
                    
                    send(comm_socket, answer, strlen(answer), 0);
                    
                    // Cleaning buffers
                    memset(question, 0, sizeof(question));
                    memset(answer, 0, sizeof(answer));
                    
                    // BYE ends connection
                    if (strcmp(answer, "BYE\n") == 0)
                        break;
                }
                
                // Ending communication if:
                // interrupt signal was send to server
                if (interrupted) {
                    send(comm_socket, "BYE\n", strlen("BYE\n"), 0);
                    close(comm_socket);
                // client was closed
                } else {
                    printf("Connection to %s closed\n",str);
                    close(comm_socket);
                }
            // Save id of process
            } else {
                pid_list.push_back(pid);
                close(comm_socket);
            }
        }
        
        // Kill all child processes
        for (auto pid : pid_list) {
            kill(pid, SIGINT);
            waitpid(pid, NULL, 0);
        }

    // UDP connection
    } else if ((strcmp(mode, "udp") == 0) || (strcmp(mode, "UDP") == 0)) {
        // Creation of the socket
        if ((server_socket = socket(AF_INET, SOCK_DGRAM, 0)) <= 0) {
            fprintf(stderr, "ERROR: socket");
            return 1;
        }
        
        // Suppress the default behavior of port reservation
        optval = 1;
        setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, (const void *)&optval , sizeof(int));

        // Get address of the server to assing port
        bzero((char *) &server_address, sizeof(server_address));
        server_address.sin_family = AF_INET;
        server_address.sin_addr.s_addr = htonl(INADDR_ANY);
        server_address.sin_port = htons((unsigned short)port_number);

        if (bind(server_socket, (struct sockaddr *) &server_address, sizeof(server_address)) < 0) {
            fprintf(stderr, "ERROR: binding");
            return 1;
        }

        char question[UDP_BUFSIZE];
        memset(question, 0, sizeof(question));
        char answer[UDP_BUFSIZE];
        memset(answer, 0, sizeof(answer));
        int number;
        printf("INFO: Klient(s) connected - waiting for message.\n");
        // Solve qustions untill client ends connection or interrupt signal from server
        while(1) {   
            bool error_check = false;
            // Receive the question
            clientlen = sizeof(client_address);
            bytesrx = recvfrom(server_socket, question, UDP_BUFSIZE, 0, (struct sockaddr *)&client_address, &clientlen);
            if (bytesrx < 0)
                fprintf(stderr, "ERROR: recvfrom:");

            // Generating response
            answer[0] = 1; // Op code
            // (o x y) = at least 7 chars
            if (!example_check(&question[2]) || question[0] != 0 || question[1] < 7 || question[2] == EOF) { // wrong format
                    answer[1] = 1;
                    strcpy(&answer[3], "Could not parse the message");
            } else { // good(?) format
                number = calculate(&question[2], &error_check);
                if (error_check || number < 0) { // ERROR or negative result
                    answer[1] = 1;
                    strcpy(&answer[3], "Could not parse the message");
                } else {
                    if (intlen(number) > 255) { // check of lenght
                        answer[1] = 1;
                        strcpy(&answer[3], "Could not parse the message - too long");
                    } else {
                        answer[1] = 0;
                        sprintf(&answer[3], "%d", number);
                    }
                }
            } 
            answer[2] = strlen(&answer[3]); // Lenght
           

            // Reply with answer
            bytestx = sendto(server_socket, answer, answer[2] + 3, 0, (struct sockaddr *)&client_address, clientlen);
            if (bytestx < 0) 
                fprintf(stderr, "ERROR: sendto:");
                    
            // Cleaning buffers
            memset(question, 0, sizeof(question));
            memset(answer, 0, sizeof(answer));
        }

        return 0;

    } else {
        fprintf(stderr, "ERROR: unknown mode");
        return 1;
    }

    return 0;
}
