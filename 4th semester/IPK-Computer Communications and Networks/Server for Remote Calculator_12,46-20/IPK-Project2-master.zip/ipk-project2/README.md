Dokumentace k 2. projektu IPK  -- IOTA: Server pro vzdálenou kalkulačku </br>
Jméno a příjmení: Kateřina Čepelková</br>
Login: xcepel03

### 1 Analýza požadavků
Zadáním úlohy byla implementace serveru ke vzdálené kalkulačce v programovacím jazyku C++ pomocí gramatiky v STD 68 RFC 5234 [1] .
Klient se spouští pomocí `ipkcpd -h <host> -p <port> -m <mode>`, kde `host` je IPv4 adresa serveru, `port` je port serveru a `mode` je režim protokolu (TCP/tcp nebo UDP/udp).

Po spuštění se pomocí zadaného protokolu spustí server a přijímá série příkazů od jednoho či více klientů, kteří s ním komunikují.
Server také může reagovat na signál přerušení bezproblémovým ukončením spojení. 

Formát příkazů:
 - TCP: `HELLO`, `SOLVE expr` -> `SOLVE (<operator> <expr1> <expr2> ... <exprN)`, `BYE`
 - UDP: `expr` -> `(<operator> <expr1> <expr2> ... <exprN)`
 - operators: `+`, `-`, `*`, `/`

### 2 Teorie
Server může operovat na jednom z dvou protokolů transportní vrstvy v sadě TCP/IP -- TCP nebo UDP.
![[2] Spojeni TCP a UDP](https://info-savvy.com/wp-content/uploads/2020/06/Introduction-to-TCP-and-UDP-infosavvy-1.png)
> [2] Spojeni TCP a UDP

#### 2.1 TCP 
 - spojení point-to-point
 - garantuje spolehlivé doručování díky: [3]
    - zřetězenému přenosu segmentů
    - kumulativnímu ACK potvrzování
    - jednomu časovači znovu-zasílání
    - využívaný u aplikačních protokolů a aplikací na internetu - WWW, e-mail, SSH
    - operuje v textové variantě
#### 2.2 UDP
 - datagramová služba bez záruky doručení
 - nespojovaná služba (connection-less)
 - využívaný např. u DNS, sdílení souborů v LAN
 - operuje v binární variantě
 - Formát datagramu: [4]
  <pre>
                   0      7 8     15 16    23 24    31
                 +--------+--------+--------+--------+
                 |     Source      |   Destination   |
                 |      Port       |      Port       |
                 +--------+--------+--------+--------+
                 |                 |                 |
                 |     Length      |    Checksum     |
                 +--------+--------+--------+--------+
                 |
                 |          data octets ...
                 +---------------- ...
  </pre>
   - Formáty pro projekt:
       -  Žádost od klienta:
	  <pre>
	    0                   1                   2                   3
	    0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
	    +---------------+---------------+-------------------------------+
	    |     Opcode    |Payload Length |          Payload Data         |
	    |      (8)      |      (8)      |                               |
	    +---------------+---------------+ - - - - - - - - - - - - - - - +
	    :                     Payload Data continued ...                :
	    + - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - +
	    |                     Payload Data continued ...                |
	    +---------------------------------------------------------------+
	  </pre>
       -  Odpověď od serveru:
	   <pre>
	    0                   1                   2                   3
	    0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
	    +---------------+---------------+---------------+---------------+
	    |     Opcode    |  Status Code  |Payload Length | Payload Data  |
	    |      (8)      |      (8)      |      (8)      |               |
	    +---------------+---------------+---------------+ - - - - - - - +
	    :                     Payload Data continued ...                :
	    + - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - +
	    |                     Payload Data continued ...                |
	    +---------------------------------------------------------------+
	    </pre>

### 3 Implementace
Kód serveru v jazyce C++ standardu 20 se nachází v souboru `ipkcpd.cpp`.  Je inspirován sadou souborů demonstrujících různé způsoby implementace klient-server dodané v zadání od pana docenta Ondřeje Ryšavého (rysavy@fit.vutbr.cz) a to konkrétně implementace serveru u DemoTcp[5],  DemoUdp[6] a u DemoFork[7].

#### 3.1 Načítání parametrů
Po spuštění klienta je překontrolován počet argumentů a zkontrolováno jejich správné řazení.  Následně je z těchto argumentů získána adresa serveru a číslo portu a dále se získá z argumentů režim, ve kterém má klient operovat a podle něj se spustí přes `if` výběr správné propojení.
Režim je možné zapsat jako `TCP`/`UDP` nebo `tcp`/`udp`.

#### 3.2 TCP spojení
Z parametrů načtených při spuštění se server připojí na danou IP adresu serveru a port a vytvoří socket. Pro správnou funkčnost server je nutno potlačit výchozí chování rezervace portu. Následně se "sváže" propojení pomocí funkce `bind` a `listen` z knihovny **sys/socket.h**. Poté už server může navazovat plné spojení s klienty.

##### 3.2.1 Fork + signál přerušení
Každému klientovi je při připojení na server přiřazen vlastní dětský proces. Všechny dětské procesy jsou zároveň zapisovány do seznamu procesů `std::list<pid_t> pid_list` kvůli jejich ukončování.

Funkce `void signal_handler(int signum)` funguje na principu, že po detekci signálu přerušení nastaví `bool interrupted` na hodnotu `true`. Na tomto boolu jsou závislé oba `while` cykly, které se proto následně ukončí a všechny dětské procesy zašlou svým klientům poslední `BYE\n` zprávu a uzavřou svoje sockety `comm_socket`.  Poté se spustí `for`,  který projde celý list procesů a všechny je ukončí pomocí `kill(pid, SIGINT);`.

#####  3.2.2 Zpracování vstupů od klienta
Pro začátek komunikace očekává server od klienta zprávu `HELLO\n`. Když ji dostane nastaví se `bool handshake` na hodnotu `true` a spojení může pokračovat. Pokud ale `HELLO\n` nezíská, zašle klientovi jako odpověď `BYE\n` a ukončí spojení.

Pokud je tedy "handshake" potvrzen může se přejít na řešení příkladů. Server očekává vstup ve formátu `SOLVE expr` -> `SOLVE (<operator> <expr1> <expr2> ... <exprN)`. Pokud je tedy získána jiná hodnota je spojení ukončeno a klientovi je zasláno `BYE\n`.

Před zasláním do funkce  `calculate()` (viz Kapitola 3.4) je zpráva od klienta zbavena svého začátku (`SOLVE `) a `\n` a je zaslána do funkce `example_check()` (viz Kapitola 3.4) .  Pokud jakákoliv z těchto funkcí vrátí chybu, je znovu klientovi zasláno `BYE\n` a spojení je ukončeno. Jinak je ale získán výsledek ve formě `int`.  Ten je zkontrolován, zda není záporný (server nepodporuje záporné výsledky). Pokud touto kontrolou projde, je převeden do formátu `char[]` a před něj je umístěn řetězec `RESULT `. Takto upravený výsledek je následovně zaslán klientovi.

#### 3.3 UDP spojení
UDP spojení není potřeba řešit přes `fork()`, zvládne obsluhovat několik klientů najednou i bez úpravy. 

#####  3.3.1 Zpracování vstupů od klienta
Po načtení zprávy od klienta je zkontrolováno, zda má správný *Opcode* = 0 a zda má správný formát a to pomocí funkce `example_check()` (viz Kapitola 3.4) . Pokud něco z toho neplatí, je klientovi zaslána zpráva `Could not parse the message` s *Status code* = 1, ale spojení na rozdíl od TCP pokračuje. Dokud spojení neukončí klient nebo server přes signál přerušení.

Po výpočtu výsledku pomocí funkce `calculate()` (viz Kapitola 3.4) je tento výsledek zkontrolován, zda není záporný, či zda při výpočtu nenastala nějaká chyba -- kontrola pomocí `bool error_check`. V těchto případech je klientu zaslána zpátky zpráva `Could not parse the message` a *Status code* = 1,  jinak je mu zaslán výsledek s *Opcode* = 1, *Status code* = 0 a délkou odpovědi.

#####  3.3.3 UDP_BUFSIZE
Důvod pro zvolení velikosti `UDP_BUFSIZE` jako 259 je takový, že potřebujeme započítat bajty pro *Opcode*, *Status code* , *Payload Length*,  a byty zprávy (255 + koncová nula). Zpráva může být ale maximálně 256 (2^8) bytu velká, jelikož taková je maximální hodnota Payload Length, ale musíme ještě nechat 1 byte pro koncovou nulu zprávy, takže zpráva jako taková může mít pouze 255 bytů/znaků. 
Proto nemůže být ani výsledek příkladu delší než 259 bytů a proto je v případě přesáhnutí klientovi zaslána error zpráva se *Status code* = 1 a `Could not parse the message - too long`.

#### 3.4 Kalkulace
#####  3.4.1 bool example_check(const  char *example)
Tato funkce slouží ke kontrole správnosti gramatiky příkladu. Kontroluje, zda má příklad stejný počet pravých a levých závorek a zda se v něm nacházejí pouze povolené symboly -> `+, -, *, /, (, )` a čísla. Správnost jejich pořadí si kontroluje až funkce `calculate()`.

##### 3.4.2 int calculate(char *example, bool *error)
Funkce funguje rekurzivně pro řešení vnořených příkladů. Přijímá řetězce typu `(<operator> <expr1> <expr2> ... <exprN)`, odkud si uloží operátor.

 Následně se orientuje díky funkci `int find_start_expr(const  char *example)`, pomocí které si nalezne začátek první hodnoty -> pokud je tato hodnota číslo, pokračuje tím, že ho převede na formát  `int`. Pokud je ale tato hodnota další řetězec začínající `(` pošle ho rekurzivně do funkce `calculate` a po získání výsledku výsledek uloží jako `int` do proměnné `result`. Zároveň je využita funkce `int find_end_expr(const  char *example)` na posunutí ukazatele `pos` až za tuto, již vyhodnocenou, hodnotu.

Další hodnoty v řetězci se poté načítají až ve `while` cyklu, kde se provádí stejné vyjmutí a zhodnocení hodnoty jako u první hodnoty a tato hodnota je následně připočítána k `result` pomocí `switch`, který vybírá potřebnou operaci podle uloženého operátoru. `While` cyklus je chráněn podmínkou `(example[pos] && example[pos] != ')' && !*error)`, která ho ukončí pokud dojde na konec řetězce, dojde k  ukončení své hodnoty  `')'` a nebo je někde při výpočtu objevena chyba. 

Tentato chyba může nastat při snaze dělit nulou, nebo při špatném formátu výpočtu. Pokud k jedné z těchto chyb dojde, je z výpočtu navrácena 0 a `bool error` je nastaven na hodnotu `true`. Proto je důležité pro TCP či UDP kontrolovat `bool`, který této funkci dají do parametru.

### 4 Testování
Server byl testován na referenčním virtuálním serveru s operačním systémem Nix, přiloženém v zadání, s 64bitovým linuxovým jádrem na verzi 5.12.94 a přeložen pomocí Makefile s příkazem `g++`a parametry `-Wall -Wextra -std=c++20`. Na komunikaci byl využit mnou vytvoření klient z Projektu 1 z předmětu IPK [8].

U klienta je ukazován najednou jak `stdin` tak `stdout`.

#### 4.1 Testování propojení pomocí TCP
Sever byl spuštěn pomocí: `./ipkcpd -h localhost -p 2023 -m tcp`
Klient(i) byl(i) spuštěni(i) pomocí: `./ipkcpc -h localhost -p 2023 -m tcp`
<br>

**Ukázka jednoduchého sčítání (14 + 6), násobení (9 * 10), dělení (9 / 3) a odečítání (142 - 23) a vypnutí klienta pomocí BYE a následné vypnutí serveru interrupt signálem**
>Server:
```
New connection (maintained by 15334):
	Client address is ::ffff:127.0.0.1 and port is 56600
Connection to ::ffff:127.0.0.1 closed
Server interrupted - shutting down
```
>Klient:
```
HELLO
HELLO
SOLVE (+ 14 6)
RESULT 20
SOLVE (* 9 10)
RESULT 90
SOLVE (/ 9 3)
RESULT 3
SOLVE (- 142 23)
RESULT 119
BYE
BYE
```

**Výpočet vícehodnotového příkladu (95 + 77 + 42 + 1235 + 8), vypnutí klienta pomocí BYE a následné vypnutí serveru interrupt signálem**
>Server:
```
New connection (maintained by 15456):
	Client address is ::ffff:127.0.0.1 and port is 35550
Connection to ::ffff:127.0.0.1 closed
Server interrupted - shutting down
```
>Klient:
```
HELLO
HELLO
SOLVE (+ 95 77 42 1235 8)
RESULT 1457
BYE
BYE
```

**Výpočet složitého, vnořeného příkladu (5 * (35 - (4 - 2)), vypnutí klienta pomocí BYE a následné vypnutí serveru interrupt signálem**
>Server:
```
New connection (maintained by 15456):
	Client address is ::ffff:127.0.0.1 and port is 35550
Connection to ::ffff:127.0.0.1 closed
Server interrupted - shutting down
```
>Klient:
```
HELLO
HELLO
SOLVE (* 5 (- 35 (- 4 2)))
RESULT 165
BYE
BYE
```

**Špatný formát příkladu a následné vypnutí serveru interrupt signálem**
>Server:
```
New connection (maintained by 15479):
	Client address is ::ffff:127.0.0.1 and port is 57198
Connection to ::ffff:127.0.0.1 closed
Server interrupted - shutting down
```
>Klient:
```
HELLO
HELLO
(+ 6 5)
BYE
ERROR: Unknown request.
BYE
```

**Snaha o získání záporného výsledku a následné vypnutí serveru interrupt signálem**
>Server:
```
New connection (maintained by 15485):
	Client address is ::ffff:127.0.0.1 and port is 39616
Connection to ::ffff:127.0.0.1 closed
Server interrupted - shutting down
```
>Klient:
```
HELLO
HELLO
SOLVE (- 0 10)
BYE
ERROR: Unknown request.
BYE
```

**Snaha o dělení nulou a následné vypnutí serveru interrupt signálem**
>Server:
```
New connection (maintained by 15490):
	Client address is ::ffff:127.0.0.1 and port is 43904
Connection to ::ffff:127.0.0.1 closed
Server interrupted - shutting down
```
>Klient:
```
HELLO
HELLO
SOLVE (/ 50 0)
BYE
ERROR: Unknown request.
BYE
```

**Snaha klienta o připojení se bez úvodního "HELLO\n" a následné vypnutí serveru interrupt signálem**
>Server:
```
New connection (maintained by 15504):
	Client address is ::ffff:127.0.0.1 and port is 47184
Connection to ::ffff:127.0.0.1 closed
Server interrupted - shutting down
```
>Klient:
```
SOLVE (+ 6 9)
ERROR: Wrong init - missing HELLO.
BYE
```

**Připojení více klientů - oba klienti spuštěni zaráz a připojeni na 1 server, a následné vypnutí serveru interrupt signálem. Klient1 je ukončen sám pomocí BYE, klient 2 je odpojen po ukončení serveru.**
>Server:
```
New connection (maintained by 15526):
	Client address is ::ffff:127.0.0.1 and port is 60138
Connection to ::ffff:127.0.0.1 closed
Server interrupted - shutting down
New connection (maintained by 15524):
	Client address is ::ffff:127.0.0.1 and port is 60136
Server interrupted - shutting down
Server interrupted - shutting down
```
>Klient 1:
```
HELLO
HELLO
SOLVE (* 6 6)
RESULT 36
BYE
BYE
```
>Klient 2:
```
HELLO
HELLO
SOLVE (+ 3 5)
RESULT 8

BYE
```

#### 4.2 Testování propojení pomocí UDP
Sever byl spuštěn pomocí: `./ipkcpd -h localhost -p 2023 -m udp`
Klient(i) byl(i) spuštěn(i) pomocí: `./ipkcpc -h localhost -p 2023 -m udp`
<br>

**Ukázka jednoduchého sčítání (14 + 6), násobení (9 * 10), dělení (9 / 3) a odečítání (142 - 23)**
>Server:
```
INFO: Klient(s) connected - waiting for message.
```
>Klient:
```
(14 + 6)
OK:20
(* 9 10)
OK:90
(/ 9 3)
OK:3
(- 142 23)
OK:199
```

**Výpočet vícehodnotového příkladu (95 + 77 + 42 + 1235 + 8)**
>Server:
```
INFO: Klient(s) connected - waiting for message.
```
>Klient:
```
(+ 95 77 42 1235 8)
OK:1457
```

**Výpočet složitého, vnořeného příkladu (5 * (35 - (4 - 2))**
>Server:
```
INFO: Klient(s) connected - waiting for message.
```
>Klient:
```
(* 5 (- 35 (- 4 2)))
OK:165
```

**Špatný formát příkladu**
>Server:
```
INFO: Klient(s) connected - waiting for message.
```
>Klient:
```
SOLVE (+ 5 6)
ERR:Could not parse the message
```

**Snaha o získání záporného výsledku**
>Server:
```
INFO: Klient(s) connected - waiting for message.
```
>Klient:
```
(- 0 10)
ERR:Could not parse the message
```

**Snaha o dělení nulou**
>Server:
```
INFO: Klient(s) connected - waiting for message.
```
>Klient:
```
(/ 50 0)
ERR:Could not parse the message
```

**Připojení více klientů - oba klienti spuštěni zaráz a připojeni na 1 server**
>Server:
```
INFO: Klient(s) connected - waiting for message.
```
>Klient 1:
```
(+ 5 6)
OK:11
```
>Klient 2:
```
(* 8 4)
OK: 32
```

### 5 Bibliografie

[1] Information on STD 68 » RFC Editor. _» RFC Editor_ [online][cit. 2023-03-18]. Dostupné z: [https://www.rfc-editor.org/info/std68](https://www.rfc-editor.org/info/std68) </br>

[2] Introduction to TCP and UDP | Infosavvy Security and IT Management Training. _Infosavvy Security And Management Training 2020-21 | Info-savvy_ [online]. Copyright © 2023 [cit. 2023-03-18]. Dostupné z: [https://info-savvy.com/introduction-to-tcp-and-udp/](https://info-savvy.com/introduction-to-tcp-and-udp/) </br>

[3] RFC 793: Transmission Control Protocol . _» RFC Editor_ [online][cit. 2023-03-18]. Dostupné z: [https://www.rfc-editor.org/rfc/rfc793](https://www.rfc-editor.org/rfc/rfc793)</br>

[4] RFC 768: User Datagram Protocol . _» RFC Editor_ [online][cit. 2023-04-16]. Dostupné z: [https://www.rfc-editor.org/rfc/rfc768](https://www.rfc-editor.org/rfc/rfc768)</br>

[5] Ondrej Rysavy, IPK-Projekty/server.c at master - IPK-Projekty - FIT - VUT Brno - git. [online][cit. 2023-04-16]. Dostupné z: [https://git.fit.vutbr.cz/NESFIT/IPK-Projekty/src/branch/master/Stubs/cpp/DemoTcp/server.c](https://git.fit.vutbr.cz/NESFIT/IPK-Projekty/src/branch/master/Stubs/cpp/DemoTcp/server.c)</br>

[6] Ondrej Rysavy, IPK-Projekty/server.c at master - IPK-Projekty - FIT - VUT Brno - git. [online][cit. 2023-04-16]. Dostupné z: [https://git.fit.vutbr.cz/NESFIT/IPK-Projekty/src/branch/master/Stubs/cpp/DemoUdp/server.c](https://git.fit.vutbr.cz/NESFIT/IPK-Projekty/src/branch/master/Stubs/cpp/DemoUdp/server.c) </br>

[7] Ondrej Rysavy, IPK-Projekty/server.c at master - IPK-Projekty - FIT - VUT Brno - git. [online][cit. 2023-04-16]. Dostupné z: [https://git.fit.vutbr.cz/NESFIT/IPK-Projekty/src/branch/master/Stubs/cpp/DemoFork/server.c](https://git.fit.vutbr.cz/NESFIT/IPK-Projekty/src/branch/master/Stubs/cpp/DemoFork/server.c) </br>

[8] xcepel03, IPK-Projekt1 master - FIT - VUT Brno - git. [online][cit. 2023-04-17]. Dostupné z:  [https://git.fit.vutbr.cz/xcepel03/IPK-Project1](https://git.fit.vutbr.cz/xcepel03/IPK-Project1)