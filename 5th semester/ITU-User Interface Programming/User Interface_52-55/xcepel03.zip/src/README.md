# Aplikace Piškworky

Piškvorky jsou klasická hra pro dva hráče, kteří se střídají ve značení políček na hrací ploše. Hráč, který první vytvoří řadu tří/pěti svých značek v řadě, diagonále nebo sloupci, vyhrává.
Aplikace umožňuje i tvorbu vlastních herních map.

## Autoři
- Kateřina Čepelková (xcepel03)

- Tomáš Ebert (xebert00)

- Sára Jobranová (xjobra01)

## Pokyny k instalaci

1. Stáhněte a nainstalujte si [Qt Creator](https://www.qt.io/product/development-tools).
Postupujte podle pokynů k instalaci uvedených na webové stránce Qt.

2. Otevřete projekt v nástroji Qt Creator.
 Spusťte program Qt Creator a otevřete soubor projektu Qt (`CMakeLists.txt`) umístěný v kořenovém adresáři.

3. Nakonfigurujte nástroje potřebné pro vývoj pro Android.
Zkontrolujte, zda máte v nástroji Qt Creator nakonfigurovány potřebné sestavovací sady pro cílovou platformu Android. Podrobný návod je k dispozici v [dokumentaci Qt](https://doc.qt.io/qt-6/android-getting-started.html).

4. Vytvoření APK balíku.
Po připojení Vašeho Android zařízení zvolte správnou sestavovací sadu dle architektury procesoru zařízení a sestavte projekt. Před sestavením je potřeba zajistit, že bude výsledný balík podepsán. Klíč i certifikát lze vygenerovat pomocí Qt Creator, více informací je k dispozici v [dokumentaci Qt](https://doc.qt.io/qtcreator/creator-deploying-android.html#signing-android-packages). Aby mohl Qt Creator korektně identifikovat zařízení, je potřeba povolit v Android zařízení možnosti pro vývojáře a ladění USB.

5. Instalace na samotné zařízení se systémem Android.
Ve Vašem `build` adresáři (pojmenovaném dle zvolené sestavovací sady a typu sestavení, např. `build-ITU-Android_Qt_6_6_0_Clang_arm64_v8a-Release`) ve složce `android-build/build/outputs` a podsložce dle typu sestavení (např. `release`) se nachází vytvořený APK balík. Soubor zkopírujte do požadovaného umístění v Android zařízení. Poté stačí v Android zařízení otevřít tento soubor a postupovat dle uvedených instalačních pokynů na obrazovce. Je potřeba povolit instalaci z neznámých zdrojů.

## Použité knihovny a jejich licence

- **Qt Framework:**
  - Webové stránky: [Qt](https://www.qt.io/)
  - Licence: [Terms and Conditions](https://www.qt.io/terms-conditions/edu)

- **Modul Qt - Qt Quick**
  - Webové stránky: [Qt Quick Documentation](https://doc.qt.io/qt-6/qtquick-index.html)
  - Licence: [Terms and Conditions](https://www.qt.io/terms-conditions/edu)

- **Standardní knihovna C++**
  - Webové stránky: [C++ Reference](https://en.cppreference.com/w/cpp/header)
  - Licence: [GNU Libstdc++ License](https://gcc.gnu.org/onlinedocs/libstdc++/manual/license.html)


