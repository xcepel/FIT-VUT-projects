/*********************************************************************
 * @file  appstate.cpp
 *
 * @brief Implementation of starting state of the app
 *
 * @author xebert00
 * @date Last modified on 2023-12-17
 *********************************************************************/

#include "appstate.h"
#include "adapter.h"

AppState::AppState(Adapter* adapter, QString settingsFilePath, QString usersFilePath, QString gamesFilePath)
    : currentUser("Hráč-1"),
      settingsHandler(adapter, settingsFilePath),
      gamesHandler(adapter, gamesFilePath),
      usersFilePath(usersFilePath),
      adapter(adapter)
{
}
