/*********************************************************************
 * @file  settingshandler.h
 *
 * @brief Header file for settingshandler
 *
 * @author xcepel03
 * @date Last modified on 2023-12-17
 *********************************************************************/

#ifndef SETTINGSHANDLER_H
#define SETTINGSHANDLER_H

#include <QObject>
#include "DAL/settingsentity.h"

class Adapter;

class SettingsHandler : public QObject
{
    Q_OBJECT


public:
    explicit SettingsHandler(Adapter *adapter, QString settingsFilePath, QObject *parent = nullptr);
    
    SettingsEntity settings;

private:
    Adapter *adapter;

public slots:
    void handleSettingsDoubleClickEnabledChanged(bool newState);
    void handleSettingsHelpEnabledChanged(bool newState);
    void handleSettingsDarkModeEnabledChanged(bool newState);
    void handleSettingsSymbolTypeChanged(int newType);
    void handleSettingsSoundEnabledChanged(bool newState);
};

#endif // SETTINGSHANDLER_H
