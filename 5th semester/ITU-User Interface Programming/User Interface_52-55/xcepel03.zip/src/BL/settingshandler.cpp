/*********************************************************************
 * @file  settingshandler.cpp
 *
 * @brief Implementation of settings hadling
 *
 * @author xcepel03
 * @date Last modified on 2023-12-17
 *********************************************************************/

#include "settingshandler.h"
#include "adapter.h"

SettingsHandler::SettingsHandler(Adapter* adapter, QString settingsFilePath, QObject *parent)
    : QObject{parent},
      adapter(adapter)
{
    // Initialize connections:
    QObject::connect(adapter, &Adapter::settingsDoubleClickEnabledChanged,
                     this, &SettingsHandler::handleSettingsDoubleClickEnabledChanged);
    QObject::connect(adapter, &Adapter::settingsHelpEnabledChanged,
                     this, &SettingsHandler::handleSettingsHelpEnabledChanged);
    QObject::connect(adapter, &Adapter::settingsDarkModeEnabledChanged,
                     this, &SettingsHandler::handleSettingsDarkModeEnabledChanged);
    QObject::connect(adapter, &Adapter::settingsSymbolTypeChanged,
                     this, &SettingsHandler::handleSettingsSymbolTypeChanged);
    QObject::connect(adapter, &Adapter::settingsSoundEnabledChanged,
                     this, &SettingsHandler::handleSettingsSoundEnabledChanged);
    
    settings.setFilePath(settingsFilePath);
    settings.loadSettings();

    adapter->loadSettingsFromAppState();
}

// Handle double click settings - change to newState and saving
void SettingsHandler::handleSettingsDoubleClickEnabledChanged(bool newState)
{
    settings.doubleClickEnabled = newState;
    settings.saveSettings();
}

// Handle help settings - change to newState and saving
void SettingsHandler::handleSettingsHelpEnabledChanged(bool newState)
{
    settings.helpEnabled = newState;
    settings.saveSettings();
}

// Handle darkmode settings - change to newState and saving
void SettingsHandler::handleSettingsDarkModeEnabledChanged(bool newState)
{
    settings.darkModeEnabled = newState;
    settings.saveSettings();
}

// Handle symbol type settings - change to newType and saving
void SettingsHandler::handleSettingsSymbolTypeChanged(int newType)
{
    settings.symbolType = newType;
    settings.saveSettings();
}

// Handle sound settings - change to newState and saving
void SettingsHandler::handleSettingsSoundEnabledChanged(bool newState)
{
    settings.soundEnabled = newState;
    settings.saveSettings();
}
