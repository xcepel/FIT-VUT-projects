/*********************************************************************
 * @file  appsate.h
 *
 * @brief Header file for appstate
 *
 * @author xebert00
 * @date Last modified on 2023-12-17
 *********************************************************************/

#ifndef APPSTATE_H
#define APPSTATE_H

#include "BL/gameshandler.h"
#include "BL/settingshandler.h"
#include "DAL/userentity.h"

class Adapter;

class AppState
{
private:
    QString usersFilePath; //FIXME: will be in UserHandler
    Adapter *adapter;
public:
    AppState(Adapter *adapter, QString settingsFilePath, QString usersFilePath, QString gamesFilePath);
    SettingsHandler settingsHandler;
    GamesHandler gamesHandler;
    UserEntity currentUser;
};

#endif // APPSTATE_H
