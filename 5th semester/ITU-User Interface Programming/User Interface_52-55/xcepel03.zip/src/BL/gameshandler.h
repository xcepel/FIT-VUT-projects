/*********************************************************************
 * @file  gameshandler.h
 *
 * @brief Header file for gameshandler
 *
 * @author xcepel03, xebert00, xjobra01
 * @date Last modified on 2023-12-17
 *********************************************************************/

#ifndef GAMESHANDLER_H
#define GAMESHANDLER_H

#include "DAL/games.h"
#include <QObject>

class Adapter;

class GamesHandler : public QObject
{
    Q_OBJECT
public:
    // author - xebert00:
    explicit GamesHandler(Adapter *adapter, QString gamesFilePath, QObject *parent = nullptr);
    ~GamesHandler() override;

    Games games;
    int currentGamePlayerOnTurn;

private:
    Adapter *adapter;

    int** gameMatrix;
    GameEntity* loadedReplayGame;
    int replayTurn;

    // author - xcepel03:
    QVector<move_t> checkForWin(GameEntity game);
    void setCurrentGamePlayerOnTurn(int newOnTurn);

    // author - xjobra01:
    void loadReplayMap();
    void loadReplayResult();
    void updateGrid();

public slots:
    // author - xcepel03:
    void handleCreateGame(bool winModeThree, bool newCustomMap, uint64_t newPlayerOneUid, uint64_t newPlayerTwoUid, QVector<int> initMap);
    void handleLoadUnfinishedGame();
    void handleGameGridChanged(int x, int y);
    void handleHelp();
    void handleCurrentGameSurrender();

    // author - xebert00:
    void handleCreateMap();
    void handleGameMapGridChanged(int x, int y, int fieldType);

    // author - xjobra01:
    void handleLoadHistory();
    void handleLoadReplayGame(QString gameName);
    void handleReplayBeginning();
    void handleReplayBack();
    void handleReplayForward();
    void handleReplayEnd();
    void handleNewGameFromReplayed();

signals:
    // author - xcepel03:
    void turnChanged();
    void currentUserHasFinishedGameChanged();
    void unfinishedGameLoaded(QVector<int>& gameGrid, QVector<int>& gameMapGrid, bool winModeThree);
    void gameWon(QVector<int>& winningCombination, QString winnerName);
    void helpResult(QVector<int>& newHelpCoords);

    // author - xjobra01:
    void updatedGameNames(QVector<QString>& newGameNames);
    void replayGameLoaded(QVector<int>& gameGrid);
    void newGameFromReplayedLoaded(QVector<int>& gameGrid, bool winModeThree);
};

#endif // GAMESHANDLER_H
