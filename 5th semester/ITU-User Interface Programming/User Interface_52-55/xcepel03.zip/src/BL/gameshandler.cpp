/*********************************************************************
 * @file  gameshandler.cpp
 *
 * @brief Implementation of game hadling - managment needed for playing
 *
 * @author xcepel03, xebert00, xjobra01
 * @date Last modified on 2023-12-17
 *********************************************************************/

#include "gameshandler.h"
#include "adapter.h"

// Authors of each function are noted in the header file

GamesHandler::GamesHandler(Adapter* adapter, QString gamesFilePath, QObject *parent)
    : QObject{parent},
      adapter(adapter),
      games(gamesFilePath),
      currentGamePlayerOnTurn(0)
{
    // Initialize connections:
    QObject::connect(adapter, &Adapter::createGame,
                     this, &GamesHandler::handleCreateGame);
    QObject::connect(adapter, &Adapter::gameGridChanged,
                     this, &GamesHandler::handleGameGridChanged);
    QObject::connect(this, &GamesHandler::gameWon,
                     adapter, &Adapter::handleGameWon);
    QObject::connect(adapter, &Adapter::createMap,
                     this, &GamesHandler::handleCreateMap);
    QObject::connect(adapter, &Adapter::gameMapGridChanged,
                     this, &GamesHandler::handleGameMapGridChanged);
    QObject::connect(adapter, &Adapter::helpEnabled,
                     this, &GamesHandler::handleHelp);
    QObject::connect(this, &GamesHandler::helpResult,
                     adapter, &Adapter::handleHelpResult);
    QObject::connect(adapter, &Adapter::loadHistory,
                     this, &GamesHandler::handleLoadHistory);
    QObject::connect(this, &GamesHandler::updatedGameNames,
                     adapter, &Adapter::handleUpdatedGameNames);
    QObject::connect(adapter, &Adapter::loadReplayGame,
                     this, &GamesHandler::handleLoadReplayGame);
    QObject::connect(adapter, &Adapter::replayBeginning,
                     this, &GamesHandler::handleReplayBeginning);
    QObject::connect(adapter, &Adapter::replayBack,
                     this, &GamesHandler::handleReplayBack);
    QObject::connect(adapter, &Adapter::replayForward,
                     this, &GamesHandler::handleReplayForward);
    QObject::connect(adapter, &Adapter::replayEnd,
                     this, &GamesHandler::handleReplayEnd);
    QObject::connect(this, &GamesHandler::replayGameLoaded,
                     adapter, &Adapter::handleReplayGameLoaded);
    QObject::connect(adapter, &Adapter::newGameFromReplayed,
                     this, &GamesHandler::handleNewGameFromReplayed);
    QObject::connect(this, &GamesHandler::newGameFromReplayedLoaded,
                     adapter, &Adapter::handleNewGameFromReplayedLoaded);
    QObject::connect(this, &GamesHandler::turnChanged,
                     adapter, &Adapter::handleTurnChanged);
    QObject::connect(adapter, &Adapter::currentGameSurrender,
                     this, &GamesHandler::handleCurrentGameSurrender);
    QObject::connect(this, &GamesHandler::currentUserHasFinishedGameChanged,
                     adapter, &Adapter::handleUnfinishedGameChanged);
    QObject::connect(adapter, &Adapter::loadUnfinishedGame,
                     this, &GamesHandler::handleLoadUnfinishedGame);
    QObject::connect(this, &GamesHandler::unfinishedGameLoaded,
                     adapter, &Adapter::handleUnfinishedGameLoaded);

    // Alloc game matrix
    int matrixSize = adapter->gameGridSideLength;
    gameMatrix = new int*[matrixSize];
    for (int i = 0; i < matrixSize; i++) {
        gameMatrix[i] = new int[matrixSize];
    }
}

// Handle changing of current player on turn
void GamesHandler::setCurrentGamePlayerOnTurn(int newOnTurn)
{
    if (currentGamePlayerOnTurn != newOnTurn && newOnTurn > 0) {
        currentGamePlayerOnTurn = newOnTurn;
        emit turnChanged();
    }
}

// Handle loading of saved finished games
void GamesHandler::handleLoadHistory()
{
    QVector<QString> gameNames;

    for (const GameEntity &game : games.allGames) {
        if (game.isFinished) {
            gameNames.append(game.gameName);
        }
    }

    emit updatedGameNames(gameNames);
}

// Handle creation of game - with given stats
void GamesHandler::handleCreateGame(bool winModeThree, bool newCustomMap, uint64_t newPlayerOneUid, uint64_t newPlayerTwoUid, QVector<int> initMap)
{
    int matrixSize = adapter->gameGridSideLength;
    if (newCustomMap) {
        for (int i = 0; i < matrixSize; i++) {
            for (int j = 0; j < matrixSize; j++) {
                gameMatrix[i][j] = initMap[i * 15 + j];
            }
        }
    }
    else {
        // Creates an empty map if not specified beforehand
        for (int i = 0; i < matrixSize; i++) {
            for (int j = 0; j < matrixSize; j++) {
                gameMatrix[i][j] = 0;
            }
        }
    }
    setCurrentGamePlayerOnTurn(1);

    // Create a new game
    GameEntity newGame(winModeThree, newCustomMap, newPlayerOneUid, newPlayerTwoUid);
    if (newCustomMap) {
        for (int i = 0; i < matrixSize; i++) {
            for (int j = 0; j < matrixSize; j++) {
                if (gameMatrix[i][j] == 0) {
                }
                else if (gameMatrix[i][j] == 1) {
                    newGame.addPlayerOneField({i, j});
                }
                else if (gameMatrix[i][j] == 2) {
                    newGame.addPlayerTwoField({i, j});
                }
                else if (gameMatrix[i][j] == 3) {
                    newGame.addBlockedField({i, j});
                }
                else {
                    throw runtime_error("Field type index is invalid.");
                }
            }
        }
    }
    games.addGame(newGame);
    games.saveGames();
    adapter->appState.currentUser.unfinishedGameName = newGame.gameName;
    emit currentUserHasFinishedGameChanged();
}

// Handle loading of unfinished game for playing
void GamesHandler::handleLoadUnfinishedGame()
{
    QString gameName = adapter->appState.currentUser.unfinishedGameName;
    auto iter = std::find_if(games.allGames.begin(), games.allGames.end(), [gameName](const GameEntity& game) {
        return game.gameName == gameName;
    });

    if (iter != games.allGames.end()) {
        GameEntity loadedGame = *iter;

        // Init map as empty
        int matrixSize = adapter->gameGridSideLength;
        for (int i = 0; i < matrixSize; i++) {
            for (int j = 0; j < matrixSize; j++) {
                gameMatrix[i][j] = 0;
            }
        }

        // Load map
        for (const auto& move : loadedGame.playerOneFields) {
            gameMatrix[move.first][move.second] = 1;
        }
        for (const auto& move : loadedGame.playerTwoFields) {
            gameMatrix[move.first][move.second] = 2;
        }
        for (const auto& move : loadedGame.blockedFields) {
            gameMatrix[move.first][move.second] = 3;
        }

        QVector<int> gameMapGrid;
        for (int i = 0; i < matrixSize; ++i) {
            for (int j = 0; j < matrixSize; ++j) {
                gameMapGrid.append(gameMatrix[i][j]);
            }
        }

        // Load turns
        int turn = 0;
        for (const auto& move : loadedGame.playerOneMoves) {
            gameMatrix[move.first][move.second] = 1;
            turn++;
        }
        for (const auto& move : loadedGame.playerTwoMoves) {
            gameMatrix[move.first][move.second] = 2;
            turn++;
        }
        int playerOnTurn = ((turn % 2) == 1)? 2 : 1;
        setCurrentGamePlayerOnTurn(playerOnTurn);

        QVector<int> gameGrid;
        for (int i = 0; i < matrixSize; ++i) {
            for (int j = 0; j < matrixSize; ++j) {
                gameGrid.append(gameMatrix[i][j]);
            }
        }

        emit unfinishedGameLoaded(gameGrid, gameMapGrid, loadedGame.winModeThree);
    }
    else {
        throw runtime_error("Invalid unfinished game name: game doesn't exist.");
    }
}

// Handle for changes in game grid on given coordinates
void GamesHandler::handleGameGridChanged(int x, int y)
{
    gameMatrix[x][y] = currentGamePlayerOnTurn;

    if (currentGamePlayerOnTurn == 1) {
        games.allGames.last().addPlayerOneMove({x, y});
    }
    else if (currentGamePlayerOnTurn == 2) {
        games.allGames.last().addPlayerTwoMove({x, y});
    }
    else {
        throw runtime_error("Current player on turn's index is invalid.");
    }

    auto winningCombination = checkForWin(games.allGames.last());
    if (winningCombination.empty()) {
        games.saveGames();
        // Next player is on turn now
        int nextPlayerOnTurn = (currentGamePlayerOnTurn == 1)? 2 : 1;
        setCurrentGamePlayerOnTurn(nextPlayerOnTurn);
    }
    else { // Win
        games.allGames.last().isFinished = true;
        games.saveGames();
        QString winnerName = (currentGamePlayerOnTurn == 1)? "První" : "Druhý"; //FIXME: change to proper name loading
        // Change the vector from x,y moves to grid indices
        QVector<int> winningCombinationGridIndices;
        for (const QPair<int, int>& move : winningCombination) {
            winningCombinationGridIndices.append(move.first * 15 + move.second);
        }
        adapter->appState.currentUser.unfinishedGameName.clear();
        emit currentUserHasFinishedGameChanged();
        emit gameWon(winningCombinationGridIndices, winnerName);
    }
}

// Check for winning combinations
QVector<move_t> GamesHandler::checkForWin(GameEntity game)
{
    int matrixSize = adapter->gameGridSideLength;

    int winningLength = (game.winModeThree)? 3 : 5;

    // Search for winning combination in rows and cols
    for (int i = 0; i < matrixSize; i++) {
        QVector<move_t> row, col;
        for (int j = 0; j < matrixSize; j++) {
            // Check rows
            if (gameMatrix[i][j] == currentGamePlayerOnTurn) {
                row.append({i, j});
                if (row.size() == winningLength) {
                    return row;
                }
            }
            else {
                row.clear();
            }
            // Check columns
            if (gameMatrix[j][i] == currentGamePlayerOnTurn) {
                col.append({j, i});
                if (col.size() == winningLength) {
                    return col;
                }
            }
            else {
                col.clear();
            }
        }
    }

    // Check diagonals from right top to left bottom
    QVector<move_t> diagMain;
    for (int row = 0; row < matrixSize; row++) {
        for (int col = 0; col < matrixSize; col++) {
            if (gameMatrix[row][col] == currentGamePlayerOnTurn) {
                int count = 0;

                // Check diagonal
                for (int k = 0; k < winningLength; k++) {
                    if (row + k < matrixSize && col - k >= 0 && gameMatrix[row + k][col - k] == currentGamePlayerOnTurn) {
                        count++;
                    } else {
                        break;
                    }
                }

                if (count == winningLength) { //found
                    for (int k = 0; k < winningLength; k++) {
                        diagMain.append({row + k, col - k});
                    }
                    return diagMain;
                }
            }
        }
    }

    // Check diagonals from left top to right bottom
    QVector<move_t> diagReverse;
    for (int row = 0; row < matrixSize; row++) {
        for (int col = 0; col < matrixSize; col++) {
            if (gameMatrix[row][col] == currentGamePlayerOnTurn) {
                int count = 0;

                // Check reverse diagonal
                for (int k = 0; k < winningLength; k++) {
                    if (row + k < matrixSize && col + k < matrixSize && gameMatrix[row + k][col + k] == currentGamePlayerOnTurn) {
                        count++;
                    } else {
                        break;
                    }
                }

                if (count == winningLength) { // found
                    for (int k = 0; k < winningLength; k++) {
                        diagReverse.append({row + k, col + k});
                    }
                    return diagReverse;
                }
            }
        }
    }

    return QVector<move_t>();
}

// Handle surrendering of game
void GamesHandler::handleCurrentGameSurrender()
{
    games.allGames.last().isFinished = true;
    adapter->appState.currentUser.unfinishedGameName.clear();
    emit currentUserHasFinishedGameChanged();
}

// Handle creating map grid
void GamesHandler::handleCreateMap()
{
    int matrixSize = adapter->gameGridSideLength;
    for (int i = 0; i < matrixSize; i++) {
        for (int j = 0; j < matrixSize; j++) {
            gameMatrix[i][j] = 0;
        }
    }
}

// If valid, place fieldType on coords x,y in gameGrid
void GamesHandler::handleGameMapGridChanged(int x, int y, int fieldType)
{
    if (fieldType >= 0 && fieldType <= 3) {
        gameMatrix[x][y] = fieldType;
    }
    else {
        throw runtime_error("Field type index is invalid.");
    }
}

// Handles replaying of saved games
void GamesHandler::handleLoadReplayGame(QString gameName)
{
    auto iter = std::find_if(games.allGames.begin(), games.allGames.end(), [gameName](const GameEntity& game) {
        return game.gameName == gameName;
    });

    if (iter != games.allGames.end()) {
        loadedReplayGame = &(*iter);

        // Init map
        int matrixSize = adapter->gameGridSideLength;
        for (int i = 0; i < matrixSize; i++) {
            for (int j = 0; j < matrixSize; j++) {
                gameMatrix[i][j] = 0;
            }
        }

        setCurrentGamePlayerOnTurn(1);
        replayTurn = 0;

        loadReplayMap();
    }
    else {
        throw runtime_error("Invalid historic game name: game doesn't exist.");
    }
}

// Updates game grid acording to saved matrix
void GamesHandler::updateGrid()
{
    int matrixSize = adapter->gameGridSideLength;
    QVector<int> gameGrid;
    for (int i = 0; i < matrixSize; ++i) {
        for (int j = 0; j < matrixSize; ++j) {
            gameGrid.append(gameMatrix[i][j]);
        }
    }
    emit replayGameLoaded(gameGrid);
}

// Loads map for replaying
void GamesHandler::loadReplayMap()
{
    replayTurn = 0;
    setCurrentGamePlayerOnTurn(1);

    handleCreateMap();

    for (const auto& move : loadedReplayGame->playerOneFields) {
        gameMatrix[move.first][move.second] = 1;
    }
    for (const auto& move : loadedReplayGame->playerTwoFields) {
        gameMatrix[move.first][move.second] = 2;
    }
    for (const auto& move : loadedReplayGame->blockedFields) {
        gameMatrix[move.first][move.second] = 3;
    }

    updateGrid();
    QVector<int> winMovesEmpty;
    emit gameWon(winMovesEmpty, ""); // No one could win at the start
}

// Handle steps in replay
void GamesHandler::loadReplayResult()
{
    replayTurn = 0;

    for (const auto& move : loadedReplayGame->playerOneMoves) {
        gameMatrix[move.first][move.second] = 1;
        replayTurn++;
    }
    for (const auto& move : loadedReplayGame->playerTwoMoves) {
        gameMatrix[move.first][move.second] = 2;
        replayTurn++;
    }
    for (const auto& move : loadedReplayGame->playerOneFields) {
        gameMatrix[move.first][move.second] = 1;
    }
    for (const auto& move : loadedReplayGame->playerTwoFields) {
        gameMatrix[move.first][move.second] = 2;
    }
    for (const auto& move : loadedReplayGame->blockedFields) {
        gameMatrix[move.first][move.second] = 3;
    }

    auto winningCombination = checkForWin(*loadedReplayGame);
    if (winningCombination.empty()) {
        // Should never get here - only if we allow not finished games in history
        QVector<int> winMovesEmpty;
        emit gameWon(winMovesEmpty, "");
    }
    else { // Win
        QString winnerName = (currentGamePlayerOnTurn == 1)? "První" : "Druhý"; //FIXME: change to proper name loading
        // Change the vector from x,y moves to grid indices
        QVector<int> winningCombinationGridIndices;
        for (const QPair<int, int>& move : winningCombination) {
            winningCombinationGridIndices.append(move.first * 15 + move.second);
        }
        emit gameWon(winningCombinationGridIndices, winnerName);
    }
    int nextPlayerOnTurn = (currentGamePlayerOnTurn == 1)? 2 : 1;
    setCurrentGamePlayerOnTurn(nextPlayerOnTurn);
    updateGrid();
}

// Return begining of replay
void GamesHandler::handleReplayBeginning()
{
    if (replayTurn != 0) {
        loadReplayMap();
    }
}

// Handle step back in replay
void GamesHandler::handleReplayBack()
{
    if (replayTurn != 0) {
        move_t previousMove;
        if (currentGamePlayerOnTurn == 1) {
            previousMove = loadedReplayGame->playerTwoMoves[(replayTurn - 2) / 2];
        }
        else {
            previousMove = loadedReplayGame->playerOneMoves[(replayTurn - 1) / 2];
        }
        gameMatrix[previousMove.first][previousMove.second] = 0;
        int nextPlayerOnTurn = (currentGamePlayerOnTurn == 1)? 2 : 1;
        setCurrentGamePlayerOnTurn(nextPlayerOnTurn);
        replayTurn--;

        updateGrid();

        QVector<int> winMovesEmpty;
        emit gameWon(winMovesEmpty, ""); // No one could win when there are more turns left
    }
}

// Handle step forward in replay
void GamesHandler::handleReplayForward()
{
    if (replayTurn < (loadedReplayGame->playerOneMoves.length() + loadedReplayGame->playerTwoMoves.length())) {
        move_t nextMove;
        if (currentGamePlayerOnTurn == 1) {
            nextMove = loadedReplayGame->playerOneMoves[replayTurn / 2];
            gameMatrix[nextMove.first][nextMove.second] = 1;
        }
        else {
            nextMove = loadedReplayGame->playerTwoMoves[(replayTurn - 1) / 2];
            gameMatrix[nextMove.first][nextMove.second] = 2;
        }

        auto winningCombination = checkForWin(*loadedReplayGame);
        if (winningCombination.empty()) {
            QVector<int> winMovesEmpty;
            emit gameWon(winMovesEmpty, "");
        }
        else { // Win
            QString winnerName = (currentGamePlayerOnTurn == 1)? "První" : "Druhý"; //FIXME: change to proper name loading
            // Change the vector from x,y moves to grid indices
            QVector<int> winningCombinationGridIndices;
            for (const QPair<int, int>& move : winningCombination) {
                winningCombinationGridIndices.append(move.first * 15 + move.second);
            }
            emit gameWon(winningCombinationGridIndices, winnerName);
        }
        int nextPlayerOnTurn = (currentGamePlayerOnTurn == 1)? 2 : 1;
        setCurrentGamePlayerOnTurn(nextPlayerOnTurn);
        replayTurn++;

        updateGrid();
    }
}

// Return end of replay
void GamesHandler::handleReplayEnd()
{
    if (replayTurn < (loadedReplayGame->playerOneMoves.length() + loadedReplayGame->playerTwoMoves.length())) {
        loadReplayResult();
    }
}

// Handle creation of new game from one point in replay
void GamesHandler::handleNewGameFromReplayed()
{
    int matrixSize = adapter->gameGridSideLength;
    QVector<int> gameGrid;
    for (int i = 0; i < matrixSize; ++i) {
        for (int j = 0; j < matrixSize; ++j) {
            gameGrid.append(gameMatrix[i][j]);
        }
    }

    emit newGameFromReplayedLoaded(gameGrid, loadedReplayGame->winModeThree);
}

// Handle notice of possible loss
// could not finish implementation
//void GamesHandler::handleLoseHelp()
//{
//    int matrixSize = adapter->gameGridSideLength;

//    int winningLength = (games.allGames.last().winModeThree)? 3 : 5;

//    QVector<move_t> loseRisk;

//    int enemyPlayer = (currentGamePlayerOnTurn == 1) ? 2 : 1;
//    for (int i = 0; i < matrixSize; i++) {
//        for (int j = 0; j < matrixSize; j++) {
//            //4 in row
//            if (j < matrixSize - 3 && gameMatrix[i][j] == enemyPlayer && gameMatrix[i][j + 1] == enemyPlayer
//                && gameMatrix[i][j + 2] == enemyPlayer && gameMatrix[i][j + 3] == enemyPlayer) {
//                if (j > 0 && gameMatrix[i][j - 1] == 0) {
//                    loseRisk.append({i, j - 1});
//                }
//                if (j + 4 < matrixSize && gameMatrix[i][j + 4] == 0) {
//                    loseRisk.append({i, j + 4});
//                }
//            }

//            // 4 in col
//            if (i < matrixSize - 3 && gameMatrix[i][j] == enemyPlayer && gameMatrix[i + 1][j] == enemyPlayer
//                && gameMatrix[i + 2][j] == enemyPlayer && gameMatrix[i + 3][j] == enemyPlayer) {
//                if (i > 0 && gameMatrix[i - 1][j] == 0) {
//                    loseRisk.append({i - 1, j});
//                }
//                if (i + 4 < matrixSize && gameMatrix[i + 4][j] == 0) {
//                    loseRisk.append({i + 4, j});
//                }
//            }

//            // 4 in diagonal (top-left to bottom-right)
//            if (i < matrixSize - 3 && j < matrixSize - 3 && gameMatrix[i][j] == enemyPlayer &&
//                gameMatrix[i + 1][j + 1] == enemyPlayer &&
//                gameMatrix[i + 2][j + 2] == enemyPlayer &&
//                gameMatrix[i + 3][j + 3] == enemyPlayer) {
//                if (i > 0 && j > 0 && gameMatrix[i - 1][j - 1] == 0) {
//                    loseRisk.append({i - 1, j - 1});
//                }
//                if (i + 4 < matrixSize && j + 4 < matrixSize && gameMatrix[i + 4][j + 4] == 0) {
//                    loseRisk.append({i + 4, j + 4});
//                }
//            }

//            // 4 in diagonal (top-right to bottom-left)
//            if (i < matrixSize - 3 && j >= 3 && gameMatrix[i][j] == enemyPlayer &&
//                gameMatrix[i + 1][j - 1] == enemyPlayer &&
//                gameMatrix[i + 2][j - 2] == enemyPlayer &&
//                gameMatrix[i + 3][j - 3] == enemyPlayer) {
//                if (i > 0 && j + 1 < matrixSize && gameMatrix[i - 1][j + 1] == 0) {
//                    loseRisk.append({i - 1, j + 1});
//                }
//                if (i + 4 < matrixSize && j - 4 >= 0 && gameMatrix[i + 4][j - 4] == 0) {
//                    loseRisk.append({i + 4, j - 4});
//                }
//            }
//        }
//    }

//    QVector<int> loseRiskGridIndices;
//    for (const QPair<int, int>& move : loseRisk) {
//        loseRiskGridIndices.append(move.first * 15 + move.second);
//    }
//    emit helpResult(loseRiskGridIndices);
//}

// Handle of help in game
void GamesHandler::handleHelp()
{
    int matrixSize = adapter->gameGridSideLength;

    int winningLength = (games.allGames.last().winModeThree)? 3 : 5;

    QVector<move_t> helpFound;

    // Rows + Columns
    for (int i = 0; i < matrixSize; i++) {
        for (int j = 0; j < matrixSize; j++) {
            // Row
            //4 in row
            if (j < matrixSize - 3 && gameMatrix[i][j] == currentGamePlayerOnTurn && gameMatrix[i][j + 1] == currentGamePlayerOnTurn
                && gameMatrix[i][j + 2] == currentGamePlayerOnTurn && gameMatrix[i][j + 3] == currentGamePlayerOnTurn) {
                if (j > 0 && gameMatrix[i][j - 1] == 0) {
                    helpFound.append({i, j - 1});
                }
                if (j + 4 < matrixSize && gameMatrix[i][j + 4] == 0) {
                    helpFound.append({i, j + 4});
                }
            }
            // 3 in row
            if (j < matrixSize - 2 && gameMatrix[i][j] == currentGamePlayerOnTurn && gameMatrix[i][j + 1] == currentGamePlayerOnTurn
                && gameMatrix[i][j + 2] == currentGamePlayerOnTurn) {
                if (j > 0 && gameMatrix[i][j - 1] == 0) {
                    helpFound.append({i, j - 1});
                }
                if (j + 3 < matrixSize && gameMatrix[i][j + 3] == 0) {
                    helpFound.append({i, j + 3});
                }
            }
            // for 3 wins - 2 in row
            if (winningLength == 3 && gameMatrix[i][j] == currentGamePlayerOnTurn && gameMatrix[i][j + 1] == currentGamePlayerOnTurn) {
                if (j > 0 && gameMatrix[i][j - 1] == 0) {
                    helpFound.append({i, j - 1});
                }
                if (j + 3 < matrixSize && gameMatrix[i][j + 2] == 0) {
                    helpFound.append({i, j + 2});
                }
            }

            // Col
            // 4 in col
            if (i < matrixSize - 3 && gameMatrix[i][j] == currentGamePlayerOnTurn && gameMatrix[i + 1][j] == currentGamePlayerOnTurn
                && gameMatrix[i + 2][j] == currentGamePlayerOnTurn && gameMatrix[i + 3][j] == currentGamePlayerOnTurn) {
                if (i > 0 && gameMatrix[i - 1][j] == 0) {
                    helpFound.append({i - 1, j});
                }
                if (i + 4 < matrixSize && gameMatrix[i + 4][j] == 0) {
                    helpFound.append({i + 4, j});
                }
            }
            // 3 in col
            if (i < matrixSize - 3 && gameMatrix[i][j] == currentGamePlayerOnTurn && gameMatrix[i + 1][j] == currentGamePlayerOnTurn
                && gameMatrix[i + 2][j] == currentGamePlayerOnTurn) {
                if (i > 0 && gameMatrix[i - 1][j] == 0) {
                    helpFound.append({i - 1, j});
                }
                if (i + 3 < matrixSize && gameMatrix[i + 3][j] == 0) {
                    helpFound.append({i + 3, j});
                }
            }
            // for 3 wins - 2 in col
            if (winningLength == 3 && gameMatrix[i][j] == currentGamePlayerOnTurn && gameMatrix[i + 1][j] == currentGamePlayerOnTurn) {
                if (j > 0 && gameMatrix[i - 1][j] == 0) {
                    helpFound.append({i - 1, j});
                }
                if (j + 3 < matrixSize && gameMatrix[i + 2][j] == 0) {
                    helpFound.append({i + 2, j});
                }
            }

            // Diagonals
            // 4 in diagonal (top-left to bottom-right)
            if (i < matrixSize - 3 && j < matrixSize - 3 && gameMatrix[i][j] == currentGamePlayerOnTurn &&
                gameMatrix[i + 1][j + 1] == currentGamePlayerOnTurn &&
                gameMatrix[i + 2][j + 2] == currentGamePlayerOnTurn &&
                gameMatrix[i + 3][j + 3] == currentGamePlayerOnTurn) {
                if (i > 0 && j > 0 && gameMatrix[i - 1][j - 1] == 0) {
                    helpFound.append({i - 1, j - 1});
                }
                if (i + 4 < matrixSize && j + 4 < matrixSize && gameMatrix[i + 4][j + 4] == 0) {
                    helpFound.append({i + 4, j + 4});
                }
            }
            // 3 in diagonal (top-left to bottom-right)
            if (i < matrixSize - 2 && j < matrixSize - 2 && gameMatrix[i][j] == currentGamePlayerOnTurn &&
                gameMatrix[i + 1][j + 1] == currentGamePlayerOnTurn &&
                gameMatrix[i + 2][j + 2] == currentGamePlayerOnTurn) {
                if (i > 0 && j > 0 && gameMatrix[i - 1][j - 1] == 0) {
                    helpFound.append({i - 1, j - 1});
                }
                if (i + 3 < matrixSize && j + 3 < matrixSize && gameMatrix[i + 3][j + 3] == 0) {
                    helpFound.append({i + 3, j + 3});
                }
            }
            // for 3 wins - 2 in diagonal (top-left to bottom-right)
            if (winningLength == 3 && i < matrixSize - 1 && j < matrixSize - 1 && gameMatrix[i][j] == currentGamePlayerOnTurn &&
                gameMatrix[i + 1][j + 1] == currentGamePlayerOnTurn) {
                if (i > 0 && j > 0 && gameMatrix[i - 1][j - 1] == 0) {
                    helpFound.append({i - 1, j - 1});
                }
                if (i + 2 < matrixSize && j + 2 < matrixSize && gameMatrix[i + 2][j + 2] == 0) {
                    helpFound.append({i + 2, j + 2});
                }
            }

            // 4 in diagonal (top-right to bottom-left)
            if (i < matrixSize - 3 && j >= 3 && gameMatrix[i][j] == currentGamePlayerOnTurn &&
                gameMatrix[i + 1][j - 1] == currentGamePlayerOnTurn &&
                gameMatrix[i + 2][j - 2] == currentGamePlayerOnTurn &&
                gameMatrix[i + 3][j - 3] == currentGamePlayerOnTurn) {
                if (i > 0 && j + 1 < matrixSize && gameMatrix[i - 1][j + 1] == 0) {
                    helpFound.append({i - 1, j + 1});
                }
                if (i + 4 < matrixSize && j - 4 >= 0 && gameMatrix[i + 4][j - 4] == 0) {
                    helpFound.append({i + 4, j - 4});
                }
            }
            // 3 in diagonal (top-right to bottom-left)
            if (i < matrixSize - 2 && j >= 2 && gameMatrix[i][j] == currentGamePlayerOnTurn &&
                gameMatrix[i + 1][j - 1] == currentGamePlayerOnTurn &&
                gameMatrix[i + 2][j - 2] == currentGamePlayerOnTurn) {
                if (i > 0 && j + 1 < matrixSize && gameMatrix[i - 1][j + 1] == 0) {
                    helpFound.append({i - 1, j + 1});
                }
                if (i + 3 < matrixSize && j - 3 >= 0 && gameMatrix[i + 3][j - 3] == 0) {
                    helpFound.append({i + 3, j - 3});
                }
            }
            // for 3 wins - 2 in diagonal (top-right to bottom-left)
            if (winningLength == 3 && i < matrixSize - 1 && j >= 1 && gameMatrix[i][j] == currentGamePlayerOnTurn &&
                gameMatrix[i + 1][j - 1] == currentGamePlayerOnTurn) {
                if (i > 0 && j + 1 < matrixSize && gameMatrix[i - 1][j + 1] == 0) {
                    helpFound.append({i - 1, j + 1});
                }
                if (i + 2 < matrixSize && j - 2 >= 0 && gameMatrix[i + 2][j - 2] == 0) {
                    helpFound.append({i + 2, j - 2});
                }
            }
        }
    }

    QVector<int> helpFoundGridIndices;
    for (const QPair<int, int>& move :  helpFound) {
        helpFoundGridIndices.append(move.first * 15 + move.second);
    }
    emit helpResult(helpFoundGridIndices);
}

// Destructor of game
GamesHandler::~GamesHandler()
{
    int rows = adapter->gameGridSideLength;
    for (int i = 0; i < rows; ++i) {
        delete[] gameMatrix[i];
    }
    delete[] gameMatrix;
}
