/*********************************************************************
 * @file  adapter.cpp
 *
 * @brief Implementation of adapter (connecting View and Model)
 *
 * @author xcepel03, xebert00, xjobra01
 * @date Last modified on 2023-12-17
 *********************************************************************/

#include "adapter.h"

// Authors of each function are noted in the header file

Adapter::Adapter(QString settingsFilePath, QString usersFilePath, QString gamesFilePath, QObject *parent)
    : QObject{parent},
      appState(this, settingsFilePath, usersFilePath, gamesFilePath)
{
}

// Load settings from app and store them as within the Adapter
void Adapter::loadSettingsFromAppState()
{
    m_settingsDoubleClickEnabled = appState.settingsHandler.settings.doubleClickEnabled;
    m_settingsHelpEnabled = appState.settingsHandler.settings.helpEnabled;
    m_settingsDarkModeEnabled = appState.settingsHandler.settings.darkModeEnabled;
    m_settingsSymbolType = appState.settingsHandler.settings.symbolType;
    m_settingsSoundEnabled = appState.settingsHandler.settings.soundEnabled;
}

// Check if current user has an unfinished game
bool Adapter::hasUnfinishedGame()
{
    bool Result = true;
    if (appState.currentUser.unfinishedGameName.isEmpty()) {
        Result = false;
    }
    return Result;
}

// Emit signal signaling that unfinished game has changed its state
void Adapter::handleUnfinishedGameChanged()
{
    emit hasUnfinishedGameChanged();
}

// Return name of current active user
QString Adapter::currentUserName()
{
    return appState.currentUser.nickname;
}

// Change current active users name to newName
void Adapter::setCurrentUserName(QString newName)
{
    if (newName != m_currentUserName) {
        m_currentUserName = newName;
        emit currentUserNameChanged();
    }
}

// Return state of double click
bool Adapter::settingsDoubleClickEnabled()
{
    return m_settingsDoubleClickEnabled;
}

// Change settings state of double click to newState
void Adapter::setSettingsDoubleClickEnabled(bool newState)
{
    if (newState != m_settingsDoubleClickEnabled) {
        m_settingsDoubleClickEnabled = newState;
        emit settingsDoubleClickEnabledChanged(newState);
    }
}

// Return state of settings help
bool Adapter::settingsHelpEnabled()
{
    return m_settingsHelpEnabled;
}

// Change settings state of settings help to newState
void Adapter::setSettingsHelpEnabled(bool newState)
{
    if (newState != m_settingsHelpEnabled) {
        m_settingsHelpEnabled = newState;
        emit settingsHelpEnabledChanged(newState);
    }
}

// Returns state of dark mode settings
bool Adapter::settingsDarkModeEnabled()
{
    return m_settingsDarkModeEnabled;
}

// Change settings state of dark mode to newState
void Adapter::setSettingsDarkModeEnabled(bool newState)
{
    if (newState != m_settingsDarkModeEnabled) {
        m_settingsDarkModeEnabled = newState;
        emit settingsDarkModeEnabledChanged(newState);
    }
}

// Return current chosen symbol type
int Adapter::settingsSymbolType()
{
    return m_settingsSymbolType;
}

// Change settings state of symbol type to newType
void Adapter::setSettingsSymbolType(int newType)
{
    if (newType != m_settingsSymbolType) {
        m_settingsSymbolType = newType;
        emit settingsSymbolTypeChanged(newType);
    }
}

// Return current chosen setting state for sound
bool Adapter::settingsSoundEnabled()
{
    return m_settingsSoundEnabled;
}

// Change settings state of sound to newState
void Adapter::setSettingsSoundEnabled(bool newState)
{
    if (newState != m_settingsSoundEnabled) {
        m_settingsSoundEnabled = newState;
        emit settingsSoundEnabledChanged(newState);
    }
}

// Return size of the grid
int Adapter::gameGridSize()
{
    return gameGridSideLength;
}

// Emit signal needed for creation of new game with given stats
void Adapter::emitCreateGame(bool winModeThree, bool customMap, uint64_t playerTwoUid)
{
    QVector<int> initMap;
    if (customMap) {
        m_gameGrid = m_gameMapGrid;
        initMap = m_gameMapGrid;
    }
    else {
        // Initialize grid if not specified beforehand and clear map
        m_gameGrid.fill(0, gameGridSideLength * gameGridSideLength);
        m_gameMapGrid.fill(0, gameGridSideLength * gameGridSideLength);
    }
    m_helpCoords.clear();
    emit helpCoordsChanged();
    m_winningCombination.clear();
    emit winningCombinationChanged();
    emit createGame(winModeThree, customMap, appState.currentUser.uid, playerTwoUid, initMap);
}

// Return game grid
QVector<int> Adapter::gameGrid()
{
    return m_gameGrid;
}

// Set symbol of current player on turn into gridIndex of gameGrid
void Adapter::setGameGrid(int gridIndex)
{
    if (m_gameGrid[gridIndex] == 0) {
        m_gameGrid[gridIndex] = appState.gamesHandler.currentGamePlayerOnTurn;
        m_helpCoords.clear();
        emit helpCoordsChanged();
        emit gameGridChanged(gridIndex / gameGridSideLength, gridIndex % gameGridSideLength);
    }
}

// Return lenght of winningCombination needed to win the game
QVector<int> Adapter::winningCombination()
{
    return m_winningCombination;
}

// Return name of the winner
QString Adapter::winnerName()
{
    return m_winnerName;
}

// Handle processing of won/ended game
void Adapter::handleGameWon(QVector<int>& winningCombination, QString winnerName)
{
    m_winningCombination = winningCombination;
    m_winnerName = winnerName;
    emit winningCombinationChanged();
    emit winnerNameChanged();
}

// Send signal for creating game map
void Adapter::emitCreateMap()
{
    m_gameMapGrid.fill(0, gameGridSideLength * gameGridSideLength);
    emit createMap();
}

// Return gameMapGrid
QVector<int> Adapter::gameMapGrid()
{
    return m_gameMapGrid;
}

// Set new fieldType into gridIndex in gameGrid
void Adapter::setGameMapGrid(int gridIndex, int fieldType)
{
    if ((fieldType > 0 && m_gameMapGrid[gridIndex] == 0) || (fieldType == 0 && m_gameMapGrid[gridIndex] != 0)) {
        m_gameMapGrid[gridIndex] = fieldType;
        emit gameMapGridChanged(gridIndex / gameGridSideLength, gridIndex % gameGridSideLength, fieldType);
    }
}

// Emit helping coordinantes
void Adapter::emitHelp()
{
    if (m_helpCoords.isEmpty()) {
        emit helpEnabled();
    } else {
        m_helpCoords.clear();
        emit helpCoordsChanged();
    }
}

// Return helping coordinanetes
QVector<int> Adapter::helpCoords()
{
    return m_helpCoords;
}

// Handle change of help results
void Adapter::handleHelpResult(QVector<int>& newHelpCoords)
{
    m_helpCoords = newHelpCoords;
    emit helpCoordsChanged();
}

// Return list of all played games
QStringList Adapter::replayGameNames()
{
    return QStringList(m_replayGameNames.begin(), m_replayGameNames.end());
}

// Handle change/update of list of all game names
void Adapter::handleUpdatedGameNames(QVector<QString>& newGameNames)
{
    m_replayGameNames = newGameNames;
    emit replayGameNamesChanged();
}

// Emit signal for replaying chosen game (with gameName)
void Adapter::emitLoadReplayGame(QString gameName)
{
    // Clear all
    m_gameGrid.fill(0, gameGridSideLength * gameGridSideLength);
    m_gameMapGrid.fill(0, gameGridSideLength * gameGridSideLength);
    m_gameReplayGrid.fill(0, gameGridSideLength * gameGridSideLength);
    m_winningCombination.clear();
    emit loadReplayGame(gameName);
}

// Return replay grid
QVector<int> Adapter::gameReplayGrid()
{
    return m_gameReplayGrid;
}

// Emit signal for loaded replay
void Adapter::handleReplayGameLoaded(QVector<int>& gameGrid)
{
    m_gameReplayGrid = gameGrid;
    emit gameReplayGridChanged();
}

// Handle creating new game from chosen point in replay with stats from replay
void Adapter::handleNewGameFromReplayedLoaded(QVector<int>& gameGrid, bool winModeThree)
{
    m_gameGrid = gameGrid;
    m_gameMapGrid = gameGrid;
    m_loadedGameModes.clear();
    m_loadedGameModes << winModeThree << true;
    emit loadedGameModesChanged();
}

// Return loaded game mode
QVector<bool> Adapter::loadedGameModes()
{
    return m_loadedGameModes;
}

// Return current player on turn
int Adapter::currentPlayerOnTurn()
{
    return appState.gamesHandler.currentGamePlayerOnTurn;
}

// Handle change of current player on turn
void Adapter::handleTurnChanged()
{
    emit currentPlayerOnTurnChanged();
}

// Handle if loading of unfinished game
void Adapter::handleUnfinishedGameLoaded(QVector<int>& gameGrid, QVector<int>& gameMapGrid, bool winModeThree)
{
    m_gameGrid = gameGrid;
    m_gameMapGrid = gameMapGrid;
    m_loadedGameModes.clear();
    m_loadedGameModes << winModeThree << (gameMapGrid.length() > 0);
    emit loadedGameModesChanged();
}
