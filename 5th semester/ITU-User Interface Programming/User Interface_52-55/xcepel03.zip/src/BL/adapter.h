/*********************************************************************
 * @file  adapter.h
 *
 * @brief Header file for adapter (connecting View and Model)
 *
 * @author xcepel03, xebert00, xjobra01
 * @date Last modified on 2023-12-17
 *********************************************************************/

#ifndef ADAPTER_H
#define ADAPTER_H

#include <QObject>
#include <QStandardPaths>
#include <QStringList>
#include "appstate.h"

class Adapter : public QObject
{
    Q_OBJECT
    // author - xcepel03:
    Q_PROPERTY(bool hasUnfinishedGame READ hasUnfinishedGame NOTIFY hasUnfinishedGameChanged FINAL)
    Q_PROPERTY(int gameGridSize READ gameGridSize CONSTANT)
    Q_PROPERTY(QVector<int> gameGrid READ gameGrid NOTIFY gameGridChanged FINAL)
    Q_PROPERTY(QVector<int> winningCombination READ winningCombination NOTIFY winningCombinationChanged)
    Q_PROPERTY(QString winnerName READ winnerName NOTIFY winnerNameChanged FINAL)
    Q_PROPERTY(int currentPlayerOnTurn READ currentPlayerOnTurn NOTIFY currentPlayerOnTurnChanged FINAL)
    Q_PROPERTY(QVector<int> helpCoords READ helpCoords NOTIFY helpCoordsChanged)

    Q_PROPERTY(bool settingsDoubleClickEnabled READ settingsDoubleClickEnabled WRITE setSettingsDoubleClickEnabled NOTIFY settingsDoubleClickEnabledChanged FINAL)
    Q_PROPERTY(bool settingsHelpEnabled READ settingsHelpEnabled WRITE setSettingsHelpEnabled NOTIFY settingsHelpEnabledChanged FINAL)
    Q_PROPERTY(bool settingsDarkModeEnabled READ settingsDarkModeEnabled WRITE setSettingsDarkModeEnabled NOTIFY settingsDarkModeEnabledChanged FINAL)
    Q_PROPERTY(int settingsSymbolType READ settingsSymbolType WRITE setSettingsSymbolType NOTIFY settingsSymbolTypeChanged FINAL)
    Q_PROPERTY(bool settingsSoundEnabled READ settingsSoundEnabled WRITE setSettingsSoundEnabled NOTIFY settingsSoundEnabledChanged FINAL)

    // author - xebert00:
    Q_PROPERTY(QString currentUserName READ currentUserName WRITE setCurrentUserName NOTIFY currentUserNameChanged FINAL)
    Q_PROPERTY(QVector<int> gameMapGrid READ gameMapGrid NOTIFY gameMapGridChanged FINAL)

    // author - xjobra01:
    Q_PROPERTY(QStringList replayGameNames READ replayGameNames NOTIFY replayGameNamesChanged)
    Q_PROPERTY(QVector<int> gameReplayGrid READ gameReplayGrid NOTIFY gameReplayGridChanged FINAL)
    Q_PROPERTY(QVector<bool> loadedGameModes READ loadedGameModes NOTIFY loadedGameModesChanged FINAL)

public:
    // author - xebert00:
    explicit Adapter(QString settingsFilePath, QString usersFilePath, QString gamesFilePath, QObject *parent = nullptr);

    AppState appState;
    static const int gameGridSideLength = 15;

    // author - xcepel03:
    void loadSettingsFromAppState();
    bool settingsDoubleClickEnabled();
    void setSettingsDoubleClickEnabled(bool newState);
    bool settingsHelpEnabled();
    void setSettingsHelpEnabled(bool newState);
    bool settingsDarkModeEnabled();
    void setSettingsDarkModeEnabled(bool newState);
    int settingsSymbolType();
    void setSettingsSymbolType(int newType);
    bool settingsSoundEnabled();
    void setSettingsSoundEnabled(bool newState);

    int gameGridSize();
    Q_INVOKABLE void emitCreateGame(bool winModeThree, bool customMap, uint64_t playerTwoUid);
    QVector<int> gameGrid();
    Q_INVOKABLE void setGameGrid(int gridIndex);
    QVector<int> winningCombination();
    QString winnerName();
    QVector<int> helpCoords();
    Q_INVOKABLE void emitHelp();
    int currentPlayerOnTurn();

    bool hasUnfinishedGame();
    
    // author - xebert00:
    QString currentUserName();
    void setCurrentUserName(QString newName);

    Q_INVOKABLE void emitCreateMap();
    QVector<int> gameMapGrid();
    Q_INVOKABLE void setGameMapGrid(int gridIndex, int fieldType);
    
    // author - xjobra01:
    QStringList replayGameNames();
    Q_INVOKABLE void emitLoadReplayGame(QString gameName);
    QVector<int> gameReplayGrid();
    QVector<bool> loadedGameModes();
    
public slots:
    // author - xcepel03:
    void handleUnfinishedGameChanged();
    void handleTurnChanged();
    void handleGameWon(QVector<int>& winningCombination, QString winnerName);
    void handleHelpResult(QVector<int>& newHelpCoords);
    void handleUnfinishedGameLoaded(QVector<int>& gameGrid, QVector<int>& gameMapGrid, bool winModeThree);

    // author - xjobra01:
    void handleUpdatedGameNames(QVector<QString>& newGameNames);
    void handleReplayGameLoaded(QVector<int>& gameGrid);
    void handleNewGameFromReplayedLoaded(QVector<int>& gameGrid, bool winModeThree);

signals:
    // author - xcepel03:
    void settingsDoubleClickEnabledChanged(bool newState);
    void settingsHelpEnabledChanged(bool newState);
    void settingsDarkModeEnabledChanged(bool newState);
    void settingsSymbolTypeChanged(int newType);
    void settingsSoundEnabledChanged(bool newState);
    
    void createGame(bool winModeThree, bool newCustomMap, uint64_t newPlayerOneUid, uint64_t newPlayerTwoUid, QVector<int> initMap);
    void gameGridChanged(int x, int y);
    void winningCombinationChanged();
    void winnerNameChanged();
    void helpEnabled();
    void helpCoordsChanged();
    void currentPlayerOnTurnChanged();
    void currentGameSurrender();

    void loadUnfinishedGame();
    void hasUnfinishedGameChanged();

    // author - xebert00:
    void currentUserNameChanged();

    void createMap();
    void gameMapGridChanged(int x, int y, int fieldType);

    // author - xjobra01:
    void loadHistory();
    void replayGameNamesChanged();
    void loadReplayGame(QString &gameName);
    void gameReplayGridChanged();
    void replayBeginning();
    void replayBack();
    void replayForward();
    void replayEnd();
    void newGameFromReplayed();
    void loadedGameModesChanged();

private:
    QObject *viewRoot;

    bool m_settingsDoubleClickEnabled;
    bool m_settingsHelpEnabled;
    bool m_settingsDarkModeEnabled;
    int m_settingsSymbolType;
    bool m_settingsSoundEnabled;

    QVector<int> m_gameGrid;
    QVector<int> m_winningCombination;
    QString m_winnerName;
    QVector<int> m_helpCoords;

    bool m_hasUnfinishedGame;

    QString m_currentUserName;

    QVector<int> m_gameMapGrid;
    
    QVector<QString> m_replayGameNames;
    QVector<int> m_gameReplayGrid;
    QVector<bool> m_loadedGameModes;
};

#endif // ADAPTER_H
