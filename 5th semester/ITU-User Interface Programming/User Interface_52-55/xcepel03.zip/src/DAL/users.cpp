/*********************************************************************
 * @file  usersentity.cpp
 *
 * @brief Implementation of managment of users in settings
 * @author xebert00
 * @date Last modified on 2023-12-17
 *********************************************************************/

#include "users.h"

Users::Users(QString usersFilePath): usersFilePath(usersFilePath)
{
    //TODO: load from JSON
}

void Users::addUser(UserEntity newUser)
{
    allUsers.push_back(newUser);
    //TODO: write to JSON
}
