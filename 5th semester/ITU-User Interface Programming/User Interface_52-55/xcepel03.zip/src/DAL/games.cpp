/*********************************************************************
 * @file  games.cpp
 *
 * @brief Implementation of game entity - methods for managing the games in saves
 *
 * @author xjobra01
 * @date Last modified on 2023-12-17
 *********************************************************************/

#include "games.h"

// Handle saved games
Games::Games(QString gamesFilePath): gamesFilePath(gamesFilePath)
{
    QFile gamesFile(gamesFilePath);
    if (!gamesFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
        // Handle error - file does not exist or cannot be opened
        return;
    }

    QByteArray fileContent = gamesFile.readAll();
    gamesFile.close();

    QJsonDocument jsonDoc = QJsonDocument::fromJson(fileContent);
    if (!jsonDoc.isObject()) {
        // Handle error - invalid JSON format
        return;
    }

    QJsonObject jsonObject = jsonDoc.object();
    if (jsonObject.contains("games") && jsonObject["games"].isArray()) {
        QJsonArray gamesArray = jsonObject["games"].toArray();

        allGames.clear(); // Clear existing games

        for (const QJsonValue& gameValue : gamesArray) {
            if (gameValue.isObject()) {
                QJsonObject gameObject = gameValue.toObject();
                GameEntity game(gameObject);
                allGames.append(game);
            }
        }
    }
}

// Save games to json
void Games::saveGames()
{
    QFile gamesFile(gamesFilePath);

    if (!gamesFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
        // Handle error - cannot open file for writing
        return;
    }

    QJsonArray gamesArray;

    for (const GameEntity& game : allGames) {
        QJsonObject gameObject;
        gameObject["gameName"] = game.gameName;
        gameObject["winModeThree"] = game.winModeThree;
        gameObject["customMap"] = game.customMap;
        gameObject["playerOneUid"] = static_cast<qint64>(game.playerOneUid);
        gameObject["playerTwoUid"] = static_cast<qint64>(game.playerTwoUid);
        gameObject["isFinished"] = game.isFinished;
        gameObject["playerOneMoves"] = GameEntity::movesToJsonArray(game.playerOneMoves);
        gameObject["playerTwoMoves"] = GameEntity::movesToJsonArray(game.playerTwoMoves);
        gameObject["playerOneFields"] = GameEntity::movesToJsonArray(game.playerOneFields);
        gameObject["playerTwoFields"] = GameEntity::movesToJsonArray(game.playerTwoFields);
        gameObject["blockedFields"] = GameEntity::movesToJsonArray(game.blockedFields);

        gamesArray.append(gameObject);
    }

    QJsonObject jsonObject;
    jsonObject["games"] = gamesArray;

    QJsonDocument jsonDoc(jsonObject);
    gamesFile.write(jsonDoc.toJson());

    gamesFile.close();
}

// Add game to games list
void Games::addGame(GameEntity newGame)
{
    allGames.append(newGame);
    saveGames();
}
