/*********************************************************************
 * @file  userentity.cpp
 *
 * @brief Implementation of user entity - methods for managing the user in saves
 *
 * @author xebert00
 * @date Last modified on 2023-12-17
 *********************************************************************/

#include "userentity.h"

uint64_t UserEntity::newUid = 0;

// Inicialise new user
UserEntity::UserEntity(QString newNickname): uid(newUid++)
{
    nickname = newNickname;
    elo = 0;
    nGames3Wins = 0;
    nGames5Wins = 0;
    nGamesSwap = 0;
    nWins = 0;
    unfinishedGameName = "";
}
