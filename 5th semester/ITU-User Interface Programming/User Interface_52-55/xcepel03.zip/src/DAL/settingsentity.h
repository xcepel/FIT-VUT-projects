/*********************************************************************
 * @file  settingsentity.h
 *
 * @brief Header file for settings entity
 *
 * @author xcepel03
 * @date Last modified on 2023-12-17
 *********************************************************************/

#ifndef SETTINGSENTITY_H
#define SETTINGSENTITY_H

#include <QFile>
#include <QString>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue>

using namespace std;

class SettingsEntity
{
private:
    QString settingsFilePath;
public:
    bool doubleClickEnabled;
    bool helpEnabled;
    bool darkModeEnabled;
    int symbolType;
    bool soundEnabled;

    SettingsEntity();
    void setFilePath(QString filePath);
    void loadSettings();
    void saveSettings();
};

#endif // SETTINGSENTITY_H
