/*********************************************************************
 * @file  games.h
 *
 * @brief Header file for games management
 *
 * @author xjobra01
 * @date Last modified on 2023-12-17
 *********************************************************************/

#ifndef GAMES_H
#define GAMES_H

#include <QVector>
#include <QFile>
#include <QString>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue>
#include "DAL/gameentity.h"

using namespace std;

class Games
{
private:
    QString gamesFilePath;
public:
    QVector<GameEntity> allGames;

    Games(QString gamesFilePath);
    void saveGames();
    void addGame(GameEntity newGame);
    GameEntity getGame(QString gameName);
};

#endif // GAMES_H
