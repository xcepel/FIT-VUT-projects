/*********************************************************************
 * @file  userentity.h
 *
 * @brief Header file for user entity
 *
 * @author xebert00
 * @date Last modified on 2023-12-17
 *********************************************************************/

#ifndef USERENTITY_H
#define USERENTITY_H

#include <QString>

using namespace std;

class UserEntity
{
private:
    static uint64_t newUid;

public:
    const uint64_t uid;
    QString nickname;
    //TODO: ProfilePic
    uint16_t elo;
    uint64_t nGames3Wins;
    uint64_t nGames5Wins;
    uint64_t nGamesSwap;
    uint64_t nWins;
    QString unfinishedGameName; // if empty string - no unfinished game

    UserEntity(QString newNickname);
};

#endif // USERENTITY_H
