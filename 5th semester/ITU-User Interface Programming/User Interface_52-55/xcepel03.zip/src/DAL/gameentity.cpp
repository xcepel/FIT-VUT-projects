/*********************************************************************
 * @file  gameentity.cpp
 *
 * @brief Implementation of game entity - methods for setting up + managing the game
 *
 * @author xjobra01
 * @date Last modified on 2023-12-17
 *********************************************************************/

#include "gameentity.h"

// Creator - clean map
GameEntity::GameEntity(bool newWinModeThree, bool newCustomMap, uint64_t newPlayerOneUid, uint64_t newPlayerTwoUid)
{
    QTimeZone timeZone("Europe/Prague");
    gameName = QDateTime::currentDateTime().toTimeZone(timeZone).toString("yyyy-MM-dd-hh-mm-ss");
    winModeThree = newWinModeThree;
    customMap = newCustomMap;
    playerOneUid = newPlayerOneUid;
    playerTwoUid = newPlayerTwoUid;
    isFinished = false;
}

// Creator - loading map
GameEntity::GameEntity(QJsonObject gameObject)
{
    gameName = gameObject["gameName"].toString();
    winModeThree = gameObject["winModeThree"].toBool();
    customMap = gameObject["customMap"].toBool();
    playerOneUid = gameObject["playerOneUid"].toVariant().toULongLong();
    playerTwoUid = gameObject["playerTwoUid"].toVariant().toULongLong();
    isFinished = gameObject["isFinished"].toBool();
    playerOneMoves = GameEntity::movesFromJsonArray(gameObject["playerOneMoves"].toArray());
    playerTwoMoves = GameEntity::movesFromJsonArray(gameObject["playerTwoMoves"].toArray());
    playerOneFields = GameEntity::movesFromJsonArray(gameObject["playerOneFields"].toArray());
    playerTwoFields = GameEntity::movesFromJsonArray(gameObject["playerTwoFields"].toArray());
    blockedFields = GameEntity::movesFromJsonArray(gameObject["blockedFields"].toArray());
}

// Saves new move for player one
void GameEntity::addPlayerOneMove(move_t newMove)
{
    playerOneMoves.append(newMove);
}

// Saves new move for player two
void GameEntity::addPlayerTwoMove(move_t newMove)
{
    playerTwoMoves.append(newMove);
}

// Saves field for player one
void GameEntity::addPlayerOneField(move_t newMove)
{
    playerOneFields.append(newMove);
}

// Saves field for player two
void GameEntity::addPlayerTwoField(move_t newMove)
{
    playerTwoFields.append(newMove);
}

// Saves blocked field
void GameEntity::addBlockedField(move_t newMove)
{
    blockedFields.append(newMove);
}

// Rewrites stats of moves to array JSON
QJsonArray GameEntity::movesToJsonArray(const QVector<move_t>& moves)
{
    QJsonArray movesArray;
    for (const auto& move : moves) {
        QJsonArray moveArray;
        moveArray.append(move.first);
        moveArray.append(move.second);
        movesArray.append(moveArray);
    }
    return movesArray;
}

// Rewrites stats of moves from JSON to array
QVector<move_t> GameEntity::movesFromJsonArray(const QJsonArray& jsonArray)
{
    QVector<move_t> moves;
    for (const QJsonValue& moveValue : jsonArray) {
        QJsonArray moveArray = moveValue.toArray();
        moves.append(QPair<int, int>(moveArray[0].toInt(), moveArray[1].toInt()));
    }
    return moves;
}
