/*********************************************************************
 * @file  gameentity.h
 *
 * @brief Header file for game entity
 *
 * @author xjobra01
 * @date Last modified on 2023-12-17
 *********************************************************************/

#ifndef GAMEENTITY_H
#define GAMEENTITY_H

#include <cstdint>
#include <utility>
#include <QVector>
#include <QString>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue>
#include <QJsonArray>
#include <QDateTime>
#include <QTimeZone>

using namespace std;

typedef pair<int, int> move_t;

enum GameMode {
    ThreeWins,
    FiveWins
};

class GameEntity
{
public:
    QString gameName;
    bool winModeThree;
    bool customMap;
    uint64_t playerOneUid;
    uint64_t playerTwoUid;
    QVector<move_t> playerOneMoves;
    QVector<move_t> playerTwoMoves;
    // Used only with custom maps:
    QVector<move_t> playerOneFields;
    QVector<move_t> playerTwoFields;
    QVector<move_t> blockedFields;
    bool isFinished;

    GameEntity(bool newWinModeThree, bool newCustomMap, uint64_t newPlayerOneUid, uint64_t newPlayerTwoUid); // creates new game
    GameEntity(QJsonObject gameObject); // for loading from a file

    void addPlayerOneMove(move_t newMove);
    void addPlayerTwoMove(move_t newMove);
    void addPlayerOneField(move_t newMove);
    void addPlayerTwoField(move_t newMove);
    void addBlockedField(move_t newMove);

    static QJsonArray movesToJsonArray(const QVector<move_t>& moves);
    static QVector<move_t> movesFromJsonArray(const QJsonArray& jsonArray);
};

#endif // GAMEENTITY_H
