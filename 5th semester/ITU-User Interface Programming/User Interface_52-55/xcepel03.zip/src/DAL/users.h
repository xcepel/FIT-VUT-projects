/*********************************************************************
 * @file  users.h
 *
 * @brief Header file for users
 *
 * @author xebert00
 * @date Last modified on 2023-12-17
 *********************************************************************/

#ifndef USERS_H
#define USERS_H

#include "DAL/userentity.h"
#include <QString>
#include <vector>

using namespace std;

class Users
{
private:
    QString usersFilePath;
public:
    vector<UserEntity> allUsers;

    Users(QString usersFilePath);
    void addUser(UserEntity newUser);
    UserEntity getUser(QString nickname);
};

#endif // USERS_H
