/*********************************************************************
 * @file  settingsentity.cpp
 *
 * @brief Implementation of settings entity - methods for managing the settings saving
 *
 * @author xcepel03
 * @date Last modified on 2023-12-17
 *********************************************************************/

#include "settingsentity.h"

// Constructor
SettingsEntity::SettingsEntity()
{
}

// Set new filepath for settings
void SettingsEntity::setFilePath(QString filePath)
{
    settingsFilePath = filePath;
}

// Load settings from file
void SettingsEntity::loadSettings()
{
    // TODO: check if filepath is set?
    bool existed = QFile::exists(settingsFilePath);
    QFile settingsFile(settingsFilePath);

    if (!settingsFile.open(QIODevice::ReadWrite | QIODevice::Text)) {
        throw runtime_error("Could not open file");
    }
    QTextStream stream(&settingsFile);
    QJsonObject settings;
    if (!existed) {
        settings["doubleClickEnabled"] = false;
        settings["helpEnabled"] = true;
        settings["darkModeEnabled"] = false;
        settings["symbolType"] = 0;
        settings["soundEnabled"] = false;
        QByteArray out = QJsonDocument(settings).toJson();
        stream << out;
    }
    else {
        QString s = settingsFile.readAll();
        settingsFile.close();
        settings = QJsonDocument::fromJson(s.toUtf8()).object();
    }
    settingsFile.close();

    doubleClickEnabled = settings.value("doubleClickEnabled").toBool();
    helpEnabled = settings.value("helpEnabled").toBool();
    darkModeEnabled = settings.value("darkModeEnabled").toBool();
    symbolType = settings.value("symbolType").toInt();
    soundEnabled = settings.value("soundEnabled").toBool();
}

// Save settings to file
void SettingsEntity::saveSettings()
{
    QFile settingsFile(settingsFilePath);

    if (!settingsFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
        throw std::runtime_error("Could not open file for writing");
    }

    QJsonObject settings;
    settings["doubleClickEnabled"] = doubleClickEnabled;
    settings["helpEnabled"] = helpEnabled;
    settings["darkModeEnabled"] = darkModeEnabled;
    settings["symbolType"] = symbolType;
    settings["soundEnabled"] = soundEnabled;

    QTextStream stream(&settingsFile);
    stream << QJsonDocument(settings).toJson();

    settingsFile.close();
}
