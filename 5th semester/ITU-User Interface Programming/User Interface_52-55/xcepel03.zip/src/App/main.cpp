/*********************************************************************
 * @file  main.cpp
 *
 * @brief Entry point of the application (initializing the app)
 *
 * @author xjobra01
 * @date Last modified on 2023-12-17
 *********************************************************************/

#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include "BL/adapter.h"

int main(int argc, char *argv[])
{
    QCoreApplication::setApplicationName("piŠKVORky");
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    const QUrl url(u"qrc:/ITU/App/Main.qml"_qs);

    // Set file paths
    QString appdataPath = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation); //TODO: choose more appropriate folder
    QString settingsFileName = "settings.json";
    QString settingsFilePath = appdataPath + "/" + settingsFileName;
    QString usersFileName = "users.json";
    QString usersFilePath = appdataPath + "/" + usersFileName;
    QString gamesFileName = "games.json";
    QString gamesFilePath = appdataPath + "/" + gamesFileName;

    Adapter adapter(settingsFilePath, usersFilePath, gamesFilePath);
    QQmlContext *context = engine.rootContext();
    context->setContextProperty("adapter", &adapter);

    QObject::connect(&engine, &QQmlApplicationEngine::objectCreationFailed,
        &app, []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
