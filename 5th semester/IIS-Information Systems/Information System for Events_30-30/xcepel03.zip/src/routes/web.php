<?php

use App\Http\Controllers\CategoryController;
use App\Http\Controllers\EventImageController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\EventController;
use App\Http\Controllers\TicketController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\VenueController;
use App\Http\Controllers\CommentController;
use App\Http\Controllers\IsAttendingController;
use App\Http\Controllers\VenueImageController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [EventController::class, 'index'])->name('events_index');
Route::get('/events/{id}/detail', [EventController::class, 'detail'])->name('events_detail');


Route::get('/venues', [VenueController::class, 'index'])->name('venues_index');
Route::get('/venues/{id}/detail', [VenueController::class, 'detail'])->name('venues_detail');


Route::get('/categories', [CategoryController::class, 'index'])->name('categories_index');
Route::get('/categories/{id}/detail', [CategoryController::class, 'detail'])->name('categories_detail');


Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    Route::delete('/profile/img', [ProfileController::class, 'delete_image'])->name('profile.image.delete');


    Route::get('/events/create', [EventController::class, 'create'])->name('events_create');
    Route::post('/events/save', [EventController::class, 'store'])->name('events_save');
    Route::get('/events/{id}/edit', [EventController::class, 'edit'])->name('events.edit');
    Route::put('/events/{id}', [EventController::class, 'update'])->name('events.update');
    Route::get('/events/{event_id}/tickets/create', [TicketController::class, 'create'])->name('tickets.create');
    Route::post('/events/{event_id}/tickets/store', [TicketController::class, 'store'])->name('tickets.store');
    Route::get('/events/{event_id}/tickets/{ticket_id}/edit', [TicketController::class, 'edit'])->name('tickets.edit');
    Route::put('/events/{event_id}/tickets/{ticket_id}', [TicketController::class, 'update'])->name('tickets.update');
    Route::delete('/events/{event_id}/tickets/{ticket_id}', [TicketController::class, 'destroy'])->name('tickets.destroy');
    Route::delete('/events/{event_id}', [EventController::class, 'destroy'])->name('events_destroy');
    Route::get('/events/myevents', [EventController::class, 'my_events'])->name('events.my_events');
    Route::post('/events/{event_id}/approve', [EventController::class, 'approve_event'])->name('events.approve');
    Route::delete('/events/{event_id}/{image_id}', [EventImageController::class, 'destroy'])->name('event_image_destroy');


    Route::get('/venues/create', [VenueController::class, 'create'])->name('venues_create');
    Route::post('/venues/store', [VenueController::class, 'store'])->name('venues_store');
    Route::get('/venues/{id}/edit', [VenueController::class, 'edit'])->name('venues.edit');
    Route::put('/venues/{id}', [VenueController::class, 'update'])->name('venues.update');
    Route::delete('/venues/{venue_id}', [VenueController::class, 'destroy'])->name('venues_destroy');
    Route::post('/venues/{venue_id}/approve', [VenueController::class, 'approve_venue'])->name('venues.approve');
    Route::delete('/venues/{venue_id}/{image_id}', [VenueImageController::class, 'destroy'])->name('venue_image_destroy');


    Route::get('/categories/create', [CategoryController::class, 'create'])->name('categories_create');
    Route::post('/categories/save', [CategoryController::class, 'store'])->name('categories_save');
    Route::get('/categories/{id}/edit', [CategoryController::class, 'edit'])->name('categories.edit');
    Route::put('/categories/{id}', [CategoryController::class, 'update'])->name('categories.update');


    Route::delete('/categories/{category_id}', [CategoryController::class, 'destroy'])->name('categories_destroy');
    Route::post('/categories/{category_id}/approve', [CategoryController::class, 'approve_category'])->name('categories.approve');


    Route::get('/comments/index', [CommentController::class, 'index'])->name('comments_index');
    Route::delete('/comments/{comment_id}/{event_id}', [CommentController::class, 'destroy'])->name('comments_destroy');
    Route::post('/events/{event_id}/comments/store', [CommentController::class, 'store'])->name('comments_store');


    Route::get('/events/{event_id}/isattending', [IsAttendingController::class, 'index'])->name('isattending_index');
    Route::post('/events/{event_id}/isattending/store', [IsAttendingController::class, 'store'])->name('isattending_store');
    Route::delete('/events/{event_id}/isattending', [IsAttendingController::class, 'destroy'])->name('isattending_destroy');
    Route::post('/events/{event_id}/isattending/{user_id}', [IsAttendingController::class, 'store_attendee'])->name('attendees.store');


    Route::get('/users/index', [UserController::class, 'index'])->name('users_index');
    Route::post('/users/{user_id}', [UserController::class, 'change_role'])->name('users_change_role');
    Route::delete('/users/{user_id}', [UserController::class, 'destroy'])->name('users_destroy');
});

require __DIR__.'/auth.php';
