<x-app-layout>
    <x-slot name="title">
        Moje akce a události
    </x-slot>

    <x-slot name="header">
        <h1>Moje akce a události</h1>
    </x-slot>

    <div id="my_event_buttons" class="container text-center">
        <button id="future_attended_event_button" onclick="future_attended_events()"><span></span>Účastním se (nadcházející)</button>
        <button id="past_attended_event_button" onclick="past_attended_events()"><span></span>Účastním se (proběhlé)</button>
        <button id="hosted_event_button" onclick="hosted_events()"><span></span>Pořádám</button>
    </div>

    <div id="future_attended_events" class="container">
        <table id="future_attended_events_table" class="table table-hover table-bordered">
            <thead>
            <tr>
                <th></th>
                <th scope="col">Název</th>
                <th scope="col">Místo konání</th>
                <th scope="col">Datum</th>
                <th scope="col">Kategorie</th>
            </tr>
            </thead>
            <tbody>
            @foreach($future_attended_events as $event)
                    <?php // php script for change of appearance of date
                    $date_from = new DateTime($event->date_from);
                    $date_to = new DateTime($event->date_to);

                    // Format the date manually using the date function
                    $formatted_date_from = \Carbon\Carbon::parse($date_from->getTimestamp())->format('d. n. Y, G:i');
                    $formatted_date_to = \Carbon\Carbon::parse($date_to->getTimestamp())->format('d. n. Y, G:i');
                    ?>
                <tr>
                    <td onclick="window.location='{{route('events_detail', $event->id)}}';">
                        @if ($event->Has_images->count())
                            <img class="img-fluid img-thumbnail" src="{{ asset('storage/images/events/' . $event->Has_images->first()->img_path ) }}" alt="">
                        @else
                            <img class="img-fluid img-thumbnail" src="{{ asset('storage/images/default/event.png') }}" alt="Výchozí obrázek">
                        @endif
                    </td>
                    <td onclick="window.location='{{route('events_detail', $event->id)}}';">{{ $event->name }}</td>
                    <td {{ is_null($event->Venue) ? '' : 'onclick="window.location=' . route('events_detail', $event->id) . ';"' }}>
                        {{ is_null($event->Venue) ? '' : $event->Venue->name }}
                    </td>
                    <td>
                        <p><b>Od:</b> <?php echo $formatted_date_from; ?></p>
                        <p><b>Do:</b> <?php echo $formatted_date_to; ?></p>
                    </td>
                    <td>{{ (is_null($event->Category))? "" : $event->Category->name }}</td>

                </tr>
                <br>
            @endforeach
            </tbody>
        </table>
    </div>

    <div id="past_attended_events" class="container">
        <table id="past_attended_events_table" class="table table-hover table-bordered">
            <thead>
            <tr>
                <th></th>
                <th scope="col">Název</th>
                <th scope="col">Místo konání</th>
                <th scope="col">Datum</th>
                <th scope="col">Kategorie</th>
            </tr>
            </thead>
            <tbody>
            @foreach($past_attended_events as $event)
                    <?php // php script for change of appearance of date
                    $date_from = new DateTime($event->date_from);
                    $date_to = new DateTime($event->date_to);

                    // Format the date manually using the date function
                    $formatted_date_from = \Carbon\Carbon::parse($date_from->getTimestamp())->format('d. n. Y, G:i');
                    $formatted_date_to = \Carbon\Carbon::parse($date_to->getTimestamp())->format('d. n. Y, G:i');
                    ?>
                <tr>
                    <td onclick="window.location='{{route('events_detail', $event->id)}}';">
                        @if ($event->Has_images->count())
                            <img class="img-fluid img-thumbnail" src="{{ asset('storage/images/events/' . $event->Has_images->first()->img_path ) }}" alt="">
                        @else
                            <img class="img-fluid img-thumbnail" src="{{ asset('storage/images/default/event.png') }}" alt="Výchozí obrázek">
                        @endif
                    </td>
                    <td onclick="window.location='{{route('events_detail', $event->id)}}';">{{ $event->name }}</td>
                    <td {{ is_null($event->Venue) ? '' : 'onclick="window.location=' . route('events_detail', $event->id) . ';"' }}>
                        {{ is_null($event->Venue) ? '' : $event->Venue->name }}
                    </td>
                    <td>
                        <p><b>Od:</b> <?php echo $formatted_date_from; ?></p>
                        <p><b>Do:</b> <?php echo $formatted_date_to; ?></p>
                    </td>
                    <td>{{ (is_null($event->Category))? "" : $event->Category->name }}</td>

                </tr>
                <br>
            @endforeach
            </tbody>
        </table>
    </div>

    <div id="hosted_events" class="container">
        <table id="hosted_events_table" class="table table-hover table-bordered">
            <thead>
            <tr>
                <th></th>
                <th scope="col">Název</th>
                <th scope="col">Místo konání</th>
                <th scope="col">Datum</th>
                <th scope="col">Kategorie</th>
            </tr>
            </thead>
            <tbody>
            @foreach($hosted_events as $event)
                    <?php // php script for change of appearance of date
                    $date_from = new DateTime($event->date_from);
                    $date_to = new DateTime($event->date_to);

                    // Format the date manually using the date function
                    $formatted_date_from = \Carbon\Carbon::parse($date_from->getTimestamp())->format('d. n. Y, G:i');
                    $formatted_date_to = \Carbon\Carbon::parse($date_to->getTimestamp())->format('d. n. Y, G:i');
                    ?>
                <tr>
                    <td onclick="window.location='{{route('events_detail', $event->id)}}';">
                        @if ($event->Has_images->count())
                            <img class="img-fluid img-thumbnail" src="{{ asset('storage/images/events/' . $event->Has_images->first()->img_path ) }}" alt="">
                        @else
                            <img class="img-fluid img-thumbnail" src="{{ asset('storage/images/default/event.png') }}" alt="Výchozí obrázek">
                        @endif
                    </td>
                    <td onclick="window.location='{{route('events_detail', $event->id)}}';">{{ $event->name }}</td>
                    <td {{ is_null($event->Venue) ? '' : 'onclick="window.location=' . route('events_detail', $event->id) . ';"' }}>
                        {{ is_null($event->Venue) ? '' : $event->Venue->name }}
                    </td>
                    <td>
                        <p><b>Od:</b> <?php echo $formatted_date_from; ?></p>
                        <p><b>Do:</b> <?php echo $formatted_date_to; ?></p>
                    </td>
                    <td>{{ (is_null($event->Category))? "" : $event->Category->name }}</td>

                </tr>
                <br>
            @endforeach
            </tbody>
        </table>
    </div>

    <script>
        $(document).ready(
            function () {
                $('#hosted_events_table').DataTable({
                    "language": {
                        "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Czech.json"
                    },
                    "aaSorting": [],
                    columnDefs: [{
                        orderable: false,
                        targets: 0
                    }]
                });
                $('#future_attended_events_table').DataTable({
                    "language": {
                        "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Czech.json"
                    },
                    "aaSorting": [],
                    columnDefs: [{
                        orderable: false,
                        targets: 0
                    }]
                });
                $('#past_attended_events_table').DataTable({
                    "language": {
                        "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Czech.json"
                    },
                    "aaSorting": [],
                    columnDefs: [{
                        orderable: false,
                        targets: 0
                    }]
                });
            }
        );

    var future_attended_events_table = document.getElementById('future_attended_events');
    var future_attended_events_table_style = window.getComputedStyle(future_attended_events_table);
    var future_attended_events_button = document.getElementById('future_attended_event_button');
        var past_attended_events_table = document.getElementById('past_attended_events');
        var past_attended_events_table_style = window.getComputedStyle(past_attended_events_table);
        var past_attended_events_button = document.getElementById('past_attended_event_button');
    var hosted_events_table = document.getElementById('hosted_events');
    var hosted_events_table_style = window.getComputedStyle(hosted_events_table);
    var hosted_events_button = document.getElementById('hosted_event_button');
    // Function to toggle the visibility of the future attended events
    function future_attended_events() {
        if (future_attended_events_table_style.display === 'none') {
            future_attended_events_table.style.display = 'block';
            future_attended_events_button.style.background = 'royalblue';
            future_attended_events_button.style.color = 'black';
            past_attended_events_table.style.display = 'none';
            past_attended_events_button.style.background = 'white';
            past_attended_events_button.style.color = 'black';
            hosted_events_table.style.display = 'none';
            hosted_events_button.style.background = 'white';
            hosted_events_button.style.color = 'black';
        }
    }
    // Function to toggle the visibility of the past attended events
    function past_attended_events() {
        if (past_attended_events_table_style.display === 'none') {
            past_attended_events_table.style.display = 'block';
            past_attended_events_button.style.background = 'royalblue';
            past_attended_events_button.style.color = 'black';
            future_attended_events_table.style.display = 'none';
            future_attended_events_button.style.background = 'white';
            future_attended_events_button.style.color = 'black';
            hosted_events_table.style.display = 'none';
            hosted_events_button.style.background = 'white';
            hosted_events_button.style.color = 'black';
        }
    }
    // Function to toggle the visibility of the hosted events
    function hosted_events() {
        if (hosted_events_table_style.display === 'none') {
            hosted_events_table.style.display = 'block';
            hosted_events_button.style.background = 'royalblue';
            hosted_events_button.style.color = 'black';
            future_attended_events_table.style.display = 'none';
            future_attended_events_button.style.background = 'white';
            future_attended_events_button.style.color = 'black';
            past_attended_events_table.style.display = 'none';
            past_attended_events_button.style.background = 'white';
            past_attended_events_button.style.color = 'black';
        }
    }
    </script>
</x-app-layout>
