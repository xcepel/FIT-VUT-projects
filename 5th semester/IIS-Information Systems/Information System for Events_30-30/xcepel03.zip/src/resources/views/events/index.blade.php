<x-app-layout>
    <x-slot name="title">
        Akce a události
    </x-slot>

    <x-slot name="header">
        <h1>Akce a události</h1>
    </x-slot>

    <div id="event_buttons" class="container text-center">
        <button id="future_event_button" onclick="future_events()"><span></span>Nadcházející události</button>
        <button id="past_event_button" onclick="past_events()"><span></span>Proběhlé události</button>
        @if((optional(auth()->user())->mod) || optional(auth()->user())->admin)
            <button id="no_approval_events_button" onclick="no_approval_events()"><span></span>Události bez potvrzení</button>
        @endif
    </div>

    <div id="create_event_button" class="container text-center">
        <form class="form-horizontal" method="get" action="{{route('events_create')}}">
                {{ csrf_field() }}<button type="submit" class="btn btn-primary"><span></span>Vytvořit novou událost</button>
        </form>
    </div>

    <div id="future_events" class="container">
        <table id="future_events_table" class="table table-hover table-bordered">
            <thead>
            <tr>
                <th></th>
                <th scope="col">Název</th>
                <th scope="col">Místo konání</th>
                <th scope="col">Datum</th>
                <th scope="col">Kategorie</th>
            </tr>
            </thead>
            <tbody>
                @foreach($future_events as $event)
                    <?php // php script for change of appearance of date
                        $date_from = new DateTime($event->date_from);
                        $date_to = new DateTime($event->date_to);

                        // Format the date manually using the date function
                        $formatted_date_from = \Carbon\Carbon::parse($date_from->getTimestamp())->format('d. n. Y, G:i');
                        $formatted_date_to = \Carbon\Carbon::parse($date_to->getTimestamp())->format('d. n. Y, G:i');
                    ?>
                    <tr onclick="window.location='{{route('events_detail', $event->id)}}';">
                        <td>
                            @if ($event->Has_images->count())
                                <img class="img-fluid img-thumbnail" src="{{ asset('storage/images/events/' . $event->Has_images->first()->img_path ) }}" alt="">
                            @else
                                <img class="img-fluid img-thumbnail" src="{{ asset('storage/images/default/event.png') }}" alt="Výchozí obrázek">
                            @endif
                        </td>
                        <td>{{ $event->name }}</td>
                        <td {{ is_null($event->Venue) ? '' : 'onclick="window.location=' . route('events_detail', $event->id) . ';"' }}>
                        {{ is_null($event->Venue) ? '' : $event->Venue->name }}
                    </td>
                        <td>
                            <p><b>Od:</b> <?php echo $formatted_date_from; ?></p>
                            <p><b>Do:</b> <?php echo $formatted_date_to; ?></p>
                        </td>
                        <td>{{ (is_null($event->Category))? "" : $event->Category->name }}</td>

                    </tr>
                    <br>
                @endforeach
            </tbody>
        </table>
    </div>

<div id="past_events" class="container">
    <table id="past_events_table" class="table table-hover table-bordered table-sm">
        <thead>
        <tr>
            <th></th>
            <th scope="col">Název</th>
            <th scope="col">Místo konání</th>
            <th scope="col">Datum</th>
            <th scope="col">Kategorie</th>
        </tr>
        </thead>
        <tbody>
            @foreach($past_events as $event)
                <?php // php script for change of appearance of date
                    $date_from = new DateTime($event->date_from);
                    $date_to = new DateTime($event->date_to);
                    $formatted_date_from = \Carbon\Carbon::parse($date_from->getTimestamp())->format('d. n. Y, G:i');
                    $formatted_date_to = \Carbon\Carbon::parse($date_to->getTimestamp())->format('d. n. Y, G:i');
                ?>
                <tr onclick="window.location='{{route('events_detail', $event->id)}}';">
                    <td>
                        @if ($event->Has_images->count())
                            <img class="img-fluid img-thumbnail" src="{{ asset('storage/images/events/' . $event->Has_images->first()->img_path ) }}" alt="">
                        @else
                            <img class="img-fluid img-thumbnail" src="{{ asset('storage/images/default/event.png') }}" alt="Výchozí obrázek">
                        @endif
                    </td>
                    <td>{{ $event->name }}</td>
                    <td {{ is_null($event->Venue) ? '' : 'onclick="window.location=' . route('events_detail', $event->id) . ';"' }}>
                        {{ is_null($event->Venue) ? '' : $event->Venue->name }}
                    </td>
                        <td>
                            <p><b>Od:</b> <?php echo $formatted_date_from; ?></p>
                            <p><b>Do:</b> <?php echo $formatted_date_to; ?></p>
                        </td>
                        <td>{{ (is_null($event->Category))? "" : $event->Category->name }}</td>

                    </tr>
                    <br>
                @endforeach
            </tbody>
        </table>
    </div>

    <div id="no_approval_events" class="container">
    <table id="no_approval_events_table" class="table table-hover table-bordered">
        <thead>
        <tr>
            <th></th>
            <th scope="col">Název</th>
            <th scope="col">Místo konání</th>
            <th scope="col">Datum</th>
            <th scope="col">Kategorie</th>
        </tr>
        </thead>
        <tbody>
        @foreach($no_approval_events as $event)
                <?php // php script for change of appearance of date
                $date_from = new DateTime($event->date_from);
                $date_to = new DateTime($event->date_to);
                // Format the date manually using the date function
                $formatted_date_from = \Carbon\Carbon::parse($date_from->getTimestamp())->format('d. n. Y, G:i');
                $formatted_date_to = \Carbon\Carbon::parse($date_to->getTimestamp())->format('d. n. Y, G:i');
                ?>
            <tr onclick="window.location='{{route('events_detail', $event->id)}}';">
                <td>
                    @if ($event->Has_images->count())
                        <img class="img-fluid img-thumbnail" src="{{ asset('storage/images/events/' . $event->Has_images->first()->img_path ) }}" alt="">
                    @else
                        <img class="img-fluid img-thumbnail" src="{{ asset('storage/images/default/event.png') }}" alt="Výchozí obrázek">
                    @endif
                </td>
                <td>{{ $event->name }}</td>
                <td {{ is_null($event->Venue) ? '' : 'onclick="window.location=' . route('events_detail', $event->id) . ';"' }}>
                    {{ is_null($event->Venue) ? '' : $event->Venue->name }}
                </td>
                <td>
                    <p><b>Od:</b> <?php echo $formatted_date_from; ?></p>
                    <p><b>Do:</b> <?php echo $formatted_date_to; ?></p>
                </td>
                <td>{{ (is_null($event->Category))? "" : $event->Category->name }}</td>
            </tr>
            <br>
        @endforeach
        </tbody>
    </table>
</div>


    <script>
        $(document).ready(
            function () {
                $('#future_events_table').DataTable({
                    "language": {
                        "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Czech.json"
                    },
                    "aaSorting": [],
                    columnDefs: [{
                        orderable: false,
                        targets: 0
                    }]
                });
                $('#past_events_table').DataTable({
                    "language": {
                        "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Czech.json"
                    },
                    "aaSorting": [],
                    columnDefs: [{
                        orderable: false,
                        targets: 0
                    }]
                });
                $('#no_approval_events_table').DataTable({
                    "language": {
                        "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Czech.json"
                    },
                    "aaSorting": [],
                    columnDefs: [{
                        orderable: false,
                        targets: 0
                    }]
                });
            }
        );

   var past_events_table = document.getElementById('past_events');
    var past_events_table_style = window.getComputedStyle(past_events_table);
    var past_events_button = document.getElementById('past_event_button');
    var future_events_table = document.getElementById('future_events');
    var future_events_table_style = window.getComputedStyle(future_events_table);
    var future_events_button = document.getElementById('future_event_button');
    var no_approval_events_table = document.getElementById('no_approval_events');
    var no_approval_events_table_style = window.getComputedStyle(no_approval_events_table);
    var no_approval_events_button = document.getElementById('no_approval_events_button');
    // Function to toggle the visibility of the past events
    function past_events() {
        if (past_events_table_style.display === 'none') {
            past_events_table.style.display = 'block';
            past_events_button.style.background = 'royalblue';
            past_events_button.style.color = 'black';
            future_events_table.style.display = 'none';
            future_events_button.style.background = 'white';
            future_events_button.style.color = 'black';
            no_approval_events_table.style.display = 'none';
            no_approval_events_button.style.background = 'white';
            no_approval_events_button.style.color = 'black';
        }
    }
    // Function to toggle the visibility of the future events
    function future_events() {
        if (future_events_table_style.display === 'none') {
            future_events_table.style.display = 'block';
            future_events_button.style.background = 'royalblue';
            future_events_button.style.color = 'black';
            past_events_table.style.display = 'none';
            past_events_button.style.background = 'white';
            past_events_button.style.color = 'black';
            no_approval_events_table.style.display = 'none';
            no_approval_events_button.style.background = 'white';
            no_approval_events_button.style.color = 'black';
        }
    }
    // Function to toggle the visibility of the no approval events
    function no_approval_events() {
        if (no_approval_events_table_style.display === 'none') {
            no_approval_events_table.style.display = 'block';
            no_approval_events_button.style.background = 'royalblue';
            no_approval_events_button.style.color = 'black';
            future_events_table.style.display = 'none';
            future_events_button.style.background = 'white';
            future_events_button.style.color = 'black';
            past_events_table.style.display = 'none';
            past_events_button.style.background = 'white';
            past_events_button.style.color = 'black';
        }
    }

    </script>
</x-app-layout>
