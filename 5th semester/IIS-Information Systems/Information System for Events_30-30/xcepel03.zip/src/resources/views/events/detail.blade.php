<x-app-layout>
    <x-slot name="title">
        Detail události
    </x-slot>

    <x-slot name="header">
            <h1>{{ $event->name }}</h1>
            <!-- Categories -->
            <div class="container">
                <h4>
                    @foreach($categories as $category)
                        <span id="event_category_tag" class="label label-info">{{ $category->name }}</span>
                    @endforeach
                </h4>
            </div>

            <!-- Display only for future events -->
            @if (\Carbon\Carbon::now() < $event->date_to)
                @if(auth()->user())
                    @if(!$is_attending)
                        <form method="POST" action="{{ route('isattending_store', ['event_id' => $event->id]) }}">
                            @csrf
                            <button type="submit" id="register_for_event"><span></span>Přihlásit se na událost</button>
                        </form>
                    @else
                        <form id="unregister_form" method="POST" action="{{ route('isattending_destroy', ['event_id' => $event->id]) }}">
                            @csrf
                            @method('DELETE')
                            <button type="submit" id="unregister_from_event"
                                    onclick="confirmUnregister('{{$event->name}}')"><span></span>Odhlásit se z události</button>
                        </form>
                        @if ($is_attending->ticket)
                            <div style="color:green; margin-top: 20px;"><p>Vstupné zaplaceno</p></div>
                        @else
                            <div style="color:orange; margin-top: 20px;"><p>Vstupné nezaplaceno</p></div>
                        @endif
                    @endif
                @endif
            @endif
</x-slot>

<div class="container">
    <div class="row">
            <div id="event_show_participants_button" class="text-center col-md-3" style="margin-left:0; padding-left: 0;">
                @if((auth()->id() == optional($event->Manager)->id) || optional(auth()->user())->admin)
                    <a href="{{ route('isattending_index', ['event_id' => $event->id]) }}" style="width:80%;"><span></span>
                        Zobrazit účastníky
                    </a>
                @endif
            </div>
            <div id="edit_event_button" class="text-left col-md-4" style="padding-left: 0">
                @if((auth()->id() == optional($event->Manager)->id) || optional(auth()->user())->admin)
                    <form action="{{ route('events.edit', $event->id) }}" method="GET">
                        @csrf
                        <button type="submit" class="btn btn-primary" style="margin-top: 0;"><span></span>Upravit</button>
                    </form>
                @endif
            </div>
            <div id="approve_event_button" class="text-right col-md-3" style="padding-right: 0;">
                @if( (optional(auth()->user())->admin || optional(auth()->user())->mod) && !$event->Approved_by)
                    <form action="{{ route('events.approve', ['event_id' => $event->id]) }}" method="post">
                        @csrf
                        <button type="submit"><span></span>Schválit událost</button>
                    </form>
                @endif
            </div>
            <div class="text-right col-md-1 delete_button event" style="padding-left: 0;">
                @if((auth()->id() == optional($event->Manager)->id) || optional(auth()->user())->admin)
                    <form id="event_{{$event->id}}_delete_button" class="delete_button event" method="POST" action="{{ route('events_destroy', ['event_id' => $event->id]) }}">
                        @csrf
                        @method('DELETE')
                        <button onclick="confirmDelete('{{$event->name}}', '{{$event->id}}')" type="button"><span class="glyphicon glyphicon-trash"></span></button>
                    </form>
                @endif
            </div>
    </div>

    <div id="detail_event" class="row-content">
        <div>
            <div class="row container">
                <div class="col-sm-4">
                    <!-- Date and time of the event -->
                    <h2><b>Datum a čas konání</b></h2>
                    <div class="col-sm-9">
                    <?php // php script for change of appearance of date
                        $date_from = new DateTime($event->date_from);
                        $date_to = new DateTime($event->date_to);

                        // Format the date manually using the date function
                        $formatted_date_from = \Carbon\Carbon::parse($date_from->getTimestamp())->format('d. n. Y, G:i');
                        $formatted_date_to = \Carbon\Carbon::parse($date_to->getTimestamp())->format('d. n. Y, G:i');
                    ?>
                        <p><span class="glyphicon glyphicon-time"></span> Od: <?php echo $formatted_date_from; ?></p>
                        <p><span class="glyphicon glyphicon-time"></span> Do: <?php echo $formatted_date_to; ?></p>
                        <br>
                    </div>
                </div>
                <div class="col-sm-5 ">
                    <!-- Place nad capacity of the event -->
                    <h2><b>Místo konání a kapacita</b></h2>
                    <div class="col-sm-6">
                        <p><span class="glyphicon glyphicon-home"></span> Místo: {{ (isset($event->Venue->name))? $event->Venue->name : "Neuvedeno" }}</p>
                        <p><span class="glyphicon glyphicon-user"></span> Kapacita: {{ (isset($event->capacity))? $event->capacity : "Neuvedeno" }}</p>
                        <p><span class="glyphicon glyphicon-user"></span> Počet účastníků: {{ $event->Has_attendees->count() }}</p>
                        <br>
                    </div>
                </div>
                <div class="col-sm-3">
                    <!-- Manager and approved by of the event -->
                    <h2><b>Správci</b></h2>
                    <div class="col-sm-12">
                        <p><span class="glyphicon glyphicon-user"></span> Pořadatel: {{ (isset($event->Manager))? $event->Manager->first_name." ".$event->Manager->last_name : "Neuvedeno"}}</p>
                        <p><span class="glyphicon glyphicon-user"></span> Schválil: {{ (isset($event->approved_by))? $event->Approved_by->first_name." ".$event->Approved_by->last_name : "Neschváleno" }} </p>
                        <br>
                    </div>
                </div>
            </div>
            <div class="row container">
                <!-- Description -->
                <div class="col-sm-12">
                    <h2><b>Popis</b></h2>
                    <div class="col-sm-12">
                        <p> {{ (isset($event->description))? $event->description : "Bez popisu" }} </p>
                    </div>
                    <br>
                </div>
            </div>

            <div class="row container">
                <!-- Tickets -->
                <div class="col-sm-12">

                    <div class="row">
                        <h2 class="col-sm-12"><b>Lístky</b></h2> <!-- TODO MOVE BUTTON FOR ADD HERE -->
                        @if((auth()->id() == optional($event->Manager)->id) || optional(auth()->user())->admin)
                            <!-- Only for future events -->
                            @if($event->date_to > \Carbon\Carbon::now())
                                <form action="{{ route('tickets.create', $event->id) }}" method="get" class="col-md-3"
                                    id="create_ticket_button">
                                    @csrf
                                    <button type="submit" class="btn btn-primary" style="margin:0 0 20px 0;"><span></span>Vytvořit nový typ lístku</button>
                                </form>
                            @endif
                        @endif
                    </div>
                    @if ($event->Has_tickets->count())
                        @foreach($event->Has_tickets as $ticket)
                            <div class="col-sm-4" style="margin-bottom: 40px;">
                                <p><span class="glyphicon glyphicon-list-alt"></span> Typ lístku: {{ $ticket->category }}</p>
                                <p><span class="glyphicon glyphicon-list-alt"></span> Cena: {{ (isset($ticket->price))? $ticket->price. "Kč" : "Neuvedeno" }} </p>
                                @if((auth()->id() == optional($event->Manager)->id) || optional(auth()->user())->admin)
                                    @if($event->date_to > \Carbon\Carbon::now())
                                        <!-- Buttons for editing ticket -->
                                        <form action="{{ route('tickets.edit', ['event_id' => $event->id, 'ticket_id' => $ticket->id]) }}" method="get" style="display: inline;">
                                            @csrf
                                            @method('PUT')
                                            <button type="submit" class="btn btn-secondary">Upravit</button>
                                        </form>
                                        <form id="ticket_{{$ticket->id}}_delete_button" action="{{ route('tickets.destroy', ['event_id' => $event->id, 'ticket_id' => $ticket->id]) }}" method="POST" style="display: inline;">
                                            @csrf
                                            @method('DELETE')

                                            <button type="button" class="btn btn-danger" onclick="confirmDeleteTicket('{{ $ticket->category }}', '{{ $ticket->id }}')">Odstranit</button>
                                        </form>
                                    @endif
                                @endif
                                <br>
                            </div>

                        @endforeach
                    @else
                        <div class="col-sm-4">
                            <p>Nejsou uvedeny informace o lístcích</p>
                            <br>
                        </div>
                    @endif
                </div>
            </div>

            @if($event->date_to <= \Carbon\Carbon::now())
                <div class="row container">
                    <!-- Rating -->
                    <div class="col-sm-12">
                        <h2><b>Hodnocení</b></h2>
                        <div class="col-sm-6">
                            <h4>
                                <span>Celkové hodnocení: </span>

                                <span id="stars_rating">
                                    <span id="star1_read" class="fa fa-star fa-lg"></span>
                                    <span id="star2_read" class="fa fa-star fa-lg"></span>
                                    <span id="star3_read" class="fa fa-star fa-lg"></span>
                                    <span id="star4_read" class="fa fa-star fa-lg"></span>
                                    <span id="star5_read" class="fa fa-star fa-lg"></span>
                                </span>
                                <span id="stars_rating_none" style="display: none">Nehodnoceno</span>
                            </h4>
                        </div>
                    </div>
                </div>
            @endif
            <!-- Variables needed for rating -->
            <?php
            $total_rating = 0;
            $num_comments = 0;
            foreach($event->Has_comments as $comment) {
                $total_rating += $comment->rating;
            }
            $num_comments = $event->Has_comments->count();
            ?>

        </div>
    </div>
</div>

<div class="container">
    @if($event->date_to <= \Carbon\Carbon::now())
        @if ($is_attending)
            <br><br>
            <!-- Add rating -->
            <h2><b>Recenze</b></h2>
            <form action="{{ route('comments_store', ['event_id' => $event->id]) }}" method="post" role="form">
                @csrf
                <div id="add_stars_rating">
                    <span class="fa fa-star fa-lg" id="star1" onclick="add(1)"></span>
                    <span class="fa fa-star fa-lg" id="star2" onclick="add(2)"></span>
                    <span class="fa fa-star fa-lg" id="star3" onclick="add(3)"></span>
                    <span class="fa fa-star fa-lg" id="star4" onclick="add(4)"></span>
                    <span class="fa fa-star fa-lg" id="star5" onclick="add(5)"></span>
                </div>
                <input type="hidden" name="rating" id="ratingInput" value="0">
                <x-input-error :messages="$errors->get('rating')" class="mt-2" />

                <div class="form-group">
                    <textarea class="form-control" name="comment_content" id="comment_content" rows="3" required value="Přidat komentář..."></textarea>
                    <x-input-error :messages="$errors->get('comment_content')" class="mt-2" />
                </div>
                <button type="submit" class="btn btn-success">Odeslat hodnocení</button>
            </form>
        @endif
        <br><br>

        <!-- Comments -->
        <p>
            <span class="badge">{{ $event->Has_comments->count() }}</span> Komentáře
        </p><br>

        <div class="row">
            @foreach( $event->Has_comments as $comment)
                <div class="col-sm-2 text-center" style="margin-top: 10px;">
                    @if ($comment->Wrote->img_name)
                        <img height="65" width="65" class="img-fluid img-thumbnail img-circle" src="{{ asset('storage/images/users/' . $comment->Wrote->img_name) }}" alt="Profilový obrázek">
                    @else
                        <img height="65" width="65" class="img-fluid img-thumbnail img-circle" src="{{ asset('storage/images/default/user.png') }}" alt="Profilový obrázek">
                    @endif
                </div>
                <div class="col-sm-10">
                    <h4 id="comment_header">
                        <b> {{ $comment->Wrote->first_name." ".$comment->Wrote->last_name }} </b>
                        <?php
                            $user_rating = 0;
                            $user_rating = $comment->rating;
                        ?>
                        <span id="user_stars_rating">
                                    <span id="star1_user_{{$comment->id}}" class="fa fa-star fa-sm"></span>
                                    <span id="star2_user_{{$comment->id}}" class="fa fa-star fa-sm"></span>
                                    <span id="star3_user_{{$comment->id}}" class="fa fa-star fa-sm"></span>
                                    <span id="star4_user_{{$comment->id}}" class="fa fa-star fa-sm"></span>
                                    <span id="star5_user_{{$comment->id}}" class="fa fa-star fa-sm"></span>
                        </span>
                        <div id="event_comment">
                            @if((auth()->id() == optional($event->Manager)->id) || optional(auth()->user())->admin || (auth()->id() == $comment->Wrote->id))
                                <form id="comment_{{$comment->id}}_delete_button" class= "delete_button" method="POST" action="{{ route('comments_destroy', ['comment_id' => $comment->id, 'event_id' => $event->id]) }}">
                                    @csrf
                                    @method('DELETE')
                                    <button type="button"
                                            onclick="confirmDeleteComment('{{ $comment->Wrote->first_name }}', '{{ $comment->Wrote->last_name }}', '{{ $comment->created_at }}', '{{$event->name}}', '{{$comment->id}}')">
                                            <span class="glyphicon glyphicon-trash"></span></button>
                                </form>
                            @endif    
                        </div>
                    </h4>
                    <h6><span class="glyphicon glyphicon-time"></span> {{ $comment->created_at }}</h6>
                    <p> {{ $comment->content }} </p>

                    <br>
                </div>
            <script>
                // Set user event rating
                function set_user_event_rating() {
                    var user_rating = {{ $user_rating }};
                    if (user_rating < 1) {
                        document.getElementById('user_stars_rating').style.display = 'none';
                    }
                    for (var i=1;i<=5;i++) {
                        var cur=document.getElementById("star"+i+"_user_{{$comment->id}}");
                        cur.className="fa fa-star fa-sm";
                    }

                    for (var i=1;i<=user_rating;i++) {
                        var cur=document.getElementById("star"+i+"_user_{{$comment->id}}");
                        if(cur.className=="fa fa-star fa-sm") {
                            cur.className="fa fa-star fa-sm checked";
                        }
                    }
                }
                // Calling that function for each user
                set_user_event_rating();
            </script>
        @endforeach
    </div>
    @endif

    <!-- Gallery -->
    <h2><b>Galerie</b></h2>
    <div class="row text-center text-lg-start" style="padding-left: 30px; margin-bottom: 50px;">
        @if ($event->Has_images->count())
            @foreach($event->Has_images as $image)
                <div class="col-lg-4 col-md-4 col-6" id="gallery">
                    <img class="img-fluid img-thumbnail" src="{{ asset('storage/images/events/' . $image->img_path ) }}" alt="">
                    @if((auth()->id() == optional($event->Manager)->id) || optional(auth()->user())->admin)
                        <form id="image_{{$image->id}}_delete_button"
                              action="{{ route('event_image_destroy', ['event_id' => $event->id, 'image_id' => $image->id]) }}" method="post" style="display: inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" onclick="confirmDeleteImage('{{ $image->id }}')"
                                    class="btn btn-danger">Odstranit</button>
                        </form>
                    @endif
                </div>
            @endforeach
        @else
            <div class="text-left" style="padding-left: 30px;">
                <p>Tato událost nemá žádné obrázky</p>
            </div>
        @endif
    </div>

</div>

    <script>
        var eventDate = new Date('{{$event->date_to}}');
        var currentDate = new Date();

        var selectedStars = 0;
        // Add orange color to star
        function add(star_number){
            selectedStars = star_number;
            updateRatingInput();
            for (var i=1;i<=5;i++) {
                var cur=document.getElementById("star"+i)
                cur.className="fa fa-star fa-lg"
            }

            for (var i=1;i<=star_number;i++) {
                var cur=document.getElementById("star"+i)
                if(cur.className=="fa fa-star fa-lg") {
                    cur.className="fa fa-star fa-lg checked"
                }
            }
        }

        // Update the value of the hidden input field
        function updateRatingInput() {
            document.getElementById("ratingInput").value = selectedStars;
        }

        // Set total event rating
        function set_total_event_rating(){
            var total_rating = {{ $total_rating }};
            if (total_rating < 1) {
                document.getElementById("stars_rating_none").style.display = 'initial';
                document.getElementById("stars_rating").style.display = 'none';
                return;
            }
            var num_comments = {{ $num_comments }};
            total_rating = total_rating / num_comments;
            let final_rating = Math.round(total_rating);
            for (var i=1;i<=5;i++) {
                var cur=document.getElementById("star"+i+"_read");
                cur.className="fa fa-star fa-lg";
            }

            for (var i=1;i<=final_rating;i++) {
                var cur=document.getElementById("star"+i+"_read");
                if(cur.className=="fa fa-star fa-lg") {
                    cur.className="fa fa-star fa-lg checked";
                }
            }
        }

        // Confirm event delete
        function confirmDelete(event, event_id) {
            Swal.fire({
                title: 'Opravdu chcete smazat událost?',
                html: `<div>Název: <strong>${event}</strong><div>`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ano, smazat!',
                cancelButtonText: 'Zrušit',
                customClass: {
                    popup: 'custom-modal',
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    // If the user clicks "OK", submit the form
                    document.getElementById("event_"+event_id+"_delete_button").submit();
                }
            });

            return false; // Prevent the form from being submitted automatically
        }

        // Confirm comment delete
        function confirmDeleteComment(first_name, last_name, date, event, comment_id) {
            Swal.fire({
                title: 'Opravdu chcete smazat komentář?',
                html: `<div>Kdo: <strong>${first_name} ${last_name}</strong></div>
                       <div>Událost: <strong>${event}</strong></div>
                       <div>Datum: <strong>${date}</strong></div>`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ano, smazat!',
                cancelButtonText: 'Zrušit',
                customClass: {
                    popup: 'custom-modal',
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    // If the user clicks "OK", submit the form
                    document.getElementById("comment_"+comment_id+"_delete_button").submit();
                }
            });

            return false; // Prevent the form from being submitted automatically
        }

        // Confirm event unregister
        function confirmUnregister(event) {
            Swal.fire({
                title: 'Opravdu se chcete odhlásit z této události?',
                html: `<div>Událost: <strong>${event}</strong></div>`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ano, odhlásit se!',
                cancelButtonText: 'Zrušit',
                customClass: {
                    popup: 'custom-modal',
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    // If the user clicks "OK", submit the form
                    document.getElementById("unregister_form").submit();
                }
            });

            return false; // Prevent the form from being submitted automatically
        }

        // Confirm delete
        function confirmDeleteTicket(name, ticket_id) {
            Swal.fire({
                title: 'Opravdu chcete smazat typ lístku?',
                html: `<div>Typ lístku: <strong>${name}</strong></div>`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ano, smazat!',
                cancelButtonText: 'Zrušit',
                customClass: {
                    popup: 'custom-modal',
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    // If the user clicks "OK", submit the form
                    document.getElementById("ticket_"+ticket_id+"_delete_button").submit();
                }
            });

            return false; // Prevent the form from being submitted automatically
        }

        // Confirm image delete
        function confirmDeleteImage(image_id) {
            Swal.fire({
                title: 'Opravdu chcete smazat obrázek?',
                html: ``,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ano, smazat!',
                cancelButtonText: 'Zrušit',
                customClass: {
                    popup: 'custom-modal',
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    // If the user clicks "OK", submit the form
                    document.getElementById("image_"+image_id+"_delete_button").submit();
                }
            });

            return false; // Prevent the form from being submitted automatically
        }

        // Not showing when the event is in thefuture
        if (eventDate <= currentDate) {
            set_total_event_rating();
        }
    </script>
</x-app-layout>
