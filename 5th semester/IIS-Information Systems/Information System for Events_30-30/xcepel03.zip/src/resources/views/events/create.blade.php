<x-app-layout>
    <x-slot name="title">
        Vytvoření nové události
    </x-slot>

    <x-slot name="header">
        <h1>Vytvoření nové události</h1>
    </x-slot>

<div id="form_config" class="container">
    <form class="form-inline" action="{{route('events_save')}}" method ="post" enctype='multipart/form-data'>
        @csrf
        <div class="row">
            <div class="form-group col-md-6">
                <label for="name">Název události:<x-required/></label>
                <input type="text" class="form-control" id="name" name='name' value="{{ old('name') }}" required>
                <x-input-error :messages="$errors->get('name')" class="mt-2" />
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-6 event_date">
                <label for="date_from">Datum od:<x-required/></label>
                <input type="date" class="form-control" id="date_from" name="date_from"
                       data-date-format="yyyy-mm-dd"
                       value="{{ (is_null(old('date_from')))? \Carbon\Carbon::today()->format('Y-m-d') : old('date_from')}}" required>
                <input type="time" class="form-control" id="time_from" name="time_from"
                       data-time-format="H:i"
                       value="{{ (is_null(old('time_from')))? \Carbon\Carbon::now()->format('H:i') : old('time_from')}}" required>
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-6 event_date">
                <label for="date_to">Datum do:<x-required/></label>
                <input type="date" class="form-control" id="date_to" name="date_to"
                       data-date-format="yyyy-mm-dd"
                       value="{{ (is_null(old('date_to')))?  \Carbon\Carbon::today()->format('Y-m-d') : old('date_to')}}">
                <input type="time" class="form-control" id="time_to" name="time_to"
                       data-time-format="H:i"
                    value="{{ (is_null(old('time_to')))? \Carbon\Carbon::now()->addHour()->format('H:i') : old('time_to')}}">
                <x-input-error :messages="$errors->get('date_to')" class="mt-2" />
                <x-input-error :messages="$errors->get('time_to')" class="mt-2" />
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-8">
                <label for="name">Popisek:</label>
                <textarea class="form-control" id="description" name="description" rows="3" cols="40">{{ old('description') }}</textarea>
                <x-input-error :messages="$errors->get('description')" class="mt-2" />
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-8">
                <label for="capacity">Maximální kapacita:</label>
                <input type="number" class="form-control" id="capacity" name='capacity' value="{{ old('capacity') }}">
                <x-input-error :messages="$errors->get('capacity')" class="mt-2" />
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-12">
                <label for="venue">Místo konání:</label>
                <select class="form-control" name="venue" style="width: 20%; display: inline-block; margin-right: 10px;">
                    <option value=""></option>
                    @foreach($venues as $venue)
                        <option value="{{ $venue->id }}" {{old('venue') == $venue->id ? 'selected' : ''}}>{{ $venue->name }}</option>
                    @endforeach
                </select>
                <span>nebo</span>
                <a href="{{ route('venues_create') }}" class="btn btn-primary">Vytvořit nové místo konání</a>
                </div>
        </div>
        <div class="row">
            <div class="form-group col-md-8">
                <label for="category">Kategorie:</label>
                <select class="form-control" name="category" style="width: 30%; display: inline-block; margin-right: 10px;">
                    <option value=""></option>
                    @foreach($categories as $category)
                        <option value="{{ $category->id }}" {{old('category') == $category->id ? 'selected' : ''}}>{{ $category->name }}</option>
                    @endforeach
                </select>
                <span>nebo</span>
                <a href="{{ route('categories_create') }}" class="btn btn-primary">Vytvořit novou kategorii</a>
            </div>
        </div>
        <div class="row">
            <div id="image_input" class="form-group col-md-8">
                <label for="images">Obrázky:</label>
                <input type="file" class="form-control" name="images[]" id="images" multiple accept="image/*" value="{{ old('image') }}">
                <x-input-error :messages="$errors->get('images')" class="mt-2" />
            </div>
        </div>
        <x-required-text/>
        <div id="create_event_button">
            <button type="submit"><span></span>Vytvořit událost</button>
        </div>
    </form>
</div>
</x-app-layout>
