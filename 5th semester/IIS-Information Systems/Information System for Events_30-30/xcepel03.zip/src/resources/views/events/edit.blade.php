<x-app-layout>
    <x-slot name="title">
        Úprava události
    </x-slot>

    <x-slot name="header">
        <h1>Úprava události</h1>
    </x-slot>

    <!-- Form -->
    <div id="form_config" class="container">
        <form class="form-inline" action="{{ route('events.update', $event->id) }}" method="post" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            <div class="row">
                <div class="form-group col-md-6">
                    <label for="name">Název události:<x-required/></label>
                    <input type="text" class="form-control" id="name" name='name' value="{{ old('name', $event->name) }}" required>
                    <x-input-error :messages="$errors->get('name')" class="mt-2" />
                </div>
            </div>

            <div class="row">
                <div class="form-group col-md-6 event_date">
                    <label for="date_from">Datum od:<x-required/></label>
                    <input type="date" class="form-control" id="date_from" name="date_from"
                           data-date-format="yyyy-mm-dd"
                           value="{{ old('date_from', \Carbon\Carbon::parse($event->date_from)->format('Y-m-d')) }}" required>
                    <input type="time" class="form-control" id="time_from" name="time_from"
                           data-time-format="H:i"
                           value="{{ old('time_from', \Carbon\Carbon::parse($event->date_from)->format('H:i')) }}" required>
                </div>
            </div>

            <div class="row">
                <div class="form-group col-md-6 event_date">
                    <label for="date_to">Datum do:<x-required/></label>
                    <input type="date" class="form-control" id="date_to" name="date_to"
                           data-date-format="yyyy-mm-dd"
                           value="{{ old('date_to', \Carbon\Carbon::parse($event->date_to)->format('Y-m-d')) }}">
                    <input type="time" class="form-control" id="time_to" name="time_to"
                           data-time-format="H:i"
                           value="{{ old('time_to', \Carbon\Carbon::parse($event->date_to)->format('H:i')) }}">
                    <x-input-error :messages="$errors->get('date_to')" class="mt-2" />
                    <x-input-error :messages="$errors->get('time_to')" class="mt-2" />
                </div>
            </div>

            <div class="row">
                <div class="form-group col-md-8">
                    <label for="description">Popisek:</label>
                    <textarea class="form-control" id="description" name="description" rows="3" cols="40">{{ old('description', $event->description) }}</textarea>
                    <x-input-error :messages="$errors->get('description')" class="mt-2" />
                </div>
            </div>

            <div class="row">
                <div class="form-group col-md-8">
                    <label for="capacity">Maximální kapacita:</label>
                    <input type="number" class="form-control" id="capacity" name='capacity' value="{{ old('capacity', $event->capacity) }}">
                    <x-input-error :messages="$errors->get('capacity')" class="mt-2" />
                </div>
            </div>

            <div class="row">
                <div class="form-group col-md-12">
                    <label for="venue">Místo konání:</label>
                    <select class="form-control" name="venue" style="width: 20%; display: inline-block; margin-right: 10px;">
                        <option value=""></option>
                        @foreach($venues as $venue)
                            <option value="{{ $venue->id }}" {{ $event->venue == $venue->id ? 'selected' : '' }}>
                            {{ $venue->name }}
                        @endforeach
                    </select>
                    <span>nebo</span>
                    <a href="{{ route('venues_create') }}" class="btn btn-primary">Vytvořit nové místo konání</a>
                </div>
            </div>

            <div class="row">
                <div class="form-group col-md-8">
                    <label for="category">Kategorie:</label>
                    <select class="form-control" name="category" style="width: 30%; display: inline-block; margin-right: 10px;">
                        <option value=""></option>
                        @foreach($categories as $category)
                            <option value="{{ $category->id }}" {{ $event->category == $category->id ? 'selected' : '' }}>
                            {{ $category->name }}
                        @endforeach
                    </select>
                    <span>nebo</span>
                    <a href="{{ route('categories_create') }}" class="btn btn-primary">Vytvořit novou kategorii</a>
                </div>
            </div>

            <div class="row">
                <div id="image_input" class="form-group col-md-8">
                    <label for="images">Přidat další obrázky:</label>
                    <input type="file" class="form-control" name="images[]" id="images" multiple accept="image/*" value="{{ old('image') }}">
                    <x-input-error :messages="$errors->get('images')" class="mt-2" />
                </div>
            </div>

            <!-- ... (remaining form fields) ... -->


            <x-required-text/>

            <!-- Button -->
            <div id="create_event_button">
                <button type="submit"><span></span>Upravit událost</button>
            </div>
        </form>
    </div>
</x-app-layout>
