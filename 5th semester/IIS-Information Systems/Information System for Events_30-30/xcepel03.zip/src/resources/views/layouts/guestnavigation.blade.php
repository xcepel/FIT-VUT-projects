<nav class="navbar navbar-inverse navbar-fixed-top" id="navigation">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="{{route('events_index')}}">Katalog událostí</a>
            <a class="navbar-brand" href="{{route('venues_index')}}">Katalog míst konání</a>
            <a class="navbar-brand" href="{{route('categories_index')}}">Katalog kategorií</a>
        </div>
    </div>
</nav>
