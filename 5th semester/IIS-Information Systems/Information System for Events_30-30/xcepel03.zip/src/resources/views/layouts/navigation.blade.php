<nav class="navbar navbar-inverse navbar-fixed-top" id="navigation">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="{{route('events_index')}}">Katalog událostí</a>
            <a class="navbar-brand" href="{{route('venues_index')}}">Katalog míst konání</a>
            <a class="navbar-brand" href="{{route('categories_index')}}">Katalog kategorií</a>
        </div>

        <ul class="nav navbar-nav navbar-right">
            @if (Auth::check() && Auth::user()->admin)
                <li><a href="{{ route('users_index') }}"><span class="glyphicon glyphicon-edit"></span>Správa uživatelů</a></li>
            @endif

            @if(Auth::check())
                <li><a class="nav navbar-nav navbar-right" href="{{ route('comments_index', Auth::user()->id) }}"><span class="glyphicon glyphicon-user"></span>Komentáře</a></li>
                <li><a href="{{ route('events.my_events') }}"><span class="glyphicon glyphicon-th-list"></span>Moje události</a></li>
                <li><a href="{{ route('profile.edit') }}"><span class="glyphicon glyphicon-user"></span>Účet</a></li>
                <li><form id="logout" action="{{ route('logout') }}" method="POST">
                        @csrf
                        <a href="route('logout')"
                           onclick="event.preventDefault(); this.closest('form').submit();">
                            <span class="glyphicon glyphicon-log-out"></span>Odhlásit se</a>
                </form></li>
            @else
                <li><a href="{{route('login')}}"><span class="glyphicon glyphicon-log-in"></span>Přihlásit se</a></li>
                <li><a href="{{route('register')}}"><span class="glyphicon glyphicon-user"></span>Registrovat se</a></li>
            @endif
        </ul>
    </div>
</nav>
