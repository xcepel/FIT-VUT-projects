<x-app-layout>
    <x-slot name="title">
        Správa uživatelů
    </x-slot>

    <x-slot name="header">
        <h1>Správa uživatelů</h1>
    </x-slot>
    @foreach($userList as $userData)
        <div class="container">
            <div class="row">
                <div class = "col-md-3">
                    @if ($userData['img_name'])
                        <img style="height: 200px;" class="img-fluid img-thumbnail" src="{{ asset('storage/images/users/' . $userData['img_name']) }}" alt="Profilový obrázek">
                    @else
                        <img style="height: 200px;" class="img-fluid img-thumbnail" src="{{ asset('storage/images/default/user.png') }}" alt="Profilový obrázek">
                    @endif
                </div>
                <div class = "col-md-9">
                    <strong>Login:</strong> {{ $userData['login'] }}<br>
                    <strong>Jméno:</strong> {{ $userData['name'] }}<br>
                    <strong>Role:</strong> {{ $userData['role'] }}<br>
                </div>
                <div class = "col-md-9">
                    <br>
                    @if ($userData['id'] != auth()->id())
                        <strong>Změnit roli na:</strong>
                        <form method="POST" action="{{ route('users_change_role', ['user_id' => $userData['id']]) }}">
                            @csrf
                            <button type="submit" name="role" value="user">Registrovaný uživatel</button>
                            <button type="submit" name="role" value="mod">Moderátor</button>
                            <button type="submit" name="role" value="admin">Administrátor</button>
                        </form>
                        <br>
                        <span id="delete">
                            <form id="user_{{ $userData['id'] }}_delete_button" method="POST" action="{{ route('users_destroy', ['user_id' => $userData['id']]) }} ">
                                @csrf
                                @method('DELETE')
                                <button onclick="confirmDelete('{{ $userData['login'] }}', '{{ $userData['name'] }}', '{{ $userData['id'] }}')"
                                        class="glyphicon glyphicon-trash" type="button" style="font-size: 22px;"></button>
                            </form>
                        </span>
                    @endif
                </div>
            </div>


            <hr>
        </div>
    @endforeach

    <script>
        // Confirm delete
        function confirmDelete(login, name, user_id) {
            Swal.fire({
                title: 'Opravdu chcete smazat uživatele?',
                html: `<div>Login: <strong>${login}</strong><div>
                       <div>Jméno: <strong>${name}</strong><div>`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ano, smazat!',
                cancelButtonText: 'Zrušit',
                customClass: {
                    popup: 'custom-modal',
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    // If the user clicks "OK", submit the form
                    document.getElementById("user_"+user_id+"_delete_button").submit();
                }
            });

            return false; // Prevent the form from being submitted automatically
        }
    </script>

</x-app-layout>
