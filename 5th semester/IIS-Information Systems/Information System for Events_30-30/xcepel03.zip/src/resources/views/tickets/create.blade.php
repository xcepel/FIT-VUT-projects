<x-app-layout>
    <x-slot name="title">
        Vytvoření nového lístku
    </x-slot>

    <x-slot name="header">
        <h1>Vytvoření nového lístku</h1>
    </x-slot>

    <!-- Form -->
    <div id="form_config" class="container">
        <form action="{{ route('tickets.store', $event->id) }}" method="post">
            @csrf
            <div class="row">
                <div class="form-group col-md-6">
                    <label for="category">Kategorie:<x-required/></label>
                    <input type="text" name="category" id="category" required>
                    <x-input-error :messages="$errors->get('category')" class="mt-2" />
                </div>
            </div>

            <div class="row">
                <div class="form-group col-md-6">
                    <label for="price">Cena:</label>
                    <input type="number" name="price" id="price">
                    <x-input-error :messages="$errors->get('price')" class="mt-2" />
                </div>
            </div>

            <x-required-text/>

            <!-- Button -->
            <div id="create_ticket_button">
                <button type="submit" class="btn btn-default"><span></span>Vytvořit lístek</button>
            </div>
        </form>
    </div>
</x-app-layout>
