<section>
    <header>
        <h2 id="profile_information" class="text-lg font-medium text-gray-900">
            {{ __('Profile Information') }}
        </h2>

        <p class="mt-1 text-md text-gray-600">
            Zde můžete aktualizovat své profilové údaje.
        </p>
    </header>

    <form id="send-verification" method="post" action="{{ route('verification.send') }}">
        @csrf
    </form>

    <div class="col-lg-3 col-md-3 col-3 text-center" style="height: 200px; flex-direction: column; justify-content: center;">
        @if (!is_null(auth()->user()->img_name))
            <img style="height: 200px;" class="img-fluid img-thumbnail" src="{{ asset('storage/images/users/' . auth()->user()->img_name) }}" alt="Profilový obrázek">
            <form id="image_delete_button" action="{{ route('profile.image.delete') }}" method="post" style="display: inline-block; margin-top: 10px;">
                @csrf
                @method('DELETE')
                <button type="button" onclick="confirmDeleteImage()" class="btn btn-danger"><span></span>Odstranit</button>
            </form>
        @else
            <img style="height: 200px;" class="img-fluid img-thumbnail" src="{{ asset('storage/images/default/user.png') }}" alt="Profilový obrázek">
        @endif
    </div>


    <form method="post" action="{{ route('profile.update') }}" class="mt-6 space-y-6" enctype='multipart/form-data'>
        @csrf
        @method('patch')

        <div id="profile_info" class="form-group row">
            <div class="col-md-3">
                <x-input-label for="login" :value="__('Přihlašovací jméno')"/>
            </div>
            <div class="col-md-5">
                <div id="profile_info_login">
                    <x-text-input id="login" name="login" type="text" class="mt-1 block w-full" value="{{ $user->login }}" required autofocus autocomplete="login" />
                    <x-input-error class="mt-2" :messages="$errors->get('login')" />
                </div>
            </div>

            <div class="col-md-3">
                <x-input-label for="first_name" :value="__('Jméno')"/>
            </div>
            <div class="col-md-5">
                <div id="profile_info_first_name">
                    <x-text-input id="first_name" name="first_name" type="first_name" class="mt-1 block w-full" value="{{ $user->first_name }}" required autocomplete="first_name" />
                    <x-input-error class="mt-2" :messages="$errors->get('first_name')" />
                </div>
            </div>

            <div class="col-md-3">
                <x-input-label for="last_name" :value="__('Příjmení')"/>
            </div>
            <div class="col-md-5">
                <div id="profile_info_last_name">
                    <x-text-input id="last_name" name="last_name" type="last_name" class="mt-1 block w-full" value="{{ $user->last_name }}" required autocomplete="last_name" />
                    <x-input-error class="mt-2" :messages="$errors->get('last_name')" />
                </div>
            </div>

            <div class="col-md-3">
                <x-input-label for="image" :value="__('Nový profilový obrázek')" />
            </div>
            <div class="col-md-5">
                <div id="image_input">
                    <input type="file" class="form-control" id="image" name="image" accept="image/*" value="{{ old('image') }}">
                    <x-input-error :messages="$errors->get('image')" class="mt-2" />
                </div>
            </div>
        </div>

        <div id="profile_info_button" class="col-md-12">
            <div class="flex items-center gap-4 text-center">
                <div id="create_event_button">
                    <button type="submit"><span></span>Uložit</button>
                </div>

                @if (session('status') === 'profile-updated')
                    <p
                        x-data="{ show: true }"
                        x-show="show"
                        x-transition
                        x-init="setTimeout(() => show = false, 2000)"
                        class="text-sm text-gray-600"
                    >{{ __('Saved.') }}</p>
                @endif
            </div>
        </div>
    </form>

    <script>
    // Confirm image delete
    function confirmDeleteImage() {
        Swal.fire({
            title: 'Opravdu chcete smazat obrázek?',
            html: ``,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Ano, smazat!',
            cancelButtonText: 'Zrušit',
            customClass: {
                popup: 'custom-modal',
            }
        }).then((result) => {
            if (result.isConfirmed) {
                // If the user clicks "OK", submit the form
                document.getElementById("image_delete_button").submit();
            }
        });

        return false; // Prevent the form from being submitted automatically
    }

    </script>

</section>
