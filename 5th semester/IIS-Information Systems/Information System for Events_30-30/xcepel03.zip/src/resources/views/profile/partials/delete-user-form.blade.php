<section class="space-y-6">
    <header>
        <h2 class="text-lg font-medium text-gray-900" style="font-size: 3em;">
            {{ __('Delete Account') }}
        </h2>

        <p class="mt-1 text-sm text-gray-600">
            Jakmile bude váš účet smazán, všechna jeho data budou trvale smazána. Před smazáním účtu si prosím uložte všechna data a informace, které chcete zachovat.
        </p>
    </header>

    <form id="user_{{$user->id}}_delete_button" method="POST" action="{{ route('profile.destroy')}}" class="delete_button user">
        <div  class="container text-center">
            @csrf
            @method('DELETE')
            <div class="delete_button profile">
                <button onclick="confirmDelete('{{$user->login}}', '{{$user->id}}')"
                        type="button"><span></span>Smazat účet</button>
            </div>
        </div>
    </form>
</section>

<script>
    // Confirm delete
    function confirmDelete(user_login, user_id) {
        Swal.fire({
            title: 'Opravdu chcete smazat uživatele?',
            html: `<div>Login: <strong>${user_login}</strong><div>`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Ano, smazat!',
            cancelButtonText: 'Zrušit',
            customClass: {
                popup: 'custom-modal',
            }
        }).then((result) => {
            if (result.isConfirmed) {
                // If the user clicks "OK", submit the form
                document.getElementById("user_"+user_id+"_delete_button").submit();
            }
        });

        return false; // Prevent the form from being submitted automatically
    }
</script>
