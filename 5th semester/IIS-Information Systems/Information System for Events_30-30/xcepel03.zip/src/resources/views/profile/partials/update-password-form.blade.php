<section>
    <header>
        <h2 class="text-lg font-medium text-gray-900" style="font-size: 3em;">
            Změnit heslo
        </h2>

    </header>

    <div class="container mx-auto">
        <form method="post" action="{{ route('password.update') }}" >
            @csrf
            @method('put')

            <div style="margin-bottom: 20px;">
                <x-input-label for="current_password" :value="__('Current Password')" style="margin-right: 15px;"/>
                <x-text-input id="current_password" name="current_password" type="password" class="mt-1 block w-full" autocomplete="current-password" />
                <x-input-error :messages="$errors->updatePassword->get('current_password')" class="mt-2" style="margin-top: 10px; color: red;"/>
            </div>

            <div style="margin-bottom: 20px;">
                <x-input-label for="password" :value="__('New Password')" style="margin-right: 45px;"/>
                <x-text-input id="password" name="password" type="password" class="mt-1 block w-full" autocomplete="new-password" />
                <x-input-error :messages="$errors->updatePassword->get('password')" class="mt-2" style="margin-top: 10px; color: red;"/>
            </div>

            <div style="margin-bottom: 20px;">
                <x-input-label for="password_confirmation" :value="__('Confirm Password')" style="margin-right: 13px;"/>
                <x-text-input id="password_confirmation" name="password_confirmation" type="password" class="mt-1 block w-full" autocomplete="new-password" />
                <x-input-error :messages="$errors->updatePassword->get('password_confirmation')" class="mt-2" style="margin-top: 10px; color: red;"/>
            </div>

            <div class="flex items-center gap-4">
                <div id="create_event_button">
                    <button type="submit"><span></span>Uložit</button>
                </div>

                @if (session('status') === 'password-updated')
                    <p
                        x-data="{ show: true }"
                        x-show="show"
                        x-transition
                        x-init="setTimeout(() => show = false, 2000)"
                        class="text-sm text-gray-600"
                    >{{ __('Saved.') }}</p>
                @endif
            </div>
        </form>
    </div>
</section>
