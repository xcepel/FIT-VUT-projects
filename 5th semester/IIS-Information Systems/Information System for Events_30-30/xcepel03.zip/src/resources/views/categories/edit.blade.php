<x-app-layout>
    <x-slot name="title">
        Úprava kategorie
    </x-slot>

    <x-slot name="header">
        <h1>Úprava kategorie</h1>
    </x-slot>

    <!-- Form -->
    <div id="form_config" class="container">
        <form action="{{ route('categories.update', $category->id) }}" method="post">
            @csrf
            @method('PUT')

            <div class="row">
                <div class="form-group col-md-6">
                    <label for="name">Jméno:<x-required/></label>
                    <input type="text" name="name" id="name" value="{{ old('name', $category->name) }}" required>
                    <x-input-error :messages="$errors->get('name')" class="mt-2" />
                </div>
            </div>

            <div class="row">
                <div class="form-group col-md-1">
                    <label for="supertype_id">Nadtyp:</label>
                </div>
                <div class="form-group col-md-3">
                    <select class="form-control" name="supertype_id" id="supertype_id" style="margin-left: 30px;">
                        <option value=""></option>
                        @foreach ($categories as $supertype)
                            @if ($supertype->id != $category->id) <!-- Exclude the current category -->
                                <option value="{{ $supertype->id }}" {{ $category->is_subtype_of == $supertype->id ? 'selected' : '' }}>
                                    {{ $supertype->name }}
                                </option>
                            @endif
                        @endforeach
                    </select>
                </div>
            </div>

            <x-required-text/>

            <!-- Button -->
            <div id="create_event_button">
                <button type="submit" class="btn btn-default"><span></span>Upravit kategorii</button>
            </div>
        </form>
    </div>
</x-app-layout>
