<x-app-layout>
    <x-slot name="title">
        Kategorie
    </x-slot>

    <x-slot name="header">
        <h1>Kategorie</h1>
    </x-slot>

    @if((optional(auth()->user())->mod) || optional(auth()->user())->admin)
        <div id="categories_buttons" class="container text-center">
            <button id="categories_button" onclick="categories()"><span></span>Všechny kategorie</button>
            <button id="no_approval_categories_button" onclick="no_approval_categories()"><span></span>Kategorie bez potvrzení</button>
        </div>
    @endif

    <!-- Creation of the category -->
    <div id="create_category_button" class="container text-center">
        <form class="form-horizontal" method="get" action="{{route('categories_create')}}">
            {{ csrf_field() }}<button type="submit" class="btn btn-primary"><span></span>Přidat novou kategorii</button>
        </form>
    </div>

    <div id="categories" class="container">
        <table id="categories_table" class="table table-hover table-bordered">
            <thead>
                <tr>
                    <th scope="col">Jméno</th>
                    <th scope="col">Události</th>
                </tr>
            </thead>
            <?php
                foreach ($categoryList as $category) {          
                    if($category['subtype_of'] == NULL) {
                        echo "<tr onclick=\"window.location='" . route('categories_detail', $category['id']) . "';\">";
                        echo "<td>";
                        echo "<strong>".$category['name']."</strong>";
                        echo "</td>"; 
                        echo "<td>";
                        $links = [];
                        foreach ($category['events'] as $event) {
                            $links[] = '<a href="' . route('events_detail', $event['id']) . '">' . $event['name'] . '</a>';
                        }
                        $combined = implode(', ', $links);
                        echo $combined;
                        echo "</td>";
                        echo "</tr>";
                    } else {
                        $super_types = implode(' -> ', array_reverse($category['subtype_of']));
                        echo "<tr onclick=\"window.location='" . route('categories_detail', $category['id']) . "';\">";
                        echo "<td>".$super_types." -> <strong>".$category['name']."</strong></td>";
                        echo "<td>";
                        $links = [];
                        foreach ($category['events'] as $event) {
                            $links[] = '<a href="' . route('events_detail', $event['id']) . '">' . $event['name'] . '</a>';
                        }
                        $combined = implode(', ', $links);
                        echo $combined;
                        echo "</td>";
                        echo "</tr>";
                    }
                }
            ?>
        </table>
    </div>

    <div id="no_approval_categories" class="container">
        <table id="no_approval_categories_table" class="table table-hover table-bordered">
            <thead>
                <tr>
                    <th scope="col">Jméno</th>
                    <th scope="col">Události</th>
                </tr>
            </thead>
            <?php
                foreach ($notApprovedCategoryList as $category) {          
                    if($category['subtype_of'] == NULL) {
                        echo "<tr onclick=\"window.location='" . route('categories_detail', $category['id']) . "';\">";
                        echo "<td>";
                        echo "<strong>".$category['name']."</strong>";
                        echo "</td>"; 
                        echo "<td>";
                        $links = [];
                        foreach ($category['events'] as $event) {
                            $links[] = '<a href="' . route('events_detail', $event['id']) . '">' . $event['name'] . '</a>';
                        }
                        $combined = implode(', ', $links);
                        echo $combined;
                        echo "</td>";
                        echo "</tr>";
                    } else {
                        $super_types = implode(' -> ', array_reverse($category['subtype_of']));
                        echo "<tr onclick=\"window.location='" . route('categories_detail', $category['id']) . "';\">";
                        echo "<td>".$super_types." -> <strong>".$category['name']."</strong></td>";
                        echo "<td>";
                        $links = [];
                        foreach ($category['events'] as $event) {
                            $links[] = '<a href="' . route('events_detail', $event['id']) . '">' . $event['name'] . '</a>';
                        }
                        $combined = implode(', ', $links);
                        echo $combined;
                        echo "</td>";
                        echo "</tr>";
                    }
                }
            ?>
        </table>
    </div>

    <script>
        $(document).ready(
            function () {
                $('#categories_table').DataTable({
                    "language": {
                        "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Czech.json"
                    },
                    "aaSorting": [[0, 'asc']]
                });
                $('#no_approval_categories_table').DataTable({
                    "language": {
                        "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Czech.json"
                    },
                    "aaSorting": [[0, 'asc']]
                });
            }
        );
        var categories_table = document.getElementById('categories');
        var categories_table_style = window.getComputedStyle(categories_table);
        var categories_button = document.getElementById('categories_button');

        var no_approval_categories_table = document.getElementById('no_approval_categories');
        var no_approval_categories_table_style = window.getComputedStyle(no_approval_categories_table);
        var no_approval_categories_button = document.getElementById('no_approval_categories_button');

        // Function to toggle the visibility of the categories
        function categories() {
            if (categories_table_style.display === 'none') {
                categories_table.style.display = 'block';
                categories_button.style.background = 'royalblue';
                categories_button.style.color = 'black';
                no_approval_categories_table.style.display = 'none';
                no_approval_categories_button.style.background = 'white';
                no_approval_categories_button.style.color = 'black';
            }
        }

        // Function to toggle the visibility of the no approval categories
        function no_approval_categories() {
            if (no_approval_categories_table_style.display === 'none') {
                no_approval_categories_table.style.display = 'block';
                no_approval_categories_button.style.background = 'royalblue';
                no_approval_categories_button.style.color = 'black';
                categories_table.style.display = 'none';
                categories_button.style.background = 'white';
                categories_button.style.color = 'black';
            }
        }
    </script>

</x-app-layout>
