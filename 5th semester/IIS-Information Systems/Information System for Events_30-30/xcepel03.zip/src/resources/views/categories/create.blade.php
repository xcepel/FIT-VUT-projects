<x-app-layout>
    <x-slot name="title">
        Vytvoření nové kategorie
    </x-slot>

    <x-slot name="header">
        <h1>Vytvoření nové kategorie</h1>
    </x-slot>

    <!-- Form -->
    <div id="form_config" class="container">
        <form action="{{ route('categories_save') }}" method="post">
            @csrf
            <div class="row">
                <div class="form-group col-md-6">
                    <label for="name">Jméno:<x-required/></label>
                    <input type="text" name="name" id="name" required>
                    <x-input-error :messages="$errors->get('name')" class="mt-2" />
                </div>
            </div>

            <div class="row">
                <div class="form-group col-md-1">
                    <label for="supertype_id">Nadtyp:</label>
                </div>
                <div class="form-group col-md-3">
                    <select class="form-control" name="supertype_id" id="supertype_id" style="margin-left: 30px;">
                        <option value=""></option>
                        @foreach ($categories as $parentCategory)
                            <option value="{{ $parentCategory->id }}">{{ $parentCategory->name }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <x-required-text/>
            <!-- Button -->
            <div id="create_event_button">
                <button type="submit" class="btn btn-default"><span></span>Vytvořit kategorii</button>
            </div>
        </form>
    </div>
</x-app-layout>
