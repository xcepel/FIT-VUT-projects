<x-app-layout>
    <x-slot name="title">
        Detail události
    </x-slot>

    <x-slot name="header">
        <h1>{{ $categoryData['name'] }}</h1>
    </x-slot>

    
    <div class="container">
        @if((optional(auth()->user())->mod) || optional(auth()->user())->admin)
            <div class="row">
                <div id="edit_category_button" class="text-left col-md-4">
                    <form action="{{ route('categories.edit', $categoryData['id']) }}" method="GET">
                        @csrf
                        <button type="submit" class="btn btn-primary" style="margin-top: 0;"><span></span>Upravit</button>
                    </form>
                </div>
                <div id="approve_category_button" class="text-right col-md-6" style="padding-right: 0;">
                    @if (!$categoryData['approved_by'])
                        <form action="{{ route('categories.approve', ['category_id' => $categoryData['id']]) }}" method="post">
                            @csrf
                            <button type="submit"><span></span>Schválit kategorii</button>
                        </form>
                    @endif
                </div>
                <div class="text-right col-md-1" style="padding-left: 0;">
                    <form action="{{ route('categories_destroy', ['category_id' => $categoryData['id']]) }}" 
                        class="delete_button category" method="post" onsubmit="return confirm('Are you sure you want to delete this category?')">
                        @csrf
                        @method('DELETE')
                        <button type="submit"><span class="glyphicon glyphicon-trash"></span></button>
                    </form>
                </span>
            </div>
        @endif


        <div id="detail_category" class="row-content">
            <div>
                <div class="row container">
                    <div class="col-sm-5">
                        <!-- Date and time of the venue -->
                        <h2><b>Schváleno</b></h2>
                        <div class="col-sm-9">
                            <p>{{ $categoryData['approved_by'] ?: 'Neschváleno' }}</p>
                            <br>
                        </div>
                    </div>
                </div>
                <div class="row container">
                    <div class="col-sm-6">
                        <!-- Manager and approved by of the venue -->
                        <h2><b>Nadtypy</b></h2>
                        <div class="col-sm-12">
                            @if (!empty($categoryData['subtype_of']))
                                <ul>
                                    @foreach ($categoryData['subtype_of'] as $supertype)
                                        <li>{{ $supertype }}</li>
                                    @endforeach
                                </ul>
                            @else
                                <p>Nemá nadtypy</p>
                            @endif
                            <br>
                        </div>
                    </div>                
                    <!-- Description -->
                    <div class="col-sm-6">
                        <h2><b>Podtypy</b></h2>
                        <div class="col-sm-12">
                            @if (!empty($categoryData['subtypes']))
                                <ul>
                                    @foreach ($categoryData['subtypes'] as $subtype)
                                        <li>{{ $subtype }}</li>
                                    @endforeach
                                </ul>
                            @else
                                <p>Nemá podtypy</p>
                            @endif
                            <br>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <h2><b>Události</b></h2>
                        <div class="col-sm-12" style="padding-left: 0;">
                            @if (!empty($categoryData['events']))
                            <div id="categories" class="container" style="width: 50%; margin-left:0;">
                                    <table id="categories_table" class="table table-hover table-bordered">
                                        <thead>
                                            <tr>
                                                <th scope="col">Události</th>
                                            </tr>
                                        </thead>
                                        <?php        
                                            foreach ($categoryData['events'] as $event) {
                                                echo "<tr onclick=\"window.location='" . route('events_detail', $event['id']) . "';\">";
                                                echo "<td>";
                                                echo $event['name'];
                                                echo "</td>";
                                                echo "</tr>";
                                            }
                                        ?>
                                    </table>
                                </div>
                            @else
                                <p>Žádné události s touto kategorií</p>
                            @endif
                            <br>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    <script>
        $(document).ready(
            function () {
                $('#categories_table').DataTable({
                    "language": {
                        "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Czech.json"
                    },
                    "aaSorting": [[0, 'asc']],
                });;
            }
        );
    </script>


</x-app-layout>
