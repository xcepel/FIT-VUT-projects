<span {{ $attributes->merge(['style' => 'color: red; margin: 0 0 0 2px;']) }}>
    *
</span>