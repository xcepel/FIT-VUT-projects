@props(['disabled' => false])

<input {{ $disabled ? 'disabled' : '' }} {!! $attributes->merge(['class' => 'border-gray-300 focus:border-royal-blue focus:ring-royal-blue rounded-md shadow-sm',
 'style' => 'font-size: 20px; height: 40px;']) !!}>
