<div {{ $attributes->merge(['style' => 'color: red; margin: 0 0 10px 20px;']) }}>
    Řádky označené červenou hvězdičkou jsou povinné.
</div>