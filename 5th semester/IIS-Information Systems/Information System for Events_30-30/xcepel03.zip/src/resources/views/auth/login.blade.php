<x-guest-layout>
    <x-slot name="title">
        Přihlášení
    </x-slot>

    <x-slot name="header">
        <h1>Přihlášení</h1>
    </x-slot>

    <!-- Session Status -->
    <x-auth-session-status class="mb-4" :status="session('status')" />

    <div class="container text-left" id="login_screen">
        <form method="POST" action="{{ route('login') }}">
            @csrf

            <!-- Login -->
            <div>
                <x-input-label for="login" :value="__('Přihlašovací jméno')" />
                <x-text-input id="login" class="block mt-1 w-full" type="text" name="login" :value="old('login')" required autofocus autocomplete="login" />
                <x-input-error :messages="$errors->get('login')" class="mt-2 login_error" />
            </div>

            <!-- Password -->
            <div class="mt-4">
                <x-input-label for="password" :value="__('Heslo')" />

                <x-text-input id="password" class="block mt-1 w-full"
                                type="password"
                                name="password"
                                required autocomplete="current-password" />

                <x-input-error :messages="$errors->get('password')" class="mt-2 login_error" />
            </div>

            <div class="flex items-center justify-end mt-4">
                <a class="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500" style="font-size: 18px; text-decoration: underline;" href="{{ route('register') }}">
                    {{ __('Ještě nemám účet') }}
                </a>

                <x-primary-button class="ms-3">
                    {{ __('Přihlásit') }}
                </x-primary-button>
            </div>
        </form>
    </div>
</x-guest-layout>
