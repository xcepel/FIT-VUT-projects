<x-guest-layout>
    <x-slot name="title">
        Registrace
    </x-slot>

    <x-slot name="header">
        <h1>Registrace</h1>
    </x-slot>

    <div class="container text-left" id="register_screen">
        <form method="POST" action="{{ route('register') }}" enctype='multipart/form-data'>
            @csrf

            <!-- Login -->
            <div>
            <x-input-label for="login">Přihlašovací jméno <x-required/></x-input-label>
                <x-text-input id="login" class="block mt-1 w-full" type="text" name="login" :value="old('login')" required autofocus autocomplete="login" />
                <x-input-error :messages="$errors->get('login')" class="mt-2" />
            </div>

            <!-- First name -->
            <div class="mt-4">
                <x-input-label for="first_name">Jméno <x-required/></x-input-label>
                <x-text-input id="first_name" class="block mt-1 w-full" type="text" name="first_name" :value="old('first_name')" required autofocus autocomplete="first_name" />
                <x-input-error :messages="$errors->get('first_name')" class="mt-2" />
            </div>

            <!-- Last name -->
            <div class="mt-4">
                <x-input-label for="last_name">Příjmení <x-required/></x-input-label>
                <x-text-input id="last_name" class="block mt-1 w-full" type="text" name="last_name" :value="old('last_name')" required autofocus autocomplete="last_name" />
                <x-input-error :messages="$errors->get('last_name')" class="mt-2" />
            </div>

            <!-- Password -->
            <div class="mt-4">
                <x-input-label for="password">Heslo <x-required/></x-input-label>
                <x-text-input id="password" class="block mt-1 w-full"
                                type="password"
                                name="password"
                                required autocomplete="new-password" />

                <x-input-error :messages="$errors->get('password')" class="mt-2" />
            </div>

            <!-- Confirm Password -->
            <div class="mt-4">
                <x-input-label for="password_confirmation">Potvrďte heslo <x-required/></x-input-label>

                <x-text-input id="password_confirmation" class="block mt-5 w-full"
                                type="password"
                                name="password_confirmation" required autocomplete="new-password" />

                <x-input-error :messages="$errors->get('password_confirmation')" class="mt-2" />
            </div>



            <div id="image_input" class="mt-4">
                <x-input-label for="image" :value="__('Profilový obrázek')" />
                <input type="file" class='block mt-5 w-full border-gray-300 rounded-md shadow-sm'
                    id="image" name="image" accept="image/*" value="{{ old('image') }}">
            </div>

            <x-required-text style="margin-left: 0px;"/>

            <div class="flex items-center justify-end mt-4">
                <a class="underline text-md text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500" style="font-size: 18px; text-decoration: underline;" href="{{ route('login') }}">
                    {{ __('Již mám vytvořený účet') }}
                </a>

                <x-primary-button class="ms-4">
                    {{ __('Registrovat') }}
                </x-primary-button>
            </div>
        </form>
    <div>
</x-guest-layout>
