<x-app-layout>
    <x-slot name="title">
        Správa komentářů
    </x-slot>

    <x-slot name="header">
        @if (auth()->user()->mod || auth()->user()->admin)
            <h1>Správa komentářů</h1>
        @else
            <h1>Moje komentáře</h1>
        @endif
    </x-slot>

    <div id="past_events_moderate" class="container text-left">
        @if ($events->count())
            <div class="row">
                <div class="row underline">
                    <div class="row">
                        <div class="col-md-4 moderate_title">Událost</div>
                        <div class="col-md-8 moderate_title">Komentáře</div>
                    </div>
                </div>
            </div>
            <div class="row ">
                @foreach($events as $event)
                    <div class="row underline">
                            <?php // php script for change of appearance of date
                            $date_from = new DateTime($event->date_from);
                            $date_to = new DateTime($event->date_to);
                            $formatted_date_from = \Carbon\Carbon::parse($date_from->getTimestamp())->format('d. n. Y, G:i');
                            $formatted_date_to = \Carbon\Carbon::parse($date_to->getTimestamp())->format('d. n. Y, G:i');
                            ?>
                        <div class="col-md-4">
                            <div id="event_name" onclick="window.location='{{route('events_detail', $event->id)}}';" style="cursor: pointer">{{ $event->name }} </div>
                            <div><b>Místo:</b> {{ is_null($event->Venue) ? 'Neuvedeno' : $event->Venue->name }}</div>
                            <div><b>Od:</b> <?php echo $formatted_date_from; ?></div>
                            <div><b>Do:</b> <?php echo $formatted_date_to; ?></div>
                        </div>
                        <div class="col-md-8 sideline">
                            <?php // php script to remove other user's comments if not mod/admin
                            if (!auth()->user()->mod && !auth()->user()->admin) {
                                $comments = $event->Has_comments->filter(function ($comment) {
                                    return $comment->Wrote->id == auth()->id();
                                });
                            }
                            else {
                                $comments = $event->Has_comments;
                            }
                            ?>
                            @foreach($comments as $comment)
                                <div class="col-sm-2" style="margin-top: 10px;">
                                    @if ($comment->Wrote->img_name)
                                        <img height="65" width="65" class="img-fluid img-thumbnail img-circle" src="{{ asset('storage/images/users/' . $comment->Wrote->img_name) }}" alt="Profilový obrázek">
                                    @else
                                        <img height="65" width="65" class="img-fluid img-thumbnail img-circle" src="{{ asset('storage/images/default/user.png') }}" alt="Profilový obrázek">
                                    @endif
                                </div>
                                <div id="comment">
                                    <h4>
                                        <b> {{ $comment->Wrote->first_name." ".$comment->Wrote->last_name }} </b>
                                            <?php
                                            $user_rating = 0;
                                            $user_rating = $comment->rating;
                                            ?>
                                        <span id="user_stars_rating">
                                            <span id="star1_user_{{$comment->id}}" class="fa fa-star fa-sm"></span>
                                            <span id="star2_user_{{$comment->id}}" class="fa fa-star fa-sm"></span>
                                            <span id="star3_user_{{$comment->id}}" class="fa fa-star fa-sm"></span>
                                            <span id="star4_user_{{$comment->id}}" class="fa fa-star fa-sm"></span>
                                            <span id="star5_user_{{$comment->id}}" class="fa fa-star fa-sm"></span>
                                        </span>
                                        <span id="delete">
                                            <form id="comment_{{$comment->id}}_delete_button" method="POST" action="{{ route('comments_destroy', ['comment_id' => $comment->id, 'event_id' => 0]) }}">
                                                @csrf
                                                @method('DELETE')
                                                <button onclick="confirmDelete('{{ $comment->Wrote->first_name }}', '{{ $comment->Wrote->last_name }}', '{{ $comment->created_at }}' , '{{$event->name}}', '{{$comment->id}}')"
                                                        class="glyphicon glyphicon-trash" type="button"></button>
                                            </form>

                                        </span>
                                    </h4>

                                    <h6><span class="glyphicon glyphicon-time"></span> {{ $comment->created_at }}</h6>
                                    <p> {{ $comment->content }} </p>
                                </div>

                                <script>
                                    // Set user event rating
                                    function set_user_event_rating() {
                                        var user_rating = {{ $user_rating }};
                                        if (user_rating < 1) {
                                            document.getElementById('user_stars_rating').style.display = 'none';
                                        }
                                        for (var i=1;i<=5;i++) {
                                            var cur=document.getElementById("star"+i+"_user_{{$comment->id}}");
                                            cur.className="fa fa-star fa-sm";
                                        }

                                        for (var i=1;i<=user_rating;i++) {
                                            var cur=document.getElementById("star"+i+"_user_{{$comment->id}}");
                                            if(cur.className=="fa fa-star fa-sm") {
                                                cur.className="fa fa-star fa-sm checked";
                                            }
                                        }
                                    }
                                    // Calling that function for each user
                                    set_user_event_rating();
                                </script>
                            @endforeach
                        </div>
                    </div>
                @endforeach
            </div>
        @else
            <h3>Žádné komentáře k zobrazení</h3>
        @endif
    </div>



    <script>
        $(document).ready(
            function () {
                $('#future_events_table').DataTable({
                    "language": {
                        "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Czech.json"
                    },
                    "aaSorting": [],
                    columnDefs: [{
                        orderable: false,
                        targets: 0
                    }]
                });
                $('#past_events_table').DataTable({
                    "language": {
                        "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Czech.json"
                    },
                    "aaSorting": [],
                    columnDefs: [{
                        orderable: false,
                        targets: 0
                    }]
                });
            }
        );
        // Confirm delete
        function confirmDelete(first_name, last_name, date, event, comment_id) {
            Swal.fire({
                title: 'Opravdu chcete smazat komentář?',
                html: `<div>Kdo: <strong>${first_name} ${last_name}</strong></div>
                       <div>Událost: <strong>${event}</strong></div>
                       <div>Datum: <strong>${date}</strong></div>`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ano, smazat!',
                cancelButtonText: 'Zrušit',
                customClass: {
                    popup: 'custom-modal',
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    // If the user clicks "OK", submit the form
                    document.getElementById("comment_"+comment_id+"_delete_button").submit();
                }
            });

            return false; // Prevent the form from being submitted automatically
        }
    </script>

</x-app-layout>
