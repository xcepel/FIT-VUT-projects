<x-app-layout>
    <x-slot name="title">
        Místa konání
    </x-slot>

    <x-slot name="header">
        <h1>Místa konání</h1>
    </x-slot>

    <!-- Sort venues buttons -->
    @if((optional(auth()->user())->mod) || optional(auth()->user())->admin)
        <div id="venue_buttons" class="container text-center">
            <button id="venues_button" onclick="venues()"><span></span>Všechna místa konání</button>
            <button id="no_approval_venues_button" onclick="no_approval_venues()"><span></span>Místa konání bez potvrzení</button>
        </div>
    @endif

   <!-- Create venue button -->
    <div id="create_venue_button" class="container text-center">
        <form class="form-horizontal" method="get" action="{{route('venues_create')}}">
            {{ csrf_field() }}<button type="submit" class="btn btn-primary"><span></span>Přidat nové místo konání</button>
        </form>
    </div>


    <!-- List of venues -->
    <div id="venues" class="container">
        <table id="venues_table" class="table table-hover table-bordered">
            <thead>
            <tr>
                <th scope="col"></th>
                <th scope="col">Název</th>
                <th scope="col">Město</th>
                <th scope="col">Adresa</th>
            </tr>
            </thead>
            <tbody>
            @foreach($venues as $venue)
                <tr onclick="window.location='{{route('venues_detail', $venue->id)}}';">
                    <td>
                        @if ($venue->Has_images->count())
                            <img class="img-fluid img-thumbnail" src="{{ asset('storage/images/venues/' . $venue->Has_images->first()->img_path ) }}" alt="">
                        @else
                            <img class="img-fluid img-thumbnail" src="{{ asset('storage/images/default/venue.png') }}" alt="Výchozí obrázek">
                        @endif
                   </td>
                    <td>{{ $venue->name }}</td>
                    <td>{{ $venue->address_city }}</td>
                    <td>{{ $venue->address_street }} {{ $venue->address_house_num }}</td>
                </tr>
                <br>
            @endforeach
            </tbody>
        </table>
    </div>

    <div id="no_approval_venues" class="container">
        <table id="no_approval_venues_table" class="table table-hover table-bordered">
            <thead>
            <tr>
                <th></th>
                <th scope="col">Název</th>
                <th scope="col">Město</th>
                <th scope="col">Adresa</th>
            </tr>
            </thead>
            <tbody>
            @foreach($no_approval_venues as $venue)
                <tr onclick="window.location='{{route('venues_detail', $venue->id)}}';">
                    <td>
                        @if ($venue->Has_images->count())
                            <img class="img-fluid img-thumbnail" src="{{ asset('storage/images/venues/' . $venue->Has_images->first()->img_path ) }}" alt="">
                        @else
                            <img class="img-fluid img-thumbnail" src="{{ asset('storage/images/default/venue.png') }}" alt="Výchozí obrázek">
                        @endif
                    </td>
                    <td>{{ $venue->name }}</td>
                    <td>{{ $venue->address_city }}</td>
                    <td>{{ $venue->address_street }} {{ $venue->address_house_num }}</td>
                </tr>
                <br>
            @endforeach
            </tbody>
        </table>
    </div>

    <script>
        $(document).ready(
            function () {
                $('#venues_table').DataTable({
                    "language": {
                        "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Czech.json"
                    },
                    "aaSorting": [],
                    columnDefs: [{
                        orderable: false,
                        targets: 0
                    }]
                });
                $('#no_approval_venues_table').DataTable({
                    "language": {
                        "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Czech.json"
                    },
                    "aaSorting": [],
                    columnDefs: [{
                        orderable: false,
                        targets: 0
                    }]
                });
            }
        );

        var venues_table = document.getElementById('venues');
        var venues_table_style = window.getComputedStyle(venues_table);
        var venues_button = document.getElementById('venues_button');

        var no_approval_venues_table = document.getElementById('no_approval_venues');
        var no_approval_venues_table_style = window.getComputedStyle(no_approval_venues_table);
        var no_approval_venues_button = document.getElementById('no_approval_venues_button');

        // Function to toggle the visibility of the venues
        function venues() {
            if (venues_table_style.display === 'none') {
                venues_table.style.display = 'block';
                venues_button.style.background = 'royalblue';
                venues_button.style.color = 'black';
                no_approval_venues_table.style.display = 'none';
                no_approval_venues_button.style.background = 'white';
                no_approval_venues_button.style.color = 'black';
            }
        }

        // Function to toggle the visibility of the no approval venues
        function no_approval_venues() {
            if (no_approval_venues_table_style.display === 'none') {
                no_approval_venues_table.style.display = 'block';
                no_approval_venues_button.style.background = 'royalblue';
                no_approval_venues_button.style.color = 'black';
                venues_table.style.display = 'none';
                venues_button.style.background = 'white';
                venues_button.style.color = 'black';
            }
        }

    </script>

</x-app-layout>
