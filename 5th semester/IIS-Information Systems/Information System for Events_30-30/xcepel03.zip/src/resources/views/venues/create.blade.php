<x-app-layout>
    <x-slot name="title">
        Přidání nového místa
    </x-slot>

    <x-slot name="header">
        <h1>Přidání nového místa</h1>
    </x-slot>

<div id="form_config" class="container">
    <form class="form-inline" action="{{route('venues_store')}}" method ="post" enctype='multipart/form-data'>
        @csrf
        <div class="row">
            <div class="form-group col-md-8">
                <label for="name">Jméno:<x-required/></label>
                <input type="text" class="form-control" id="name" name='name' value="{{ old('name') }}" required>
                <x-input-error :messages="$errors->get('name')" class="mt-2" />
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-8">
                <label for="name">Město:</label>
                <input type="text" class="form-control" id="address_city" name='address_city' value="{{ old('address_city') }}">
                <x-input-error :messages="$errors->get('address_city')" class="mt-2" />
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-8">
                <label for="name">Ulice:</label>
                <input type="text" class="form-control" id="address_street" name='address_street' value="{{ old('address_street') }}">
                <x-input-error :messages="$errors->get('address_street')" class="mt-2" />
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-8">
                <label for="name">Číslo popisné:</label>
                <input type="text" class="form-control" id="address_house_num" name='address_house_num' value="{{ old('address_house_num') }}">
                <x-input-error :messages="$errors->get('address_house_num')" class="mt-2" />
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-8">
                <label for="name">Poštovní směrovací číslo:</label>
                <input type="text" class="form-control" id="address_postcode" name='address_postcode' value="{{ old('address_postcode') }}">
                <x-input-error :messages="$errors->get('address_postcode')" class="mt-2" />
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-8">
                <label for="name">Popisek:</label>
                <textarea class="form-control" id="description" name="description" rows="3" cols="40">{{ old('description') }}</textarea>
                <x-input-error :messages="$errors->get('description')" class="mt-2" />
            </div>
        </div>
        <div class="row">
            <div id="image_input" class="form-group col-md-8">
                <label for="images">Obrázky:</label>
                <input type="file" class="form-control" name="images[]" id="images" multiple accept="image/*" value="{{ old('image') }}">
                <x-input-error :messages="$errors->get('images')" class="mt-2" />
            </div>
        </div>
        <x-required-text/>
        <div id="create_event_button">
            <button type="submit" class="btn btn-default"><span></span>Vytvořit místo konání</button>
        </div>
    </form>
</div>

</x-app-layout>
