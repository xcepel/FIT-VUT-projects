<x-app-layout>
    <x-slot name="title">
        Detail místa konání
    </x-slot>

    <x-slot name="header">
        <h1>{{ $venue->name }}</h1>
    </x-slot>


    <div class="container">
        @if((optional(auth()->user())->mod) || optional(auth()->user())->admin)
                <div class="row">
                    <div id="edit_venue_button" class="text-left col-md-4">
                        <form action="{{ route('venues.edit', $venue->id) }}" method="GET">
                            @csrf
                            <button type="submit" class="btn btn-primary"><span></span>Upravit</button>
                        </form>
                    </div>
                    <div id="approve_venue_button" class="text-right col-md-6" style="padding-right: 0;">
                        @if (!$venue->Approved_by)
                            <form action="{{ route('venues.approve', ['venue_id' => $venue->id]) }}" method="post">
                                @csrf
                                <button type="submit"><span></span>Schválit místo konání</button>
                            </form>
                        @endif
                    </div>
                    <div id="venue_delete_button" class="text-right col-md-1" style="padding-left: 0;">
                        <form id="venue_{{$venue->id}}_delete_button" class="delete_button" method="POST" action="{{ route('venues_destroy', ['venue_id' => $venue->id]) }}">
                            @csrf
                            @method('DELETE')
                            <button onclick="confirmDelete('{{$venue->name}}','{{$venue->id}}')" type="button"><span class="glyphicon glyphicon-trash"></span></button>
                        </form>
                    </div>
            </div>
            @endif

        <div id="detail_venue" class="row-content">
            <div>
                <div class="row container">
                    <div class="col-sm-7">
                        <!-- Date and time of the venue -->
                        <h2><b>Adresa</b></h2>
                        <div class="col-sm-9">
                            <p><span class="glyphicon glyphicon-home"></span> Město: {{ (isset($venue->address_city))? $venue->address_city : "Neuvedeno" }} </p>
                            <p><span class="glyphicon glyphicon-home"></span> Ulice: {{ (isset($venue->address_street))? $venue->address_street : "Neuvedeno" }} </p>
                            <p><span class="glyphicon glyphicon-home"></span> Číslo popisné: {{ (isset($venue->address_house_num))? $venue->address_house_num : "Neuvedeno" }} </p>
                            <p><span class="glyphicon glyphicon-home"></span> Poštovní směrovací číslo: {{ (isset($venue->address_postcode))? $venue->address_postcode : "Neuvedeno" }} </p>
                            <br>
                        </div>
                    </div>
                    <div class="col-sm-5">
                        <!-- Manager and approved by of the venue -->
                        <h2><b>Správci</b></h2>
                        <div class="col-sm-12">
                            <p><span class="glyphicon glyphicon-user"></span> Schválil: {{ (isset($venue->approved_by))? $venue->Approved_by->first_name." ".$venue->Approved_by->last_name : "Neschváleno" }} </p>
                            <br>
                        </div>
                    </div>
                </div>
                <div class="row container">
                    <!-- Description -->
                    <div class="col-sm-12">
                        <h2><b>Popis</b></h2>
                        <div class="col-sm-12">
                            <p> {{ (isset($venue->description))? $venue->description : "Bez popisu" }} </p>
                        </div>
                        <br>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <br><br>

    <div class="container">
        <!-- Gallery -->
        <h2><b>Galerie</b></h2>
        <div class="row text-center text-lg-start">
            @if ($venue->Has_images->count())
                @foreach($venue->Has_images as $image)
                    <div class="col-lg-4 col-md-4 col-6" id="gallery">
                        <img class="img-fluid img-thumbnail" src="{{ asset('storage/images/venues/' . $image->img_path ) }}" alt="">
                        @if((optional(auth()->user())->mod) || optional(auth()->user())->admin)
                            <form id="image_{{$image->id}}_delete_button"
                                  action="{{ route('venue_image_destroy', ['venue_id' => $venue->id, 'image_id' => $image->id]) }}" method="post" style="display: inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" onclick="confirmDeleteImage('{{ $image->id }}')"
                                        class="btn btn-danger">Odstranit</button>
                            </form>
                        @endif
                    </div>
                @endforeach
            @else
                <div class="text-left" style="padding-left: 30px;">
                    <p>Toto místo konání nemá žádné obrázky</p>
                </div>
            @endif
         </div>
    </div>

    <script>
        // Confirm venue delete
        function confirmDelete(venue, venue_id) {
            Swal.fire({
                title: 'Opravdu chcete smazat místo konání?',
                html: `<div>Místo: <strong>${venue}</strong><div>`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ano, smazat!',
                cancelButtonText: 'Zrušit',
                customClass: {
                    popup: 'custom-modal',
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    // If the user clicks "OK", submit the form
                    document.getElementById("venue_"+venue_id+"_delete_button").submit();
                }
            });

            return false; // Prevent the form from being submitted automatically
        }

        // Confirm image delete
        function confirmDeleteImage(image_id) {
            Swal.fire({
                title: 'Opravdu chcete smazat obrázek?',
                html: ``,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ano, smazat!',
                cancelButtonText: 'Zrušit',
                customClass: {
                    popup: 'custom-modal',
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    // If the user clicks "OK", submit the form
                    document.getElementById("image_"+image_id+"_delete_button").submit();
                }
            });

            return false; // Prevent the form from being submitted automatically
        }

    </script>

</x-app-layout>
