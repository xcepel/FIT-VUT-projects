<x-app-layout>
    <x-slot name="title">
        Detail události - Účastníci
    </x-slot>

    <x-slot name="header">
        <h1>{{ $event->name }}</h1>
    </x-slot>


    <div id="is_attending" class="container">
    <table id="is_attending_table" class="table table-hover table-bordered table-sm">
        <thead>
        <tr>
            <th scope="col">Přihlašovací jméno</th>
            <th scope="col">Jméno a příjmení</th>
            <th scope="col">Zaplaceno</th>
            <th scope="col">Lístek</th>
        </tr>
        </thead>
        <tbody>
            @foreach ($userDetails as $userDetail)
                <tr>
                    <td class="col-md-2">{{ $userDetail['user_login'] }}</td>
                    <td class="col-md-4">{{ $userDetail['user_name'] }}</td>
                    <td id="user{{$userDetail['user_id']}}_paid" class="col-md-1">{{ $userDetail['user_paid'] ? 'Ano' : 'Ne' }}</td>
                    @if ($userDetail['user_paid'])
                        <td>{{ $userDetail['ticket_category'] }} ({{ $userDetail['ticket_price'] }} Kč)</td>
                    @else
                        <td class="col-md-4">
                            <!-- Display only for future events -->
                            @if (\Carbon\Carbon::now() < $event->date_to)
                                <form method="post" action="{{ route('attendees.store', ['event_id' => $event->id, 'user_id' => $userDetail['user_id']]) }}">
                                    @csrf
                                    <label for="ticket_category">Vyber lístek:</label>
                                    <select name="ticket_category" id="ticket_category" required>
                                        <option value="">---</option>
                                        @foreach ($event->has_tickets as $ticket)
                                            <option value="{{ $ticket->category }}">{{ $ticket->category }} ({{ $ticket->price }} Kč)</option>
                                        @endforeach
                                    </select>

                                    <button type="submit">Přiřadit lístek</button>
                                </form>
                            @endif
                        </td>
                    @endif

                </tr>
                <!-- Php variables for coloring Has paid -->
                <?php
                    $user_id_paid = $userDetail['user_id'];
                ?>
                <script>
                    // Function for coloring has paid
                    function set_color() {
                        let user_paid = document.getElementById("user"+{{$user_id_paid}}+"_paid");
                        if(user_paid.textContent == 'Ano') {
                            user_paid.style.color = "green";
                        } else {
                            user_paid.style.color = "red";
                        }
                    }
                    set_color();
                </script>
                @endforeach
            </tbody>
        </table>
    </div>

    <script>
        $(document).ready(
            function () {
                $('#is_attending_table').DataTable({
                    "language": {
                        "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Czech.json"
                    },
                    "aaSorting": []
                });
            }
        );
    </script>
</x-app-layout>
