<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class UsersSeeder extends Seeder
{
    public function run(): void
    {
        /**
         * Create users
         */
        $user1 = new User();
        $user1->login = 'mod';
        $user1->password = Hash::make('mod');
        $user1->first_name = 'Tomáš';
        $user1->last_name = 'Ebert';
        $user1->mod = true;
        $user1->img_name = '1_seed.png';
        $user1->save();

        $user2 = new User();
        $user2->login = 'user';
        $user2->password = Hash::make('user');
        $user2->first_name = 'Kateřina';
        $user2->last_name = 'Čepelková';
        $user2->save();

        $user3 = new User();
        $user3->login = 'admin';
        $user3->password = Hash::make('admin');
        $user3->first_name = 'Sára';
        $user3->last_name = 'Jobranová';
        $user3->mod = true;
        $user3->admin = true;
        $user3->save();
    }
}
