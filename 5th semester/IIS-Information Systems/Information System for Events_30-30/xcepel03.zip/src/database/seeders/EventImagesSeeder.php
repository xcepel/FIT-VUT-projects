<?php

namespace Database\Seeders;

use App\Models\Event;
use App\Models\EventImage;
use Illuminate\Database\Seeder;

class EventImagesSeeder extends Seeder
{
    public function run(): void
    {
        // Load events
        $event1 = Event::find(1);
        $event2 = Event::find(2);
        $event3 = Event::find(3);
        $event4 = Event::find(4);

        $event1_image1 = new EventImage();
        $event1_image1->img_path = '1/1_seed.jpg';
        $event1_image1->save();
        $event1->has_images()->save($event1_image1);

        $event1_image2 = new EventImage();
        $event1_image2->img_path = '1/2_seed.jpg';
        $event1_image2->save();
        $event1->has_images()->save($event1_image2);

        $event2_image1 = new EventImage();
        $event2_image1->img_path = '2/1_seed.jpg';
        $event2_image1->save();
        $event2->has_images()->save($event2_image1);

        $event3_image1 = new EventImage();
        $event3_image1->img_path = '3/1_seed.jpg';
        $event3_image1->save();
        $event3->has_images()->save($event3_image1);

        $event4_image1 = new EventImage();
        $event4_image1->img_path = '4/1_seed.jpg';
        $event4_image1->save();
        $event4->has_images()->save($event4_image1);

        $event4_image2 = new EventImage();
        $event4_image2->img_path = '4/2_seed.jpg';
        $event4_image2->save();
        $event4->has_images()->save($event4_image2);

        $event4_image3 = new EventImage();
        $event4_image3->img_path = '4/3_seed.jpg';
        $event4_image3->save();
        $event4->has_images()->save($event4_image3);
    }
}
