<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call(ImageSeeder::class);
        $this->call(UsersSeeder::class);
        $this->call(VenueSeeder::class);
        $this->call(VenueImagesSeeder::class);
        $this->call(CategoriesSeeder::class);
        $this->call(EventsSeeder::class);
        $this->call(EventImagesSeeder::class);
        $this->call(CommentsSeeder::class);
        $this->call(TicketsSeeder::class);
        $this->call(IsAttendingSeeder::class);
    }
}
