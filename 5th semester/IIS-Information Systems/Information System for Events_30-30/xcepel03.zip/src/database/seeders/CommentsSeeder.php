<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Comment;
use App\Models\Event;
use App\Models\User;

class CommentsSeeder extends Seeder
{
    public function run(): void
    {
        // Load users
        $user_basic = User::where('mod', false)->where('admin', false)->first();
        $user_mod = User::where('mod', true)->first();
        $user_admin = User::where('admin', true)->first();

        // Load events
        $event2 = Event::find(2);
        $event3= Event::find(3);
        $event4 = Event::find(4);

        /**
         * Create comments
         */
        $comment1 = new Comment();
        $comment1->rating = 4;
        $comment1->content = 'kwekwlf';
        $comment1->save();
        $event3->has_comments()->save($comment1);
        $user_basic->has_wrote()->save($comment1);

        $comment2 = new Comment();
        $comment2->rating = 5;
        $comment2->content = 'parádička to byla';
        $comment2->save();
        $event3->has_comments()->save($comment2);
        $user_mod->has_wrote()->save($comment2);

        $comment3 = new Comment();
        $comment3->rating = 1;
        $comment3->content = 'moc weebů';
        $comment3->save();
        $event2->has_comments()->save($comment3);
        $user_mod->has_wrote()->save($comment3);

        $comment4 = new Comment();
        $comment4->rating = 4;
        $comment4->content = 'Byl to nezapomenutelný zážitek!';
        $comment4->save();
        $event4->has_comments()->save($comment4);
        $user_admin->has_wrote()->save($comment4);

        $comment5 = new Comment();
        $comment5->rating = 4;
        $comment5->content = 'Úžasně strávený víkend, moc se mi líbíly přednášky. Příští rok by to ale chtělo lépe vyřešit jídlo.';
        $comment5->save();
        $event2->has_comments()->save($comment5);
        $user_basic->has_wrote()->save($comment5);
    }
}
