<?php

namespace Database\Seeders;

use App\Models\Event;
use App\Models\User;
use App\Models\Category;
use App\Models\Venue;
use Illuminate\Database\Seeder;

class EventsSeeder extends Seeder
{
    public function run(): void
    {
        // Load users
        $user_basic = User::where('mod', false)->where('admin', false)->first();
        $user_mod = User::where('mod', true)->first();
        $user_admin = User::where('admin', true)->first();

        // Load venues
        $venue1 = Venue::find(1);
        $venue2 = Venue::find(2);
        $venue3 = Venue::find(3);
        $venue4 = Venue::find(4);
        $venue5 = Venue::find(5);

        // Load categories
        $category1 = Category::find(1);
        $category2 = Category::find(2);
        $category4 = Category::find(4);
        $category5 = Category::find(5);
        $category6 = Category::find(6);

        /**
         * Create events
         */
        $event1 = new Event();
        $event1->name = 'Animefest 2024';
        $event1->date_from = '2024-05-24 10:00';
        $event1->date_to = '2024-05-26 22:00';
        $event1->capacity = 15000;
        $event1->save();
        $user_basic->manages()->save($event1);
        $user_mod->has_approved_event()->save($event1);
        $venue3->takes_place()->save($event1);
        $category4->has_events()->save($event1);

        $event2 = new Event();
        $event2->name = 'Animefest 2023';
        $event2->date_from = '2023-05-05 10:00';
        $event2->date_to = '2023-05-07 22:00';
        $event2->capacity = 15000;
        $event2->save();
        $user_basic->manages()->save($event2);
        $user_mod->has_approved_event()->save($event2);
        $venue3->takes_place()->save($event2);
        $category4->has_events()->save($event2);

        $event3 = new Event();
        $event3->name = 'Dissmatik v Praze!';
        $event3->date_from = '2023-01-20 20:00';
        $event3->date_to = '2023-01-20 23:59';
        $event3->capacity = 18000;
        $event3->description = 'Slovenští Dissmatik přijeli až do Prahy, to si nemůžete nechat ujít';
        $event3->save();
        $user_basic->manages()->save($event3);
        $user_mod->has_approved_event()->save($event3);
        $venue1->takes_place()->save($event3);
        $category1->has_events()->save($event3);

        $event4 = new Event();
        $event4->name = 'HC Kometa Brno vs Sparta Praha';
        $event4->date_from = '2023-11-19 17:00';
        $event4->date_to = '2023-11-19 21:00';
        $event4->capacity = 5000;
        $event4->description = 'Zápas roku 2023!';
        $event4->save();
        $user_admin->manages()->save($event4);
        $user_admin->has_approved_event()->save($event4);
        $venue2->takes_place()->save($event4);
        $category5->has_events()->save($event4);

        $event5 = new Event();
        $event5->name = 'Vánoční party';
        $event5->date_from = '2023-12-23 22:00';
        $event5->date_to = '2023-12-24 4:00';
        $event5->capacity = 800;
        $event5->description = 'Bude to epický B-)';
        $event5->save();
        $user_mod->manages()->save($event5);
        $user_mod->has_approved_event()->save($event5);
        $venue4->takes_place()->save($event5);
        $category6->has_events()->save($event5);

        $event6 = new Event();
        $event6->name = 'Space Beer 2.0';
        $event6->date_from = '2023-12-12 18:00';
        $event6->date_to = '2023-12-12 23:59';
        $event6->capacity = 500;
        $event6->description = 'Zjistěte, jak vypouštíme struktury do vesmíru a proč na nich záleží ve velkém schématu.';
        $event6->save();
        $user_mod->manages()->save($event6);
        $venue5->takes_place()->save($event6);
        $category2->has_events()->save($event6);
    }
}
