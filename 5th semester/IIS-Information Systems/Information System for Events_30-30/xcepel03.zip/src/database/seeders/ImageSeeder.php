<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Storage;

class ImageSeeder extends Seeder
{
    /**
     * Seeds the default images.
     *
     * @return void
     */
    public function run()
    {

        $default_image_folder = 'public/images/default/';
        $user_image_folder = 'public/images/users/';
        $event_image_folder = 'public/images/events/';
        $venue_image_folder = 'public/images/venues/';
        Storage::makeDirectory($default_image_folder);
        Storage::makeDirectory($user_image_folder);
        Storage::makeDirectory($event_image_folder);
        Storage::makeDirectory($venue_image_folder);

        // Set a User-Agent header
        $options = [
            'http' => [
                'header' => 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            ],
        ];
        $context = stream_context_create($options);

        try {
            // Save default images
            $default_event = file_get_contents("https://englishka.cz/wp-content/uploads/2020/08/word-event-1536x1081.jpg", false, $context);
            Storage::put($default_image_folder . 'event.png', $default_event);
            $default_user = file_get_contents("https://storage.needpix.com/rsynced_images/avatar-1577909_1280.png", false, $context);
            Storage::put($default_image_folder . 'user.png', $default_user);
            $default_venue = file_get_contents("https://www.cvent.com/sites/default/files/image/2022-08/empty%20vintage%20moving%20theater%20venue%20type.jpg", false, $context);
            Storage::put($default_image_folder . 'venue.png', $default_venue);

            // Save user profile images
            $user1_img = file_get_contents("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTpwgiaebLy-WxtOtx4O4onYyxZ2uAcFhb_cw&usqp=CAU", false, $context);
            Storage::put($user_image_folder . '1_seed.png', $user1_img);

            // Save event images
            $event1_img1 = file_get_contents("https://upload.wikimedia.org/wikipedia/commons/5/59/Animefest2019Cosplayers1.jpg", false, $context);
            Storage::put($event_image_folder . '1/1_seed.jpg', $event1_img1);
            $event1_img2 = file_get_contents("https://live.staticflickr.com/2595/3910990859_1907478c90_b.jpg", false, $context);
            Storage::put($event_image_folder . '1/2_seed.jpg', $event1_img2);

            $event2_img = file_get_contents("https://upload.wikimedia.org/wikipedia/commons/a/a6/Animefest2019CosplayCompetition2.jpg", false, $context);
            Storage::put($event_image_folder . '2/1_seed.jpg', $event2_img);

            $event3_img = file_get_contents("https://images.pexels.com/photos/248963/pexels-photo-248963.jpeg", false, $context);
            Storage::put($event_image_folder . '3/1_seed.jpg', $event3_img);

            $event4_img1 = file_get_contents("https://upload.wikimedia.org/wikipedia/commons/d/d2/Rozlou%C4%8Den%C3%AD_s_Kometou_2011_%28081%29.jpg", false, $context);
            Storage::put($event_image_folder . '4/1_seed.jpg', $event4_img1);
            $event4_img2 = file_get_contents("https://upload.wikimedia.org/wikipedia/commons/7/7f/Rozlou%C4%8Den%C3%AD_s_Kometou_2011_%28018%29.jpg", false, $context);
            Storage::put($event_image_folder . '4/2_seed.jpg', $event4_img2);
            $event4_img3 = file_get_contents("https://upload.wikimedia.org/wikipedia/commons/9/97/Rozlou%C4%8Den%C3%AD_s_Kometou_2011_%28032%29.jpg", false, $context);
            Storage::put($event_image_folder . '4/3_seed.jpg', $event4_img3);

            // Save venue images
            $venue1_img = file_get_contents("https://upload.wikimedia.org/wikipedia/commons/f/f0/Praha%2C_%C4%8Ceskomoravsk%C3%A1%2C_autobusov%C3%BD_termin%C3%A1l%2C_plocha_p%C5%99ed_O2_ar%C3%A9nou.jpg", false, $context);
            Storage::put($venue_image_folder . '1/1_seed.jpg', $venue1_img);

            $venue2_img = file_get_contents("https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/Rondo_hall_%2803%29.jpg/1920px-Rondo_hall_%2803%29.jpg", false, $context);
            Storage::put($venue_image_folder . '2/1_seed.jpg', $venue2_img);

            $venue3_img1 = file_get_contents("https://upload.wikimedia.org/wikipedia/commons/b/b0/Brno%2C_Pis%C3%A1rky%2C_v%C3%BDstavi%C5%A1t%C4%9B%2C_pavilon_Z_%282021-07-16%3B_07%29.jpg", false, $context);
            Storage::put($venue_image_folder . '3/1_seed.jpg', $venue3_img1);
            $venue3_img2 = file_get_contents("https://upload.wikimedia.org/wikipedia/commons/a/aa/Brno%2C_BVV%2C_hlavn%C3%AD_br%C3%A1na_%286307%29.jpg", false, $context);
            Storage::put($venue_image_folder . '3/2_seed.jpg', $venue3_img2);

            $venue5_img = file_get_contents("https://upload.wikimedia.org/wikipedia/commons/8/8f/Brno_-_Kr%C3%A1lovo_Pole%2C_kartuzi%C3%A1nsk%C3%BD_kl%C3%A1%C5%A1ter_%282%29.JPG", false, $context);
            Storage::put($venue_image_folder . '5/1_seed.jpg', $venue5_img);
        } catch (\Exception $e) {
            $this->command->error("Error downloading image");
            $this->command->error($e->getMessage());
        }
    }
}
