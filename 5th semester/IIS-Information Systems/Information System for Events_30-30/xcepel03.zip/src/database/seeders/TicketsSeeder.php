<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Ticket;
use App\Models\Event;

class TicketsSeeder extends Seeder
{
    public function run(): void
    {
        // Load events
        $event1 = Event::find(1);
        $event2 = Event::find(2);
        $event3 = Event::find(3);
        $event4 = Event::find(4);
        $event5 = Event::find(5);
        $event6 = Event::find(6);

        /**
         * Create categories
         */
        $ticket1 = new Ticket();
        $ticket1->category = 'Jednodenní';
        $ticket1->price = 700;
        $ticket1->save();
        $event1->has_tickets()->save($ticket1);

        $ticket2 = new Ticket();
        $ticket2->category = 'Celovíkendové';
        $ticket2->price = 2000;
        $ticket2->save();
        $event1->has_tickets()->save($ticket2);

        $ticket3 = new Ticket();
        $ticket3->category = 'Celovíkendové VIP';
        $ticket3->price = 5000;
        $ticket3->save();
        $event1->has_tickets()->save($ticket3);

        $ticket4 = new Ticket();
        $ticket4->category = 'Jednodenní';
        $ticket4->price = 500;
        $ticket4->save();
        $event2->has_tickets()->save($ticket4);

        $ticket5 = new Ticket();
        $ticket5->category = 'Celovíkendové';
        $ticket5->price = 1600;
        $ticket5->save();
        $event2->has_tickets()->save($ticket5);

        $ticket6 = new Ticket();
        $ticket6->category = 'Celovíkendové VIP';
        $ticket6->price = 3000;
        $ticket6->save();
        $event2->has_tickets()->save($ticket6);

        $ticket7 = new Ticket();
        $ticket7->category = 'Základní';
        $ticket7->price = 500;
        $ticket7->save();
        $event3->has_tickets()->save($ticket7);

        $ticket8 = new Ticket();
        $ticket8->category = 'ZTP';
        $ticket8->price = 20;
        $ticket8->save();
        $event3->has_tickets()->save($ticket8);

        $ticket9 = new Ticket();
        $ticket9->category = 'Základní';
        $ticket9->price = 800;
        $ticket9->save();
        $event4->has_tickets()->save($ticket9);

        $ticket10 = new Ticket();
        $ticket10->category = 'VIP';
        $ticket10->price = 1500;
        $ticket10->save();
        $event4->has_tickets()->save($ticket10);

        $ticket11 = new Ticket();
        $ticket11->category = 'Jednotné';
        $ticket11->price = 150;
        $ticket11->save();
        $event5->has_tickets()->save($ticket11);

        $ticket12 = new Ticket();
        $ticket12->category = 'Jednotné';
        $ticket12->price = 50;
        $ticket12->save();
        $event6->has_tickets()->save($ticket12);
    }
}
