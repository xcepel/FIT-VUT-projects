<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Category;
use App\Models\User;

class CategoriesSeeder extends Seeder
{
    public function run(): void
    {
        // Load users
        $user_basic = User::where('mod', false)->where('admin', false)->first();
        $user_mod = User::where('mod', true)->first();
        $user_admin = User::where('admin', true)->first();

        /**
         * Create categories
         */
        $category1 = new Category();
        $category1->name = 'Koncert';
        $category1->save();
        $user_mod->has_approved_category()->save($category1);

        $category2 = new Category();
        $category2->name = 'Vzdělávací';
        $category2->save();
        $user_admin->has_approved_category()->save($category2);

        $category3 = new Category();
        $category3->name = 'Přednáška';
        $category3->save();
        $user_basic->has_approved_category()->save($category3);
        $category2->has_subtypes()->save($category3);

        $category4 = new Category();
        $category4->name = 'Zábava';
        $category4->save();
        $user_mod->has_approved_category()->save($category4);

        $category5 = new Category();
        $category5->name = 'Sportovní utkání';
        $category5->save();
        $user_mod->has_approved_category()->save($category5);
        $category4->has_subtypes()->save($category5);

        $category6 = new Category();
        $category6->name = 'Kalba';
        $category6->save();
        $user_admin->has_approved_category()->save($category6);
        $category4->has_subtypes()->save($category6);

        $category7 = new Category();
        $category7->name = 'Mše';
        $category7->save();
        $user_basic->has_approved_category()->save($category7);
    }
}
