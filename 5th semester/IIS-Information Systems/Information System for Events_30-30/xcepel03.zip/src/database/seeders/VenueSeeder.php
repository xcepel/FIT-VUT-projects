<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Venue;
use App\Models\User;

class VenueSeeder extends Seeder
{
    public function run(): void
    {
        // Load users
        $user_basic = User::where('mod', false)->where('admin', false)->first();
        $user_mod = User::where('mod', true)->first();
        $user_admin = User::where('admin', true)->first();

        /**
         * Create venues
         */
        $venue1 = new Venue();
        $venue1->name = 'O2 Arena';
        $venue1->description = 'Druhá největší hokejová hala v Evropě';
        $venue1->address_city = 'Praha';
        $venue1->address_street = 'Českomoravská';
        $venue1->address_house_num = '2345/17';
        $venue1->address_postcode = '19000';
        $venue1->save();
        $user_basic->has_approved_venue()->save($venue1);

        $venue2 = new Venue();
        $venue2->name = 'Hala Rondo';
        $venue2->description = 'Domácí hala Komety Brno';
        $venue2->address_city = 'Brno';
        $venue2->address_street = 'Křídlovická';
        $venue2->address_house_num = '911';
        $venue2->address_postcode = '60300';
        $venue2->save();
        $user_mod->has_approved_venue()->save($venue2);

        $venue3 = new Venue();
        $venue3->name = 'Výstaviště Brno';
        $venue3->description = 'Český výstavní areál';
        $venue3->address_city = 'Brno';
        $venue3->address_street = 'Výstaviště';
        $venue3->address_house_num = '405/1';
        $venue3->address_postcode = '60300';
        $venue3->save();
        $user_basic->has_approved_venue()->save($venue3);

        $venue4 = new Venue();
        $venue4->name = 'Fléda';
        $venue4->description = 'Nejznámější klub v Brně';
        $venue4->address_city = 'Brno';
        $venue4->address_street = 'Štefánikova';
        $venue4->address_house_num = '95';
        $venue4->address_postcode = '60200';
        $venue4->save();
        $user_admin->has_approved_venue()->save($venue4);

        $venue5 = new Venue();
        $venue5->name = 'VUT FIT';
        $venue5->description = 'Fakulta informačních technologií Vysokého učení technického v Brně';
        $venue5->address_city = 'Brno';
        $venue5->address_street = 'Božetěchova';
        $venue5->address_house_num = '1/2';
        $venue5->address_postcode = '61200';
        $venue5->save();

        $venue6 = new Venue();
        $venue6->name = 'Špilberk';
        $venue6->description = 'Hrad a pevnost tvořící dominantu města Brna.';
        $venue6->address_city = 'Brno';
        $venue6->address_street = 'Špilberk';
        $venue6->address_house_num = '210/1';
        $venue6->address_postcode = '66224';
        $venue6->save();
    }
}
