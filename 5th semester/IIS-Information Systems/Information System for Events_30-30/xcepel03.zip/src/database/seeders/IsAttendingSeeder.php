<?php

namespace Database\Seeders;

use App\Models\Event;
use App\Models\User;
use Illuminate\Database\Seeder;
use App\Models\IsAttending;
use App\Models\Ticket;

class IsAttendingSeeder extends Seeder
{
    public function run(): void
    {

        // Load users
        $user_basic = User::where('mod', false)->where('admin', false)->first();
        $user_mod = User::where('mod', true)->first();
        $user_admin = User::where('admin', true)->first();

        // Load events
        $event1 = Event::find(1);
        $event2 = Event::find(2);
        $event3 = Event::find(3);
        $event4 = Event::find(4);
        $event5 = Event::find(5);

        // Load tickets
        $ticket2 = Ticket::find(2);
        $ticket4 = Ticket::find(4);
        $ticket6 = Ticket::find(6);

        $is_attending1 = new IsAttending();
        $is_attending1->save();
        $user_basic->is_attending()->save($is_attending1);
        $event1->has_attendees()->save($is_attending1);
        $ticket2->sold()->save($is_attending1);

        $is_attending2 = new IsAttending();
        $is_attending2->save();
        $user_basic->is_attending()->save($is_attending2);
        $event3->has_attendees()->save($is_attending2);

        $is_attending3 = new IsAttending();
        $is_attending3->save();
        $user_basic->is_attending()->save($is_attending3);
        $event2->has_attendees()->save($is_attending3);
        $ticket6->sold()->save($is_attending3);

        $is_attending4 = new IsAttending();
        $is_attending4->save();
        $user_admin->is_attending()->save($is_attending4);
        $event2->has_attendees()->save($is_attending4);
        $ticket4->sold()->save($is_attending4);

        $is_attending5 = new IsAttending();
        $is_attending5->save();
        $user_mod->is_attending()->save($is_attending5);
        $event2->has_attendees()->save($is_attending5);

        $is_attending6 = new IsAttending();
        $is_attending6->save();
        $user_admin->is_attending()->save($is_attending6);
        $event4->has_attendees()->save($is_attending6);

        $is_attending7 = new IsAttending();
        $is_attending7->save();
        $user_admin->is_attending()->save($is_attending7);
        $event5->has_attendees()->save($is_attending7);

        $is_attending8 = new IsAttending();
        $is_attending8->save();
        $user_mod->is_attending()->save($is_attending8);
        $event5->has_attendees()->save($is_attending8);

        $is_attending9 = new IsAttending();
        $is_attending9->save();
        $user_mod->is_attending()->save($is_attending9);
        $event1->has_attendees()->save($is_attending1);

        $is_attending10 = new IsAttending();
        $is_attending10->save();
        $user_mod->is_attending()->save($is_attending10);
        $event3->has_attendees()->save($is_attending10);

        $is_attending11 = new IsAttending();
        $is_attending11->save();
        $user_admin->is_attending()->save($is_attending11);
        $event3->has_attendees()->save($is_attending11);
    }
}
