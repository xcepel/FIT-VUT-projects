<?php

namespace Database\Seeders;

use App\Models\Venue;
use App\Models\VenueImage;
use Illuminate\Database\Seeder;

class VenueImagesSeeder extends Seeder
{
    public function run(): void
    {
        // Load venues
        $venue1 = Venue::find(1);
        $venue2 = Venue::find(2);
        $venue3 = Venue::find(3);
        $venue5 = Venue::find(5);

        $venue1_image1 = new VenueImage();
        $venue1_image1->img_path = '1/1_seed.jpg';
        $venue1_image1->save();
        $venue1->has_images()->save($venue1_image1);

        $venue2_image1 = new VenueImage();
        $venue2_image1->img_path = '2/1_seed.jpg';
        $venue2_image1->save();
        $venue2->has_images()->save($venue2_image1);

        $venue3_image1 = new VenueImage();
        $venue3_image1->img_path = '3/1_seed.jpg';
        $venue3_image1->save();
        $venue3->has_images()->save($venue3_image1);

        $venue3_image2 = new VenueImage();
        $venue3_image2->img_path = '3/2_seed.jpg';
        $venue3_image2->save();
        $venue3->has_images()->save($venue3_image2);

        $venue5_image1 = new VenueImage();
        $venue5_image1->img_path = '5/1_seed.jpg';
        $venue5_image1->save();
        $venue5->has_images()->save($venue5_image1);
    }
}
