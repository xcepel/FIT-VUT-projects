<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('is_attending', function (Blueprint $table) {
            $table->foreign('ticket')->references('id')->on('tickets')->onDelete('set null');
            $table->foreign('event')->references('id')->on('events')->onDelete('cascade');
            $table->foreign('user')->references('id')->on('users')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('is_attending', function (Blueprint $table) {
            $table->dropForeign(['ticket']);
            $table->dropForeign(['event']);
            $table->dropForeign(['user']);
        });
    }
};
