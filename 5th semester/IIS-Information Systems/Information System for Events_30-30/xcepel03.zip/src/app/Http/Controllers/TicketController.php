<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Event;
use App\Models\Ticket;
use Illuminate\Http\Request;

class TicketController extends Controller
{
    public function create($event_id)
    {
        $event = Event::findOrFail($event_id);
        return view('tickets.create', ['event'=>$event]);
    }

    public function store(Request $request, $event_id)
    {
        $validatedData = $request->validate([
            'category' => 'required|string|max:50',
            'price' => 'nullable|integer',
        ]);

        $new_ticket = new Ticket([
            'category' => $validatedData['category'],
            'price' => $validatedData['price'],
        ]);

        $event = Event::findOrFail($event_id);
        $event->has_tickets()->save($new_ticket);

        return redirect()->route('events_detail', $event_id)->with('success', 'Lístek úspěšně vytvořen.');
    }

    public function edit($event_id, $ticket_id)
    {
        $event = Event::findOrFail($event_id);
        $ticket = Ticket::findOrFail($ticket_id);

        return view('tickets.edit', ['event' => $event, 'ticket' => $ticket]);
    }

    public function update(Request $request, $event_id, $ticket_id)
    {
        $validatedData = $request->validate([
            'category' => 'required|string|max:50',
            'price' => 'nullable|integer',
        ]);

        $ticket = Ticket::findOrFail($ticket_id);
        $ticket->update([
            'category' => $validatedData['category'],
            'price' => $validatedData['price'],
        ]);

        return redirect()->route('events_detail', $event_id)->with('success', 'Lístek úspěšně aktualizován.');
    }

    public function destroy($event_id, $ticket_id)
    {
        $ticket = Ticket::findOrFail($ticket_id);
        $ticket->delete();

        return redirect()->route('events_detail', $event_id)->with('success', 'Lístek úspěšně smazán.');
    }
}
