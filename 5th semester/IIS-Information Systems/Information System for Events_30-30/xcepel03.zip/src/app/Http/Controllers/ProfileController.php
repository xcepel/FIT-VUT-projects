<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProfileUpdateRequest;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class ProfileController extends Controller
{
    /**
     * Display the user's profile form.
     */
    public function edit(Request $request): View
    {
        return view('profile.edit', [
            'user' => $request->user(),
        ]);
    }

    /**
     * Update the user's profile information.
     */
    public function update(ProfileUpdateRequest $request): RedirectResponse
    {
        $request->validate([
            'login' => ['required', 'string', 'max:50', Rule::unique('users')->ignore($request->user()->id)],
            'first_name' => ['required', 'string', 'max:50'],
            'last_name' => ['required', 'string', 'max:50'],
            'image' => ['image','max:2048','mimes:jpeg,png,jpg,gif']
        ]);

        $user = $request->user();

        $user->login = $request->login;
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;

        if ($request->hasFile('image')) {
            $currentImage = $user->img_name;
            if ($currentImage) {
                $imagePath = public_path('storage/images/users/' . $currentImage);
                // Check if the file exists before attempting to delete
                if (file_exists($imagePath)) {
                    unlink($imagePath);
                }
            }

            $image = $request->file('image');
            $filename = $user->id . '_' . time() . '.' . $image->getClientOriginalExtension();
            $image->storeAs('images/users', $filename, 'public');
            $user->img_name = $filename;
        }

        $user->save();

        return Redirect::route('profile.edit')->with('status', 'profile-updated');
    }

    public function delete_image(Request $request): RedirectResponse
    {
        $user = $request->user();
        // Delete the image
        $path = public_path('storage/images/users/' . $user->img_name);
        if (file_exists($path)) {
            unlink($path);
        }
        $user->img_name = null;
        $user->save();

        return redirect()->route('profile.edit')->with('success', 'Obrázek byl úspěšně odstraněn');
    }

    /**
     * Delete the user's account.
     */
    public function destroy(Request $request): RedirectResponse
    {
        $user = auth()->user();

        if (!is_null($user->img_name)) {
            $path = public_path('storage/images/users/' . $user->img_name);
            if (file_exists($path)) {
                unlink($path);
            }
        }

        Auth::logout();
        $user->delete();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect(RouteServiceProvider::HOME);
    }
}
