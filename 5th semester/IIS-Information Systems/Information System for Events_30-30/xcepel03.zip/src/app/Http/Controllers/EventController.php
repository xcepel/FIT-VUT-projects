<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Event;
use App\Models\EventImage;
use App\Models\IsAttending;
use App\Models\User;
use App\Models\Venue;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Validation\ValidationException;


class EventController extends Controller
{
    public function index()
    {
        $time = Carbon::now();

        $future_events = Event::where('date_to', '>', $time)
                              ->whereNotNull('approved_by')
                              ->orderBy('date_from', 'ASC')
                              ->with('Venue')
                              ->with('Category')
                              ->with('Has_images')
                              ->get();
        $past_events = Event::where('date_to', '<=', $time)
                            ->whereNotNull('approved_by')
                            ->orderBy('date_from', 'DESC')
                            ->with('Venue')
                            ->with('Category')
                            ->with('Has_images')
                            ->get();
        $no_approval_events = Event::whereNull('approved_by')
                            ->orderBy('date_from', 'ASC')
                            ->with('Venue')
                            ->with('Category')
                            ->with('Has_images')
                            ->get();

        return view('events.index', ['future_events'=>$future_events, 'past_events'=>$past_events, 'no_approval_events'=>$no_approval_events]);
    }

    public function detail($event_id)
    {
        $event = Event::where('id', $event_id)
                      ->with('Venue')
                      ->with('Manager')
                      ->with('Approved_by')
                      ->with('Has_comments.Wrote')
                      ->with('Has_tickets')
                      ->with('Has_attendees')
                      ->with('Has_images')
                      ->first();

        // Iteratively get all categories
        $aux_cat = $event->Category;
        $categories = collect();
        while (isset($aux_cat)) {
            $categories->push($aux_cat);
            $aux_cat = $aux_cat->Is_subtype_of;
        }

        if (auth()->user()) {
            $is_attending = IsAttending::where('user', auth()->id())
                                        ->where('event', $event_id)
                                        ->first();
        }
        else {
            $is_attending = NULL;
        }


        return view('events.detail', ['event'=>$event, 'categories'=>$categories, 'is_attending'=>$is_attending]);
    }

    public function my_events()
    {
        $user_id = auth()->id();
        $hosted = Event::where('Manager', '=', $user_id)
            ->orderBy('date_from', 'ASC')
            ->with('Venue')
            ->with('Category')
            ->with('Has_images')
            ->get();

        $time = Carbon::now();
        $attended_events = IsAttending::where('user', $user_id)->pluck('event')->toArray();
        $future_attended = Event::whereIn('id', $attended_events)
            ->where('date_to', '>', $time)
            ->orderBy('date_from', 'ASC')
            ->with('Venue')
            ->with('Category')
            ->with('Has_images')
            ->get();
        $past_attended = Event::whereIn('id', $attended_events)
            ->where('date_to', '<=', $time)
            ->orderBy('date_from', 'DESC')
            ->with('Venue')
            ->with('Category')
            ->with('Has_images')
            ->get();

        return view('events.myevents', ['hosted_events'=>$hosted,
            'future_attended_events'=>$future_attended,
            'past_attended_events'=>$past_attended]);
    }

    public function approve_event($event_id) {
        $event = Event::findOrFail($event_id);
        auth()->user()->has_approved_event()->save($event);

        return redirect()->back()->with('success', 'Událost byla schválena.');
    }

    public function create()
    {
        $categories = Category::orderBy('name')->get();
        $venues = Venue::orderBy('name')->get();
        return view('events.create', ['categories'=>$categories, 'venues'=>$venues]);
    }

    public function store(Request $request) {
        $this->validate($request, [
            'name' => 'required|string|max:100|unique:' . Event::class,
            'date_from' => 'required|date_format:Y-m-d',
            'time_from' => 'required|date_format:H:i',
            'date_to' => 'required|date_format:Y-m-d',
            'time_to' => 'required|date_format:H:i',
            'capacity' => 'nullable|integer|min:0',
            'description' => 'nullable|string|max:1000',
            'venue' => 'nullable',
            'category' => 'nullable',
            'images.*' => 'image|mimes:jpeg,png,jpg,gif|max:2048'
        ]);

        if ($request->date_from > $request->date_to) {
            throw ValidationException::withMessages(['date_to' => 'Chybná hodnota']);
        }
        if (($request->date_from == $request->date_to) && ($request->time_from > $request->time_to)) {
            throw ValidationException::withMessages(['time_to' => 'Chybná hodnota']);
        }

        $new_event = new Event();
        $new_event->name = $request->name;
        $new_event->date_from = $request->date_from . ' ' . $request->time_from;
        $new_event->date_to = $request->date_to . ' ' . $request->time_to;
        $new_event->capacity = $request->capacity;
        $new_event->description = $request->description;
        $new_event->save();

        $manager = auth()->user();
        $manager->manages()->save($new_event);

        if (!is_null($request->venue)) {
            $venue = Venue::where('id', $request->venue)->first();
            $venue->takes_place()->save($new_event);
        }

        if (!is_null($request->category)) {
            $category = Category::where('id', $request->category)->first();
            $category->has_events()->save($new_event);
        }

        if ($request->hasFile('images')) {
            foreach ($request->file('images') as $image) {
                $filepath = $new_event->id . '/' . time() . '_' . $image->getClientOriginalName();
                $image->storeAs('images/events', $filepath, 'public');
                $newImage = new EventImage(['img_path' => $filepath]);
                $new_event->has_images()->save($newImage);
            }
        }

        return redirect()->route('events_detail', $new_event->id);
    }

    public function edit($event_id)
    {
        $event = Event::findOrFail($event_id);
        $categories = Category::orderBy('name')->get();
        $venues = Venue::orderBy('name')->get();

        return view('events.edit', ['event'=>$event, 'categories'=>$categories, 'venues'=>$venues]);
    }

    public function update(Request $request, $event_id)
    {
        $this->validate($request, [
            'name' => 'required|string|max:100|unique:' . Event::class,
            'date_from' => 'required|date_format:Y-m-d',
            'time_from' => 'required|date_format:H:i',
            'date_to' => 'required|date_format:Y-m-d',
            'time_to' => 'required|date_format:H:i',
            'capacity' => 'nullable|integer|min:0',
            'description' => 'nullable|string|max:1000',
            'venue' => 'nullable',
            'category' => 'nullable',
            'images.*' => 'image|mimes:jpeg,png,jpg,gif|max:2048'
        ]);

        if ($request->date_from > $request->date_to) {
            throw ValidationException::withMessages(['date_to' => 'Chybná hodnota']);
        }
        if (($request->date_from == $request->date_to) && ($request->time_from > $request->time_to)) {
            throw ValidationException::withMessages(['time_to' => 'Chybná hodnota']);
        }

        $event = Event::findOrFail($event_id);
        $event->name = $request->name;
        $event->date_from = $request->date_from . ' ' . $request->time_from;
        $event->date_to = $request->date_to . ' ' . $request->time_to;
        $event->capacity = $request->capacity;
        $event->description = $request->description;
        $event->save();

        if (!is_null($request->venue)) {
            $venue = Venue::where('id', $request->venue)->first();
            $venue->takes_place()->save($event);
        }
        else {
            $event->venue()->dissociate();
            $event->save();
        }

        if (!is_null($request->category)) {
            $category = Category::where('id', $request->category)->first();
            $category->has_events()->save($event);
        }
        else {
            $event->category()->dissociate();
            $event->save();
        }

        if ($request->hasFile('images')) {
            foreach ($request->file('images') as $image) {
                $filepath = $event->id . '/' . time() . '_' . $image->getClientOriginalName();
                $image->storeAs('images/events', $filepath, 'public');
                $newImage = new EventImage(['img_path' => $filepath]);
                $event->has_images()->save($newImage);
            }
        }

        return redirect()->route('events_detail', $event_id)->with('success', 'Událost úspěšně upravena.');
    }

    public function destroy($event_id)
    {
        // Find the event by ID
        $event = Event::find($event_id);

        // Check if the event exists
        if (!$event) {
            return redirect()->route('events_index')->with('error', 'Událost nebyla nalezena');
        }

        // Delete images
        foreach ($event->has_images as $image) {
            $path = public_path('storage/images/events/' . $image->img_path);
            if (file_exists($path)) {
                unlink($path);
            }
        }
        $directoryPath = public_path('storage/images/events/' . $event->id);
        if (is_dir($directoryPath)) {
            rmdir($directoryPath);
        }

        // Delete the event
        $event->delete();

        // Redirect back to the index page with a success message
        return redirect()->route('events_index')->with('success', 'Událost byla úspěšně odstraněna');
    }
}
