<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\VenueImage;

class VenueImageController extends Controller
{
    public function destroy($venue_id, $image_id)
    {
        $venue_image = VenueImage::find($image_id);
        if (!$venue_image) {
            return redirect()->route('venues_detail', $venue_id)->with('error', 'Obrázek nebyl nalezen');
        }

        // Delete the image
        $path = public_path('storage/images/venues/' . $venue_image->img_path);
        if (file_exists($path)) {
            unlink($path);
        }
        $venue_image->delete();

        return redirect()->route('venues_detail', $venue_id)->with('success', 'Obrázek byl úspěšně odstraněn');
    }
}
