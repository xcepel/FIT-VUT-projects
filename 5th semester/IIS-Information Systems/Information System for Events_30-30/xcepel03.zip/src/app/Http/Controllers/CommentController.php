<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Comment;
use App\Models\User;
use App\Models\Event;
use Illuminate\Http\Request;

class CommentController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        if (!$user->mod && !$user->admin) {
            $userId = $user->id;
            $events_with_comments = Event::whereHas('has_comments', function ($query) use ($userId) {
                                                $query->where('wrote', $userId);
                                            })
                                          ->with('Venue')
                                          ->get();
        }
        else {
            $events_with_comments = Event::whereHas('has_comments')
                                         ->with('has_comments.wrote')
                                         ->with('Venue')
                                         ->get();
        }
        return view('comments.index', ['events'=>$events_with_comments]);
    }

    public function store(Request $request, $event_id) {
        $this->validate($request, [
            'rating' => 'required|integer|min:1',
            'comment_content' => 'required|string|max:1000',
        ]);

        $new_comment = new Comment();
        $new_comment->rating = $request->rating;
        $new_comment->content = $request->comment_content;
        $new_comment->save();

        $writer = User::where('id', auth()->id())->first();
        $writer->has_wrote()->save($new_comment);

        $event = Event::where('id', $event_id)->first();
        $event->has_comments()->save($new_comment);

        return redirect()->route('events_detail', ['id' => $event_id]);
    }

    // Removes comment - if event_id is 0 returns to the "Komentáře" otherwise to the event detail
    public function destroy($comment_id, $event_id)
    {
        // Find the comment by ID
        $comment = Comment::find($comment_id);

        // Check if th comment exists
        if (!$comment) {
            return redirect()->route('comments_index')->with('error', 'Komentář nebyl nalezen');
        }

        $comment->delete();

        if ($event_id == 0) {
            return redirect()->route('comments_index')->with('success', 'Komentář byl úspěšně odstraněn');
        }

        return redirect()->route('events_detail', ['id' => $event_id]);
    }
}
