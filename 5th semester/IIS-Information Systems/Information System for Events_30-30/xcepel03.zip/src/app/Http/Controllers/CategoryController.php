<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\User;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function index()
    {
        $categories = Category::with(['is_subtype_of', 'has_subtypes', 'has_events'])->get();

        $categoryList = [];
        $notApprovedCategoryList = [];

        foreach ($categories as $category) {
            $events = $category->allEventsIncludingSubtypes();
            $subtypes = $category->has_subtypes->pluck('name')->toArray();
            $supertypes = Category::getAllSupertypes($category->id);
            // Remove the current category from the list
            $supertypes = array_diff($supertypes, [$category->name]);

            $categoryData = [
                'id' => $category->id,
                'name' => $category->name,
                'subtype_of' => $supertypes,
                'subtypes' => $subtypes,
                'events' => $events->map(function ($event) {
                    return [
                        'id' => $event->id,
                        'name' => $event->name,
                    ];
                })->toArray(),
            ];

            if ($category->approved_by === null) {
                $notApprovedCategoryList[] = $categoryData;
            } else {
                $categoryList[] = $categoryData;
            }
        }

        return view('categories.index', ['categoryList'=>$categoryList, 'notApprovedCategoryList'=>$notApprovedCategoryList]);
    }

    public function detail($category_id)
    {
        $category = Category::where('id', $category_id)
            ->with(['is_subtype_of', 'has_subtypes', 'has_events'])
            ->first();

        $events = $category->allEventsIncludingSubtypes();
        $subtypes = $category->has_subtypes->pluck('name')->toArray();
        $user = $category->approved_by ? User::find($category->approved_by) : null;

        $supertypes = Category::getAllSupertypes($category->id);
        $supertypes = array_diff($supertypes, [$category->name]); // remove the current category from the list

        $categoryData = [
            'id' => $category->id,
            'name' => $category->name,
            'subtype_of' => $supertypes,
            'subtypes' => $subtypes,
            'events' => $events->map(function ($event) {
                return [
                    'id' => $event->id,
                    'name' => $event->name,
                ];
            })->toArray(),
            'approved_by' => $user ? $user->first_name . ' ' . $user->last_name : null,
        ];

        return view('categories.detail', ['categoryData' => $categoryData]);
    }

    public function create()
    {
        $categories = Category::all();
        return view('categories.create', ['categories' => $categories]);
    }

    public function store(Request $request) {
        $this->validate($request, [
            'name' => 'required|string|unique:categories|max:50',
            'supertype_id' => 'nullable|exists:categories,id',
        ]);

        $category = new Category();
        $category->name = $request->name;
        if (isset($request->supertype_id)) {
            $supertype = Category::where('id', $request->supertype_id)->first();
            $supertype->has_subtypes()->save($category);
        }
        $category->save();

        return redirect()->route('categories_detail', $category->id);
    }

    public function edit($id)
    {
        $category = Category::findOrFail($id);
        $all_categories = Category::whereNotNull('approved_by')->orderBy('name', 'ASC')->get();
        $subtypes = Category::getAllSubtypes($id);
        $categories = $all_categories->reject(function ($category) use ($subtypes) {
            return $subtypes->contains('id', $category->id);
        });

        return view('categories.edit', ['category'=>$category, 'categories'=>$categories]);
    }

    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'name' => 'required|string|max:50|unique:categories,name,' . $id,
            'supertype_id' => 'nullable|exists:categories,id',
        ]);

        $category = Category::findOrFail($id);
        $category->name = $request->name;

        if (!is_null($request->supertype_id)) {
            $supertype = Category::findOrFail($request->supertype_id);
            $supertype->has_subtypes()->save($category);
        }
        else {
            $category->is_subtype_of = null;
        }

        $category->save();

        return redirect()->route('categories_detail', $category->id)->with('success', 'Kategorie úspěšně upravena.');
    }

    public function approve_category($category_id) {
        $category = Category::findOrFail($category_id);
        auth()->user()->has_approved_category()->save($category);

        return redirect()->back()->with('success', 'Kategorie byla schválena.');
    }

    public function destroy($category_id)
    {
        // Find the comment by ID
        $category = Category::find($category_id);

        // Check if th comment exists
        if (!$category) {
            return redirect()->route('comments_index')->with('error', 'Kategorie nebyla nalezena');
        }

        $category->delete();

        return redirect()->route('categories_index')->with('success', 'Kategorie byla úspěšně odstraněna');
    }
}
