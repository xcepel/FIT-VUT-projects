<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\VenueImage;
use Illuminate\Http\Request;
use App\Models\Venue;

class VenueController extends Controller
{
    public function index()
    {
        $venues = Venue::with('Has_images')
                        ->whereNotNull('approved_by')
                        ->orderBy('name', 'ASC')
                        ->get();

        $no_approval_venues = Venue::whereNull('approved_by')
                                   ->orderBy('name', 'ASC')
                                   ->with('Has_images')
                                   ->get();

        return view('venues.index', ['venues'=>$venues, 'no_approval_venues'=>$no_approval_venues]);
    }

    public function detail($venue_id)
    {
        $venue = Venue::where('id', $venue_id)
            ->with('Approved_by')
            ->with('Has_images')
            ->first();

        return view('venues.detail', ['venue'=>$venue]);
    }

    public function approve_venue($venue_id) {
        $venue = Venue::findOrFail($venue_id);
        auth()->user()->has_approved_venue()->save($venue);

        return redirect()->back()->with('success', 'Místo konání bylo schváleno.');
    }

    public function create()
    {
        return view('venues.create');
    }

    public function store(Request $request) {
        $this->validate($request, [
            'name' => 'required|string|max:100|unique:' . Venue::class,
            'description' => 'nullable|string|max:1000',
            'address_city' => 'nullable|string|max:50',
            'address_street' => 'nullable|string|max:50',
            'address_house_num' => 'nullable|string|max:16',
            'address_postcode' => 'nullable|integer|min:1',
            'images.*' => 'image|mimes:jpeg,png,jpg,gif|max:2048'
        ]);

        $new_venue = new Venue();
        $new_venue->name = $request->name;
        $new_venue->description = $request->description;
        $new_venue->address_city =  $request->address_city;
        $new_venue->address_street =  $request->address_street;
        $new_venue->address_house_num =  $request->address_house_num;
        $new_venue->address_postcode =  $request->address_postcode;
        $new_venue->save();

        if ($request->hasFile('images')) {
            foreach ($request->file('images') as $image) {
                $filepath = $new_venue->id . '/' . time() . '_' . $image->getClientOriginalName();
                $image->storeAs('images/venues', $filepath, 'public');
                $newImage = new VenueImage(['img_path' => $filepath]);
                $new_venue->has_images()->save($newImage);
            }
        }

        return redirect()->route('venues_detail', $new_venue->id);
    }

    public function edit($venue_id) {
        $venue = Venue::findOrFail($venue_id);
        return view('venues.edit', ['venue'=>$venue]);
    }

    public function update(Request $request, $venue_id) {
        $this->validate($request, [
            'name' => 'required|string|max:100|unique:' . Venue::class,
            'description' => 'nullable|string|max:1000',
            'address_city' => 'nullable|string|max:50',
            'address_street' => 'nullable|string|max:50',
            'address_house_num' => 'nullable|string|max:16',
            'address_postcode' => 'nullable|integer|min:1',
            'images.*' => 'image|mimes:jpeg,png,jpg,gif|max:2048'
        ]);

        $venue = Venue::findOrFail($venue_id);
        $venue->name = $request->name;
        $venue->description = $request->description;
        $venue->address_city = $request->address_city;
        $venue->address_street = $request->address_street;
        $venue->address_house_num = $request->address_house_num;
        $venue->address_postcode = $request->address_postcode;
        $venue->save();

        if ($request->hasFile('images')) {
            foreach ($request->file('images') as $image) {
                $filepath = $venue->id . '/' . time() . '_' . $image->getClientOriginalName();
                $image->storeAs('images/venues', $filepath, 'public');

                $newImage = new VenueImage(['img_path' => $filepath]);
                $venue->has_images()->save($newImage);
            }
        }

        return redirect()->route('venues_detail', $venue_id)->with('success', 'Místo konání úspěšně upraveno.');
    }

    public function destroy($venue_id)
    {
        // Find the venue by ID
        $venue = Venue::find($venue_id);

        // Check if the venue exists
        if (!$venue) {
            return redirect()->route('venues_index')->with('error', 'Místo konání nebylo nalezeno');
        }

        // Delete images
        foreach ($venue->has_images as $image) {
            $path = public_path('storage/images/venues/' . $image->img_path);
            if (file_exists($path)) {
                unlink($path);
            }
        }
        $directoryPath = public_path('storage/images/venues/' . $venue->id);
        if (is_dir($directoryPath)) {
            rmdir($directoryPath);
        }

        // Delete the venue
        $venue->delete();

        // Redirect back to the index page with a success message
        return redirect()->route('venues_index')->with('success', 'Místo konání bylo úspěšně odstraněno');
    }
}
