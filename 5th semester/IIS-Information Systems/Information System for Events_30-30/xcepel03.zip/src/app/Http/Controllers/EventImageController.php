<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\EventImage;

class EventImageController extends Controller
{
    public function destroy($event_id, $image_id)
    {
        $event_image = EventImage::find($image_id);
        if (!$event_image) {
            return redirect()->route('events_detail', $event_id)->with('error', 'Obrázek nebyl nalezen');
        }

        // Delete the image
        $path = public_path('storage/images/events/' . $event_image->img_path);
        if (file_exists($path)) {
            unlink($path);
        }
        $event_image->delete();

        return redirect()->route('events_detail', $event_id)->with('success', 'Obrázek byl úspěšně odstraněn');
    }
}
