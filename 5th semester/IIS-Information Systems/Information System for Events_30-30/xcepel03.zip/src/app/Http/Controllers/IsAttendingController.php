<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\IsAttending;
use App\Models\User;
use App\Models\Event;
use App\Models\Ticket;

class IsAttendingController extends Controller
{
    public function index($event_id)
    {
        $event = Event::find($event_id);

        // Retrieve all IsAttending records for the specified event
        $attendances = IsAttending::where('event', $event_id)->get();

        $userDetails = [];

        foreach ($attendances as $attendance) {
            // Get user information
            $user = User::find($attendance->user);
            $ticket = Ticket::find($attendance->ticket);

            if ($ticket) {
                $userDetails[] = [
                    'user_id' => $user->id,
                    'user_login' => $user->login,
                    'user_name' => $user->first_name . ' ' . $user->last_name,
                    'user_paid' => true,
                    'ticket_category' => $ticket->category,
                    'ticket_price' => $ticket->price,
                ];
            } else {
                $userDetails[] = [
                    'user_id' => $user->id,
                    'user_login' => $user->login,
                    'user_name' => $user->first_name . ' ' . $user->last_name,
                    'user_paid' => false,
                    'ticket_category' => null,
                    'ticket_price' => null,
                ];
            }
            // Add user information  to the array

        }

        return view('isattending.index', ['event'=>$event, 'userDetails' => $userDetails]);
    }

    public function store($event_id) {
        $new_is_attending = new IsAttending();
        $new_is_attending->save();

        auth()->user()->is_attending()->save($new_is_attending);

        $event = Event::where('id', $event_id)->first();
        $event->has_attendees()->save($new_is_attending);

        return redirect()->route('events_detail', ['id' => $event_id]);
    }

    public function store_attendee(Request $request, $event_id, $user_id) {
        $request->validate([
            'ticket_category' => 'required|exists:tickets,category',
        ]);

        $event = Event::findOrFail($event_id);

        $ticket = Ticket::where('category', $request->input('ticket_category'))
            ->where('for_event', $event_id)
            ->first();

        // Find eddited IsAttending
        $isAttending = IsAttending::where('event', $event_id)
            ->where('user', $user_id)
            ->first();
        // Add chosen ticket
        $isAttending->ticket = $ticket->id;
        $isAttending->save();


        return redirect()->back()->with('success', 'Lístek úspěšně přidán.');
    }

    public function destroy($event_id) {
        $is_attending = IsAttending::where('event', $event_id)->where('user', auth()->id());

        // Check if th comment exists
        if (!$is_attending) {
            return redirect()->route('events_detail', ['id' => $event_id])
                    ->with('error', 'Uživatel nemůže zrušit účast na události, které se neúčastní');
        }

        $is_attending->delete();

        return redirect()->route('events_detail', ['id' => $event_id])
               ->with('success', 'Účast byla zrušena');
    }
}
