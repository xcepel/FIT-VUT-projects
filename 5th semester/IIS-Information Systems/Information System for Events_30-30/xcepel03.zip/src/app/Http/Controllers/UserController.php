<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Event;
use App\Models\IsAttending;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use App\Providers\RouteServiceProvider;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    public function index()
    {
        $users = User::with(['manages', 'has_approved_event', 'has_approved_venue', 'is_attending'])
            ->get();

        $userList = [];


        foreach ($users as $user) {
            $attendances = IsAttending::where('user', $user->id)->get();
            $attendingEvents = [];

            foreach ($attendances as $attendance) {
                $event = Event::find($attendance->event);
                if ($event) {
                    $attendingEvents[] = $event->name;
                }
            }

            $userData = [
                'id' => $user->id,
                'login' => $user->login,
                'name' => $user->first_name . ' ' . $user->last_name,
                'role' => $user->admin ? 'Administrátor' : ($user->mod ? 'Moderátor' : 'Registrovaný uživatel'),
                'img_name' => $user->img_name,
                'managed_events' => $user->manages->pluck('name')->implode(', '),
                'approved_events' => $user->has_approved_event->pluck('name')->implode(', '),
                'approved_venues' => $user->has_approved_venue->pluck('name')->implode(', '),
                'attending_events' => implode(', ', $attendingEvents),
            ];

            $userList[] = $userData;
        }

        return view('users.index', ['userList' => $userList]);
    }

    public function change_role(Request $request, $user_id)
    {
        $user =  User::find($user_id);

        // Check if the event exists
        if (!$user) {
            return redirect()->route('users_index')->with('error', 'Uživatel nebyl nalezen');
        }

        if ($request->role == "admin") {
            $user->mod = true;
            $user->admin = true;
        }
        else if ($request->role == "mod") {
            $user->mod = true;
            $user->admin = false;
        }
        else {
            $user->mod = false;
            $user->admin = false;
        }
        $user->save();

        // Redirect back to the index page with a success message
        return redirect()->route('users_index')->with('success', 'Uživatelova role byla úspěšně změněna');
    }

    public function destroy($user_id)
    {
        $user =  User::find($user_id);

        // Check if the user exists
        if (!$user) {
            return redirect()->route('users_index')->with('error', 'Uživatel nebyl nalezen');
        }

        if (!is_null($user->img_name)) {
            $path = public_path('storage/images/users/' . $user->img_name);
            if (file_exists($path)) {
                unlink($path);
            }
        }

        $user->delete();

        // Redirect back to the index page with a success message
        return redirect()->route('users_index')->with('success', 'Uživatel byl úspěšně odstraněn');
    }
}
