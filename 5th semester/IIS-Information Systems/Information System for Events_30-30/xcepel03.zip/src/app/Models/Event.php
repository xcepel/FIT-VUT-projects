<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    protected $table = 'events';
    protected $fillable = [
        'name',
        'date_from',
        'date_to',
        'capacity',
        'description'
    ];

    public function venue() {
        return $this->belongsTo(Venue::class, 'venue');
    }

    public function approved_by() {
        return $this->belongsTo(User::class, 'approved_by');
    }

    public function manager() {
        return $this->belongsTo(User::class, 'manager');
    }

    public function category() {
        return $this->belongsTo(Category::class, 'category');
    }

    public function has_comments() {
        return $this->hasMany(Comment::class, 'to_event');
    }

    public function has_tickets() {
        return $this->hasMany(Ticket::class, 'for_event');
    }

    public function has_attendees() {
        return $this->hasMany(IsAttending::class, 'event');
    }

    public function has_images() {
        return $this->hasMany(EventImage::class, 'event');
    }
}
