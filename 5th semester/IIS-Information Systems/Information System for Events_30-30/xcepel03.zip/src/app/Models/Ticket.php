<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
    protected $table = 'tickets';
    protected $fillable = [
        'category',
        'price'
    ];

    public function for_event() {
        return $this->belongsTo(Event::class, 'for_event');
    }

    public function sold() {
        return $this->hasMany(IsAttending::class, 'ticket');
    }
}
