<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Venue extends Model
{
    protected $table = 'venues';
    protected $fillable = [
        'name',
        'description',
        'address_city',
        'address_street',
        'address_house_num',
        'address_postcode'
    ];

    public function approved_by() {
        return $this->belongsTo(User::class, 'approved_by');
    }

    public function takes_place() {
        return $this->hasMany(Event::class, 'venue');
    }

    public function has_images() {
        return $this->hasMany(VenueImage::class, 'venue');
    }

}
