<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    protected $table = 'comments';
    protected $fillable = [
        'rating',
        'content'
    ];

    public function to_event() {
        return $this->belongsTo(Event::class, 'to_event');
    }

    public function wrote() {
        return $this->belongsTo(User::class, 'wrote');
    }
}
