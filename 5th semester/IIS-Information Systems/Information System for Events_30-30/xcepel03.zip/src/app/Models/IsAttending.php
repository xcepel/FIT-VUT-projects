<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IsAttending extends Model
{
    protected $table = 'is_attending';

    public function event() {
        return $this->belongsTo(Event::class, 'event');
    }

    public function user() {
        return $this->belongsTo(User::class, 'user');
    }

    public function has_bought() {
        return $this->belongsTo(Ticket::class, 'ticket');
    }
}
