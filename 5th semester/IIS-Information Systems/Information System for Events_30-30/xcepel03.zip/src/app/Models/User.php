<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $table = 'users';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'login',
        'password',
        'first_name',
        'last_name',
        'admin',
        'mod',
        'img_name'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password'
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'password' => 'hashed',
    ];

    public function manages() {
        return $this->hasMany(Event::class, 'manager');
    }

    public function has_approved_event() {
        return $this->hasMany(Event::class, 'approved_by');
    }

    public function has_approved_venue() {
        return $this->hasMany(Venue::class, 'approved_by');
    }

    public function has_approved_category() {
        return $this->hasMany(Category::class, 'approved_by');
    }

    public function has_wrote() {
        return $this->hasMany(Comment::class, 'wrote');
    }
    public function is_attending() {
        return $this->hasMany(IsAttending::class, 'user');
    }
}
