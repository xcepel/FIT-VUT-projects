<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $table = 'categories';
    protected $fillable = [
        'name'
    ];

    public function is_subtype_of() {
        return $this->belongsTo(Category::class, 'is_subtype_of');
    }

    public function has_subtypes() {
        return $this->hasMany(Category::class, 'is_subtype_of');
    }

    public function approved_by() {
        return $this->belongsTo(User::class, 'approved_by');
    }

    public function has_events() {
        return $this->hasMany(Event::class, 'category');
    }

    // Recursive - Returns all events including subtypes of called category
    public function allEventsIncludingSubtypes()
    {
        $events = $this->has_events;

        foreach ($this->has_subtypes as $subtype) {
            $events = $events->merge($subtype->allEventsIncludingSubtypes());
        }

        return $events;
    }

    // Recursive - Returns array of all supertypes-categories above given category
    public static function getAllSupertypes($category_id)
    {
        $category = self::find($category_id);

        if (!$category) {
            return [];
        }

        $supertypeName = $category->name;
        $parentCategoryId = $category->is_subtype_of;

        return array_merge([$supertypeName], self::getAllSupertypes($parentCategoryId));
    }

    public static function getAllSubtypes($category_id)
    {
        $category = self::find($category_id);
        $subtypes = collect();

        if (!$category) {
            return $subtypes;
        }

        foreach($category->has_subtypes as $subtype) {
            $subtypes->push($subtype);
            $subtypes = $subtypes->merge(self::getAllSubtypes($subtype->id));
        }

        return $subtypes;
    }

}
