/*************************************************
* FILENAME: bottom_up_parser.c
* PROJECT:  IFJ 2022/23
* AUTHORS:  xhalen00 -- Timotej Halenár
*           xtrnov01 -- Eva Trnovská (connecting syntax tree)
*	  
*************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "bottom_up_parser.h"
#include "symtable.h"
#include "syntax_tree.h"
#include "semchecks.h"
#include "error_handle.h"

#define RULE_COUNT 13
#define RULE_LENGTH 3

/**
 * initialises stack.
 * memory must already be allocated.
 * 
 * @param stack stack variable pointer
 */
void init_stack(stack_t *stack){
    stack->top = NULL;
    stack->top_terminal = NULL;
}

/**
 * sets stack_elem type based on token type,
 * because the precedential table only uses
 * a few of them.
 * @param my_stack_elem stack element to set up
 * @param my_token token in the stack element struct
 */
void convert_token(stack_elem *my_stack_elem, token *my_token){
    switch (my_token->type){
        case INT_VAL:
            my_stack_elem->type = ID_b;
            break;
        case FLOAT_VAL:
            my_stack_elem->type = ID_b;
            break;
        case STR_VAL:
            my_stack_elem->type = ID_b;
            break;
        case VARIABLE: 
            my_stack_elem->type = ID_b;
            break;
        case NULL_:
            my_stack_elem->type = ID_b;
            break;
        case SEMICOLON:
            my_stack_elem->type = EXP_END_b;
            break;
        case PLUS:
            my_stack_elem->type = ADD_b;
            break;
        case MINUS:
            my_stack_elem->type = SUB_b;
            break;
        case MUL:
            my_stack_elem->type = MUL_b;
            break;
        case DIV:
            my_stack_elem->type = DIV_b;
            break;
        case DOT:
            my_stack_elem->type = CONC_b;
            break;
        case LEFT_BR:
            my_stack_elem->type = L_PAR_b;
            break;
        case RIGHT_BR:
            my_stack_elem->type = R_PAR_b;
            break;
        case EQ:
            my_stack_elem->type = IS_EQUAL_TYPE_b;
            break;
        case NOT_EQ:
            my_stack_elem->type = IS_NOT_EQUAL_TYPE_b;
            break;
        case BIGGER:
            my_stack_elem->type = GREATER_b;
            break;
        case SMALLER:
            my_stack_elem->type = LESSER_b;
            break;
        case BIGGER_EQ:
            my_stack_elem->type = GREATER_E_b;
            break;
        case SMALLER_EQ:
            my_stack_elem->type = LESSER_E_b;
            break;
        case END:
            my_stack_elem->type = EXP_END_b;
            break;
        default:
            //in case of unknown type
            my_stack_elem->type = 99;
            break;
    }
}

/**
 * creates stack element, inserts token, sets type, pushes onto stack.
 * 
 * @param stack stack variable pointer
 * @param token token to be pushed onto stack
 */
void push(stack_t *stack, token *token){
    //create new element
    stack_elem *new_elem = (stack_elem*)malloc(sizeof(stack_elem));
    if (new_elem == NULL){
        error_handle(INTERNAL_ERROR_MESSAGE, 0);
    }
    new_elem->token_data = *token;
    new_elem->next = stack->top;
    new_elem->prev = NULL; 

    //printf("TYPE: %d\n", new_elem->token_data.type);

    //this function is only used to push tokens -> all terminal
    new_elem->is_terminal = 1;

    if (stack->top != NULL){
        stack->top->prev = new_elem;
    }
    stack->top = new_elem;
    stack->top_terminal = new_elem;

    //set stack_elem->type based on token.type
    convert_token(new_elem, token);
}

/**
 * pushes EXPRESSION onto stack.
 * used during reduction.
 * 
 * @param stack stack variable pointer
 */
void push_expr(stack_t *stack, node_t *node){
    stack_elem *new_elem = (stack_elem*)malloc(sizeof(stack_elem));
    if (new_elem == NULL){
        error_handle(INTERNAL_ERROR_MESSAGE, 0);
    }
    new_elem->next = stack->top;
    new_elem->node = node;

    //pushing an EXPRESSION, therefore non-terminal
    new_elem->is_terminal = 0;
    if (stack->top != NULL){
        stack->top->prev = new_elem;
    }
    stack->top = new_elem;

    //EXPRESSION element does not contain a token
    //type cannot be set using convert_token()
    new_elem->type = EXPR_b;

    //because a reduction has been performed, stack->top_terminal must be set again
    top_terminal(stack);
}

/**
 * inserts element of type HANDLE_START.
 * 
 * 
 * @param stack stack variable pointer
 * @param active_elem element, above which the HANDLE_START should be inserted
 */
void insert(stack_t *stack, stack_elem *active_elem){
    stack_elem *new_elem = (stack_elem*)malloc(sizeof(stack_elem));
    if (new_elem == NULL){
        error_handle(INTERNAL_ERROR_MESSAGE, 0);
    }
    new_elem->type = HANDLE_START_b;
    new_elem->next = active_elem;
    if (active_elem->prev != NULL){ 
        new_elem->prev = active_elem->prev;
        active_elem->prev->next = new_elem;
    }
    else{
        new_elem->prev = NULL;
        stack->top = new_elem;
    }
    active_elem->prev = new_elem;
}

/**
 * pops an element from the stack.
 * 
 * @param stack stack variable pointer
 */
void pop(stack_t *stack){
    stack_elem *temp;
    if (stack->top != NULL){
        temp = stack->top;
        stack->top = stack->top->next;
        stack->top->prev = NULL;
        free(temp);
    }
}

/**
 * frees stack.
 * 
 * @param stack stack variable pointer 
 */
void dispose_stack(stack_t *stack) {
  stack_elem *temp = stack->top;
  while (temp != NULL) {
    stack_elem *next = temp->next;
    free(temp);
    temp = next;
  }
  free(stack);
}


/**
 * compares handle found on the stack with rules.
 * used by reduce()
 * 
 * @param handle int array containing handle from stack
 * @return 1 if a match was found, 0 if no match was found
 */
int compare_handle(int *handle){
//handles of rules
//since the left side is always EXPRESSION, only right sides are relevant
int ruleset[RULE_COUNT][RULE_LENGTH] = {
    {EXPR_b, ADD_b, EXPR_b},
    {EXPR_b, SUB_b, EXPR_b},
    {EXPR_b, MUL_b, EXPR_b},
    {EXPR_b, DIV_b, EXPR_b},
    {EXPR_b, CONC_b, EXPR_b},
    {EXPR_b, IS_EQUAL_TYPE_b, EXPR_b},
    {EXPR_b, IS_NOT_EQUAL_TYPE_b, EXPR_b},
    {EXPR_b, LESSER_b, EXPR_b},
    {EXPR_b, GREATER_b, EXPR_b},
    {EXPR_b, LESSER_E_b, EXPR_b},
    {EXPR_b, GREATER_E_b, EXPR_b},
    {L_PAR_b, EXPR_b, R_PAR_b},
    {EMPTY_b, EMPTY_b, ID_b}
};

    int found = 0;
    for (int i = 0; i < RULE_COUNT; i++){
        found = 1;
        for (int j = 0; j < 3; j++){
            if (handle[j] != ruleset[i][j]){
                found = 0;
                break;
            }
        }
        if (found == 1){
            break;
        }
    }
    return found;
}


bool stree_add_parent(node_t *first, node_t *second, node_t* parent){
    first->parent = parent;
    if (second != NULL){
	second->parent = parent;
    }
    node_t *free_space = parent->first_child;
    if (free_space == NULL){
	parent->first_child = first;
	first->parent = parent;
	if (parent->first_child != NULL){
	    parent->first_child->next_sibling = second;
	    return true;
	}
	return false;
    }
    else {
        free_space->next_sibling = first;
        if (free_space->next_sibling != NULL){
            free_space->next_sibling->next_sibling = second;
            return true;
        }
        return false;
    }
}


/**
 * Converts type of stack element to node type
 * 
 * @param el stack element whose type is to be converted to node type
 * @return corresponding node type (node_type_t)
 */
node_type_t stack_elem_to_node_type(stack_elem *el){
    switch (el->type){
        case ADD_b:
	    return N_ADD;
	case MUL_b:
	    return N_MUL;
	case SUB_b:
	    return N_SUB;
	case DIV_b:
	    return N_DIV;
	case CONC_b:
	    return N_CONC; 
	case IS_EQUAL_TYPE_b:
	    return N_EQUAL;
	case IS_NOT_EQUAL_TYPE_b:
	    return N_NOT_EQUAL;
	case LESSER_b:
	    return N_LS;
	case GREATER_b:
	    return N_GR;
	case LESSER_E_b:
	    return N_LE;
	case GREATER_E_b:
	    return N_GE;
	default:
	    return N_UNKNOWN;
    }
}

/**
 * finds handle on top of stack, calls compare_handle().
 * if a match is found, handle is replaced by E
 * 
 * @param stack stack variable pointer
 * @return 1 if successful, 0 if not
 */
int reduce(stack_t *stack, node_t *parent){
    htab_t *symtable = parent->current_table;
    int handle[3] = {EMPTY_b, EMPTY_b, EMPTY_b};
    stack_elem *temp;
    int i = 0;
    node_t *new_node = NULL;
    temp = stack->top;

    //find handle beginning
    while (temp->type != HANDLE_START_b){
        handle[i] = temp->type;
        i++;
        temp = temp->next;
    }

    //reverse order to accomodate for parentheses, operation order
    int swap = handle[2];
    handle[2] = handle[0];
    handle[0] = swap;

    if (compare_handle(handle)){
        for(int j = 0; j <= i; j++){
	    if (stack->top->type == ID_b){
		// Creates leaf node
		new_node = stree_empty_node();
		new_node->current_table = symtable;
		if (stack->top->token_data.type == VARIABLE){
		    stree_add_variable(new_node, &(stack->top->token_data), false);
		}
		else {
		    stree_add_terminal(new_node, &(stack->top->token_data));
		}
	    }
	    else if (stack->top->type == EXPR_b){
		// Creates node for operation and connects it with its children
		if (stack->top->next->type != HANDLE_START_b){
		    new_node  = stree_empty_node();
		    new_node->current_table = symtable;
		    stack->top->next->node = new_node;

		    node_type_t n_type = stack_elem_to_node_type(stack->top->next);
		    stree_set_type(new_node, n_type);
		    stree_add_parent(stack->top->next->next->node, stack->top->node, stack->top->next->node);
		}
	    }

	    pop(stack);
        }
        push_expr(stack, new_node);
	stree_add_parent(new_node, NULL, parent);
        return 1;
    }
    else {
        return 0;
    }
}

/**
 * finds terminal closest to the top on stack.
 * sets stack->top_terminal accordingly.
 * 
 * @param stack stack variable pointer
 */
void top_terminal(stack_t *stack){
    stack_elem *temp = stack->top;
    while (temp->is_terminal == 0){
        temp = temp->next;
    }
    stack->top_terminal = temp;
}

/**
 * prints stack elements from top to bottom.
 * 
 * @param stack stack variable pointer
 */
void stack_state(stack_t *stack){
    //used for test prints
    const char *type[] = {"+", "*", "(", ")", "id", ";", "/", "-", ".", "===", "!==", "<", ">", "<=", ">=", "HANDLE_START", "REDUCE", "E", ""};
    stack_elem *temp = NULL; //
    temp = stack->top;
    printf("*******************\n");
    printf("stack state: ");
    
    if (temp == NULL){
        printf("stack is empty\n");
    }
    
    while(temp != NULL){
        printf("%s, ", type[temp->type]);
        temp = temp->next;
    }
    printf("\n");
    printf("*******************\n");
    
}

/**
 * analyses.
 * 
 * @return 0 if successful, 1 if not. 
 */
int bottom_up_analysis(token *previous_input, token *input, node_t *n){
    bool is_previous;

    const char p_table[15][15] = {
    {'>', '<', '<', '>', '<', '>', '<', '>', '>', '>', '>', '>', '>', '>', '>'},
    {'>', '>', '<', '>', '<', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>'},
    {'<', '<', '<', '=', '<', 'x', '<', '<', '<', '<', '<', '<', '<', '<', '<'},
    {'>', '>', 'x', '>', 'x', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>'},
    {'>', '>', 'x', '>', 'x', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>'},
    {'<', '<', '<', 'x', '<', 'x', '<', '<', '<', '<', '<', '<', '<', '<', '<'},
    {'>', '>', '<', '>', '<', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>'},
    {'>', '<', '<', '>', '<', '>', '<', '>', '>', '>', '>', '>', '>', '>', '>'},
    {'>', '<', '<', '>', '<', '>', '<', '>', '>', '>', '>', '>', '>', '>', '>'},
    {'<', '<', '<', '>', '<', '>', '<', '<', '<', '>', '>', '<', '<', '<', '<'},
    {'<', '<', '<', '>', '<', '>', '<', '<', '<', '>', '>', '<', '<', '<', '<'},
    {'<', '<', '<', '>', '<', '>', '<', '<', '<', '>', '>', '>', '>', '>', '>'},
    {'<', '<', '<', '>', '<', '>', '<', '<', '<', '>', '>', '>', '>', '>', '>'},
    {'<', '<', '<', '>', '<', '>', '<', '<', '<', '>', '>', '>', '>', '>', '>'},
    {'<', '<', '<', '>', '<', '>', '<', '<', '<', '>', '>', '>', '>', '>', '>'}
    };

    //stack is initialised
    stack_t *stack = (stack_t *) malloc(sizeof(stack_t));
    if (stack == NULL){
        error_handle(INTERNAL_ERROR_MESSAGE, 0);
    }
    init_stack(stack);

    //token is obtained and stack element prepared
    stack_elem *input_elem = (stack_elem *)malloc(sizeof(stack_elem));
    if (input_elem == NULL){
        error_handle(INTERNAL_ERROR_MESSAGE, 0);
    }
    if (previous_input != NULL){
        if(previous_input->type == VARIABLE){
            sem_check_undefined_variable(n->current_table, previous_input->val.s_val, previous_input->line);
        }
        convert_token(input_elem, previous_input);
        is_previous = true;
    }
    else{
        convert_token(input_elem, input);
        is_previous = false;
    }
    

    //push ; onto the stack
    token bottom_token;
    bottom_token.type = END;
    push(stack, &bottom_token);

    //the loop where it all happens
    while(!((input->type == SEMICOLON || input->type == RIGHT_BR) && stack->top->type == EXPR_b && (stack->top->next->type == EXP_END_b))){
    
        //top terminal is found and set
        //just in case
        top_terminal(stack);  

        //invalid operator/type
        if (input_elem->type == 99){
            printf("token.type: %d\n", input->type);  
	    return 1;
        }
        
	    //find symbol in table
        switch (p_table[stack->top_terminal->type][input_elem->type]){ 
            case '<':
                insert(stack, stack->top_terminal);
                if (is_previous){
                    push(stack, previous_input);
                    convert_token(input_elem, input);
                    is_previous = false;
                }
                else{
                    push(stack, input);
                    *input = get_token();
                    if(input->type == VARIABLE){
                        sem_check_undefined_variable(n->current_table, input->val.s_val, input->line);
                    }
                    convert_token(input_elem, input);
                    break;
                }
                
            case '>':
                if (!reduce(stack, n)){
                    return 1;
                }
                break;
            case '=':
                push(stack, input);
                *input = get_token();
                if(input->type == VARIABLE){
                    sem_check_undefined_variable(n->current_table, input->val.s_val, input->line);
                }
                convert_token(input_elem, input);
                break;
            case 'x':
                return 1;
                break;
            default:
                return 1;
                break;
        }
    }
    dispose_stack(stack);
    free(input_elem);
    return 0;
}

/***** END OF FILE bottom_up_parser.c *****/
