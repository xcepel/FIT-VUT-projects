/*************************************************
* FILENAME: linked_list.h
* PROJECT:  IFJ 2022/23
* AUTHORS:  xtrnov01 -- Eva Trnovská
*	  
*************************************************/

#ifndef __LIST_H__
#define __LIST_H__

#include "symtable.h"
#include "syntax_tree.h"

typedef struct elem elem_t; 

struct elem{
    char *item;
    elem_t *next;
    elem_t *prev;
};

typedef struct elem * list_t;

void list_print(list_t l);

elem_t *list_next(list_t l);

elem_t *list_last(list_t l);

void list_add(list_t *l, char *format, ...);

void list_move_defvar(list_t l);

void list_delete_last(list_t *l);

void list_free(list_t l);


#endif 

/***** END OF FILE linked_list.h *****/
