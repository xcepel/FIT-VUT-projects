/*************************************************
* FILENAME: parser.c
* PROJECT:  IFJ 2022/23
* AUTHORS:  xstast38 -- Mikuláš Šťastný
*           xtrnov01 -- Eva Trnovská (connecting syntax tree)
*	  
*************************************************/

#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include "scanner.h"
#include "bottom_up_parser.h"
#include "symtable.h"
#include "syntax_tree.h"
#include "error_handle.h"
#include "generator.h"
#include "linked_list.h"
#include "semchecks.h"

htab_t *symtable;

// function for each non-terminal
bool prog_LL(token *current_token, stree_t *tree);
bool begin_LL(token *current_token);
bool st_list_LL(token *current_token, stree_t *tree);
bool in_block_st_list_LL(token *current_token, node_t *n);
bool stat_LL(token *current_token, node_t *n);
bool func_def_head_LL(token *current_token, node_t *n);
bool func_def_tail_LL(token *current_token, node_t *n);
bool if_else_head_LL(token *current_token, node_t *n);
bool if_else_tail_LL(token *current_token, node_t *n);
bool if_LL(token *current_token, node_t *n);
bool else_LL(token *current_token, node_t *n);
bool while_LL(token *current_token, node_t *n);
bool param_list_head_LL(token *current_token, node_t *n);
bool param_list_tail_LL(token *current_token, node_t *n);
bool param_LL(token *current_token, node_t *n);
bool type_LL(token *current_token, node_t *n);
bool return_stat_head_LL(token *current_token, node_t *n);
bool return_stat_tail_LL(token *current_token, node_t *n);
bool end_LL(token *current_token);
bool term_LL(token *current_token, node_t *n);
bool term_list_head_LL(token *current_token, node_t *n);
bool term_list_tail_LL(token *current_token, node_t *n);
bool func_call_LL(token *current_token, node_t *n);
bool assign_head_LL(token *current_token, node_t *n);
bool assign_tail_LL(token *current_token, node_t *n);

bool prog_LL(token *current_token, stree_t *tree){
    switch (current_token->type){
        case BEGIN:
            return begin_LL(current_token) && st_list_LL(current_token, tree) && end_LL(current_token);
        default:
            return false;
    }
}

bool begin_LL(token *current_token){
    switch (current_token->type){
        case BEGIN:
            *current_token = get_token();
            if(current_token->type != ID){
                return false;
            }
            if(strcmp(current_token->val.s_val, "declare")){
                return false;
            }
            *current_token = get_token();
            if(current_token->type != LEFT_BR){
                return false;
            }
            *current_token = get_token();
            if(current_token->type != ID){
                return false;
            }
            if(strcmp(current_token->val.s_val, "strict_types")){
                return false;
            }
            *current_token = get_token();
            if(current_token->type != ASSIGN){
                return false;
            }
            *current_token = get_token();
            if(current_token->type != INT_VAL){
                return false;
            }
            if(current_token->val.i_val != 1){
                return false;
            }
            *current_token = get_token();
            if(current_token->type != RIGHT_BR){
                return false;
            }
            *current_token = get_token();
            if(current_token->type != SEMICOLON){
                return false;
            }
            *current_token = get_token();
            return true;
    
        default:
            return false;
    }
}

bool st_list_LL(token *current_token, stree_t *tree){
    node_t *prev_child = stree_last_child(*tree);
    node_t *child = stree_create_child(*tree);
    switch(current_token->type){
        // The following cases are for statement (could be expression, function call or assignment)
        case STR_VAL:
        case INT_VAL:
        case FLOAT_VAL:
        case LEFT_BR:
        case ID:
        case VARIABLE:
        case NULL_:
            if(!stat_LL(current_token, child)){

                return false;
            }
            if(current_token->type != SEMICOLON){
                return false;
            }
            *current_token = get_token();
            return st_list_LL(current_token, tree);
        case IF:
            if(!if_else_head_LL(current_token, child)){
                return false;
            }
            return st_list_LL(current_token, tree);
        case WHILE:
            if(!while_LL(current_token, child)){
                return false;
            }
            return st_list_LL(current_token, tree);
        case RETURN:
            if(!return_stat_head_LL(current_token, child)){
                return false;
            }
            return st_list_LL(current_token, tree);
        case FUNCTION:
            if(!func_def_head_LL(current_token, child)){
                return false;
            }
            return st_list_LL(current_token, tree);
        case END:
	    if (prev_child != NULL){
	        prev_child->next_sibling = NULL;
	    }
            return true;
        default:
            return false;
    }
}

bool in_block_st_list_LL(token *current_token, node_t *n){
    node_t *prev_child = stree_last_child(n);
    node_t *child = stree_create_child(n);
    switch(current_token->type){
        // The following cases are for statement (could be expression, function call or assignment)
        case STR_VAL:
        case INT_VAL:
        case FLOAT_VAL:
        case LEFT_BR:
        case ID:
        case VARIABLE:
        case NULL_:
            if(!stat_LL(current_token, child)){
                return false;
            }
            if(current_token->type != SEMICOLON){
                return false;
            }
            *current_token = get_token();
            return in_block_st_list_LL(current_token, n);
        case IF:
            if(!if_else_head_LL(current_token, child)){
                return false;
            }
            return in_block_st_list_LL(current_token, n);
        case WHILE:
            if(!while_LL(current_token, child)){
                return false;
            }
            return in_block_st_list_LL(current_token, n);
        case RETURN: 
            if(!return_stat_head_LL(current_token, child)){
                return false;
            }
            return in_block_st_list_LL(current_token, n);

        case BLOCK_END:
	    if (prev_child != NULL){
	        prev_child->next_sibling = NULL;
	    }
	    else {
 		n->first_child = NULL;
	    }
            return true;
        default:
            return false;
    }
}

bool stat_LL(token *current_token, node_t *n){
    switch(current_token->type){
        case VARIABLE:
            return assign_head_LL(current_token, n);
        case ID:
            sem_check_function_definition(symtable, current_token->val.s_val, current_token->line);
	          stree_add_func_call(n, current_token);
            return func_call_LL(current_token, n);
        // Cases for expression
        case STR_VAL: 
        case INT_VAL:
        case FLOAT_VAL:
	    case NULL_:
        case LEFT_BR:
            if(bottom_up_analysis(NULL, current_token, n) == 1){
                return false;
            }
            else{
                return true;
            }
        default:
            return false;
    }
}

bool func_def_head_LL(token *current_token, node_t *n){
    switch (current_token->type){
        case FUNCTION:
            *current_token = get_token();
            if(current_token->type != ID){
                return false;
            }
            sem_check_function_redefinition(symtable, current_token->val.s_val, current_token->line);
	          stree_add_func_def(n, current_token); 
            *current_token = get_token();
            if(current_token->type != LEFT_BR){
                return false;
            }
            *current_token = get_token();
            if(!param_list_head_LL(current_token, n)){
                return false;
            }
            if(current_token->type != RIGHT_BR){
                return false;
            }
            *current_token = get_token();
            if(current_token->type != COLON){
                return false;
            }
            *current_token = get_token();
            return func_def_tail_LL(current_token, n);
        default:
            return false;
    }
}

bool func_def_tail_LL(token *current_token, node_t *n){
    node_t *return_type = stree_create_child(n);
    switch(current_token->type){
        case VOID:
	        stree_set_type(return_type, N_VOID_R);
	        return_type->parent->data.function->return_type = H_VOID_FUNC;
	        break;
        case STRING:
	        stree_set_type(return_type, N_STRING_R);
	        return_type->parent->data.function->return_type = H_STRING_ID;
	        break;
        case INT:
	        stree_set_type(return_type, N_INT_R);
	        return_type->parent->data.function->return_type = H_INT_ID;
	        break;
        case FLOAT:
	        stree_set_type(return_type, N_FLOAT_R);
	        return_type->parent->data.function->return_type = H_FLOAT_ID;
	        break;
        case Q_INT:
            stree_set_type(return_type, N_Q_INT_R);
	        return_type->parent->data.function->return_type = H_Q_INT_ID;
            break;
        case Q_FLOAT:
            stree_set_type(return_type, N_Q_FLOAT_R);
	        return_type->parent->data.function->return_type = H_Q_FLOAT_ID;
            break;
        case Q_STRING:
            stree_set_type(return_type, N_Q_STRING_R);
	        return_type->parent->data.function->return_type = H_Q_STRING_ID;
            break;
        default:
            return false;
    }
    *current_token = get_token();
    if(current_token->type != BLOCK_START){
        return false;
    }
    *current_token = get_token();
    if(!in_block_st_list_LL(current_token, n)){
        return false;
    }
    if(current_token->type != BLOCK_END){
        return false;
    }
    *current_token = get_token();
    return true;
}

bool if_else_head_LL(token *current_token, node_t *n){
    switch(current_token->type){
        case IF:
            if(!if_LL(current_token, n)){
                return false;
            }
            return if_else_tail_LL(current_token, n);
        default:
            return false;
    }
}

bool if_else_tail_LL(token *current_token, node_t *n){
    switch(current_token->type){
        case ELSE:
            return else_LL(current_token, n);
        // The following cases for no else statement (next token can be anything from st_list)
        case STR_VAL:
        case INT_VAL:
        case FLOAT_VAL:
        case LEFT_BR:
        case VARIABLE:
        case ID:
        case IF:
        case WHILE:
        case RETURN:
        case FUNCTION:
        case END: // TODO Transfer to END:
            return true;
        default:
            return false;          
    }
}

bool if_LL(token *current_token, node_t *n){
    node_t *code_block = NULL;
    node_t *cond = NULL;
    node_t *arb = NULL;
    switch(current_token->type){
        case IF:
	    stree_set_type(n, N_IF);
	    cond = stree_create_child(n);
	    stree_set_type(cond, N_CONDITION);
	    arb = stree_create_child(cond);
            *current_token = get_token();
            if(current_token->type != LEFT_BR){
                return false;
            }
            *current_token = get_token();
            // calls bottom-up parser for evaluating expression
            if(bottom_up_analysis(NULL, current_token, cond) == 1){
                return false;
            }
            if(current_token->type != RIGHT_BR){
                return false;
            }
            *current_token = get_token();
	    code_block = stree_create_child(n);
	    stree_set_type(code_block, N_BLOCK);
            if(current_token->type != BLOCK_START){
                return false;
            }
            *current_token = get_token();
            if(!in_block_st_list_LL(current_token, code_block)){
                return false;
            }
            if(current_token->type != BLOCK_END){
                return false;
            }
            *current_token = get_token();
            return true;
        default:
            return false;
    }
}

bool else_LL(token *current_token, node_t *n){
    node_t *else_node = NULL;
    node_t *code_block = NULL;
    switch(current_token->type){
        case ELSE:
	    else_node = stree_create_sibling(n);
	    stree_set_type(else_node, N_ELSE); 
            *current_token = get_token();
            if(current_token->type != BLOCK_START){
                return false;
            }
            *current_token = get_token();
	    code_block = stree_create_child(else_node);
	    stree_set_type(code_block, N_BLOCK);
            if(!in_block_st_list_LL(current_token, code_block)){
                return false;
            }
            if(current_token->type != BLOCK_END){
                return false;
            }
            *current_token = get_token();
            return true;
        default:
            return false;
    }
}

bool while_LL(token *current_token, node_t *n){
    node_t *arb = NULL;
    node_t *cond = NULL;
    node_t *code_block = NULL;
    switch(current_token->type){
        case WHILE:
	        stree_set_type(n, N_WHILE);
	        cond = stree_create_child(n);
	        stree_set_type(cond, N_CONDITION);
	        arb = stree_create_child(cond);
            *current_token = get_token();
            if(current_token->type != LEFT_BR){
                return false;
            }
            *current_token = get_token();
            // calls bottom-up parser for evaluating expression
            if(bottom_up_analysis(NULL, current_token, cond) == 1){
                return false;
            }
            if(current_token->type != RIGHT_BR){
                return false;
            }
            *current_token = get_token();
	        code_block = stree_create_child(n);
	        stree_set_type(code_block, N_BLOCK);
            if(current_token->type != BLOCK_START){
                return false;
            }
	        *current_token = get_token(); 
            if(!in_block_st_list_LL(current_token, code_block)){
                return false;
            }
            if(current_token->type != BLOCK_END){
                return false;
            }
            *current_token = get_token();
            return true;
        default:
            return false;
    }
}

bool param_list_head_LL(token *current_token, node_t *n){
    switch(current_token->type){
        case STRING:
        case INT:
        case FLOAT:
        case Q_STRING:
        case Q_INT:
        case Q_FLOAT:
            if(!param_LL(current_token, n)){ //!!
                return false;
            }
            *current_token = get_token();
            return param_list_tail_LL(current_token, n);
        case RIGHT_BR:
            return true;
        default:
            return false;
    }
}

bool param_list_tail_LL(token *current_token, node_t *n){
    switch(current_token->type){
        case COMMA:
            *current_token = get_token();
            if(!param_LL(current_token, n)){ //!!
                return false;
            }
            *current_token =  get_token();
            return param_list_tail_LL(current_token, n);
        case RIGHT_BR:
            return true;
        default:
            return false;
    }
}

bool param_LL(token *current_token, node_t *n){
    node_t *param = stree_create_child(n);
    id_type param_type;
    switch(current_token->type){
        case STRING:
	        stree_set_type(param, N_STRING_P);
            param_type = H_STRING_ID;
	        break;
        case INT:
	        stree_set_type(param, N_INT_P);
            param_type = H_INT_ID;
	        break;
        case FLOAT:
	        stree_set_type(param, N_FLOAT_P);
            param_type = H_FLOAT_ID;
 	        break;
        case Q_STRING:
            stree_set_type(param, N_Q_STRING_R);
            param_type = H_Q_STRING_ID;
        case Q_INT:
            stree_set_type(param, N_Q_INT_R);
            param_type = H_Q_INT_ID;
        case Q_FLOAT:
            stree_set_type(param, N_Q_FLOAT_R);
            param_type = H_Q_FLOAT_ID;
        default:
            return false;
    }
    *current_token = get_token();
    if(current_token->type != VARIABLE){
        return false;
    }
    sem_check_params_redefinition(param->parent->data.function, current_token->val.s_val, current_token->line);
    htab_add_param(param_type, current_token->val.s_val, param->parent->data.function);
    node_t *var = stree_create_child(param);
    stree_add_variable(var, current_token, true);
    return true;
}

bool return_stat_head_LL(token *current_token, node_t *n){
    switch(current_token->type){
        case RETURN:
	    stree_set_type(n, N_RETURN);
            *current_token = get_token();
            return return_stat_tail_LL(current_token, n);
        default:
            return false;

    }
}

bool return_stat_tail_LL(token *current_token, node_t *n){
    node_t *cond = NULL;
    switch(current_token->type){
        case SEMICOLON:
            *current_token = get_token();
            return true;
        // Cases for expression
        case INT_VAL:
        case STR_VAL:
        case FLOAT_VAL:
        case LEFT_BR:
        case NULL_: //
        case VARIABLE:
	        cond = stree_create_child(n);
            // calls bottom-up parser for evaluating expression
            if(bottom_up_analysis(NULL, current_token, n) == 1){ ///
                return false;
            }
            if(current_token->type != SEMICOLON){
                return false;
            }
            *current_token = get_token();
            return true;
        default:
            return false;

    }
}

bool end_LL(token *current_token){
    switch(current_token->type){
        case END:
            return true;
        default:
            return false; 
    }
}

bool term_LL(token *current_token, node_t *n){
    switch(current_token->type){
	case VARIABLE:
        sem_check_undefined_variable(n->current_table, current_token->val.s_val, current_token->line);
	    stree_add_variable(n, current_token, false);
	    *current_token = get_token();
	    return true;
    case STR_VAL:
    case INT_VAL:
    case FLOAT_VAL:
    case NULL_:
	    stree_add_terminal(n, current_token);
        *current_token = get_token();
        return true;
    default:
        return false;
    }
}

bool term_list_head_LL(token *current_token, node_t *n){
    node_t *argument = NULL;
    switch(current_token->type){
	    case VARIABLE:
            sem_check_undefined_variable(n->current_table, current_token->val.s_val, current_token->line);
            argument = stree_create_child(n);
            stree_add_variable(argument, current_token, false);
            *current_token = get_token(); 
            return term_list_tail_LL(current_token, argument);
        case STR_VAL:
        case INT_VAL:
        case FLOAT_VAL:
        case NULL_: 
            argument = stree_create_child(n);
            stree_add_terminal(argument, current_token);
            *current_token = get_token();
            return term_list_tail_LL(current_token, argument);
        case RIGHT_BR:
            return true;
        default:
            return false;
    }
}

bool term_list_tail_LL(token *current_token, node_t *n){
    switch(current_token->type){
        case COMMA:
            *current_token = get_token();
	        node_t *next_param = stree_create_sibling(n);
            if(!term_LL(current_token, next_param)){
                return false;
            }
            return term_list_tail_LL(current_token, next_param); 
        case RIGHT_BR:
            return true;
        default:
            return false;
    }
}

bool func_call_LL(token *current_token, node_t *n){
    switch(current_token->type){
        case ID:
            *current_token = get_token();
            if(current_token->type != LEFT_BR){
                return false;
            }
            *current_token = get_token();
            if(!term_list_head_LL(current_token, n)){
                return false;
            }
            if(current_token->type != RIGHT_BR){
                return false;
            }
            *current_token = get_token();
            return true;
    }
}

bool assign_head_LL(token *current_token, node_t *n){
    token previous_token = *current_token;
    *current_token = get_token();
    // Hack for only expression statement - after variable can be operator
    if(current_token->type == PLUS || current_token->type == MINUS || current_token->type == MUL || current_token->type == DIV || current_token->type == DOT || current_token->type == SEMICOLON){
	stree_set_type(n, N_EXPR_ONLY);
	node_t *arb = stree_create_child(n);
        if(bottom_up_analysis(&previous_token, current_token, n) == 1){
            return false;
        }
        else{
            return true;
        }
    }
    else if(current_token->type == ASSIGN){
	stree_set_type(n, N_ASSIGN);
	node_t *left_val = stree_create_child(n);
	stree_add_variable(left_val, &previous_token, true);
        *current_token = get_token();
        return assign_tail_LL(current_token, n);
    }
    else{
        return false;
    }
}

bool assign_tail_LL(token *current_token, node_t *n){
    node_t *child = NULL;
    switch(current_token->type){
        // Cases for expression
        case STR_VAL:
        case INT_VAL:
        case FLOAT_VAL:
        case LEFT_BR:
        case VARIABLE:
        case NULL_:
            // calls bottom-up parser for evaluating expression
            if(bottom_up_analysis(NULL, current_token, n) == 1){
                return false;
            }
            return true;
        case ID:
            // It is function call
            sem_check_function_definition(symtable, current_token->val.s_val, current_token->line);
            child = stree_create_child(n);
            stree_add_func_call(child, current_token);
            return func_call_LL(current_token, child);
        default:
            return false;
    }
}

int main(){
    symtable = htab_init(13);
    stree_t tree = stree_create_root(symtable);
    token current_token = get_token();

    if(!prog_LL(&current_token, &tree)){
        // For syntax error
        stree_dispose(&tree);
        htab_free(symtable);
        error_handle(SYNTAX_ERROR, current_token.line);
    }
    list_t l = NULL;
    generate_start(&l);
    generate_statements(tree, &l, false);
    generate_end(&l);
    list_move_defvar(l);
    list_print(l);
    list_free(l);
    stree_dispose(&tree);
    htab_free(symtable);
}

/***** END OF FILE parser.c *****/
