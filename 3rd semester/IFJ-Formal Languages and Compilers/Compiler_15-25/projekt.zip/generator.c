/*************************************************
* FILENAME: generator.c
* PROJECT:  IFJ 2022/23
* AUTHORS:  xtrnov01 -- Eva Trnovská
* 	    xhalen00 -- Timotej Halenár (substring) 
* 	    xcepel03 -- Kateřina Čepelková (escape sequences)
*	  
*************************************************/
#include "generator.h"
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include "linked_list.h"
#include "symtable.h"
#include "error_handle.h"

/** 
 * Prints new line
 * @param l List of instructions
 */
void write_new_line(list_t *l){
    list_add(l, "WRITE string@\\010\n");
}

void generate_undefined_variable(list_t *l);

void generate_variable_definition(list_t *l, const char *variable_name);

/** 
 * Applies given function recursively on a (sub)tree, traversing it in order
 * @param tree Abstract syntax tree to be traversed
 * @param func Void function to be applied on all children of a given tree, 
 * accepting a syntax tree and list of instruction as parameters
 * @param l List of instructions
 */
void foreach(stree_t tree, void (*func)(stree_t, list_t*), list_t *l){
    if (tree == NULL){
	    return;
    }
    foreach(tree->first_child, func, l);
    (*func)(tree, l);
    foreach(tree->next_sibling, func, l);
}

/**
 * Generates variables used for semantic controls
 * @param l List of instructions 
 */
void generate_tmp_variables(list_t *l){
    list_add(l, "DEFVAR GF@tmp1\n");
    list_add(l, "DEFVAR GF@tmp2\n");
    list_add(l, "DEFVAR GF@tmp3\n");
    list_add(l, "DEFVAR GF@type1\n");
    list_add(l, "DEFVAR GF@type2\n");
    list_add(l, "DEFVAR GF@same_types\n");
    list_add(l, "DEFVAR GF@semantic\n");
}

/**
 * Checks operand types for addition, multiplication, subtraction and division
 * @param l List of instructions
*/
void generate_arithmetic_semantic(list_t *l){
    // Operand type checking
    list_add(l, "JUMP _artihmetic_semantic_end\n");
    list_add(l, "LABEL _arithmetic_semantic\n");
    list_add(l, "POPS GF@tmp1\n");
    list_add(l, "TYPE GF@type1 GF@tmp1\n");
    list_add(l, "POPS GF@tmp2\n");
    list_add(l, "TYPE  GF@type2 GF@tmp2\n");
    list_add(l, "JUMPIFEQ _same_type GF@type1 GF@type2\n");
    
    // One is INT and one is FLOAT
    list_add(l, "JUMPIFEQ _one_is_int GF@type1 string@int\n");
    list_add(l, "JUMPIFEQ _one_is_int GF@type2 string@int\n"); //second is int
    list_add(l, "JUMPIFEQ _is_sharp_cond GF@semantic string@sharp\n"); 
    list_add(l, "JUMPIFEQ _is_sharp_cond GF@semantic string@not_sharp\n");
    list_add(l, "JUMP _no_ok\n");
    list_add(l, "LABEL _one_is_int\n");
    list_add(l, "JUMPIFEQ _float_and_int GF@type1 string@float\n");

    list_add(l, "JUMPIFEQ _int_and_float GF@type2 string@float\n");
    list_add(l, "JUMPIFEQ _is_sharp_cond GF@semantic string@sharp\n"); //
    list_add(l, "JUMPIFEQ _is_sharp_cond GF@semantic string@not_sharp\n"); //
    list_add(l, "JUMP _not_ok\n");

    // Convert tmp1 (INT) to FLOAT or vice versa
    list_add(l, "LABEL _int_and_float\n");
    list_add(l, "INT2FLOAT GF@tmp3 GF@tmp1\n");
    list_add(l, "MOVE GF@tmp1 GF@tmp3\n");
    list_add(l, "JUMP _type_check_ok\n");
    list_add(l, "LABEL _float_and_int\n");
    list_add(l, "INT2FLOAT GF@tmp3 GF@tmp2\n");
    list_add(l, "MOVE GF@tmp2 GF@tmp3\n");
    list_add(l, "JUMP _type_check_ok\n");

    // Is one null?
    list_add(l, "LABEL _is_sharp_cond\n");
    list_add(l, "JUMPIFEQ _one_is_null GF@type1 string@nil\n");
    list_add(l, "JUMPIFEQ _one_is_null GF@type2 string@nil\n");    
    list_add(l, "JUMP _not_ok\n");
    list_add(l, "LABEL _one_is_null\n");
    list_add(l, "JUMPIFEQ _sharp_ GF@semantic string@sharp\n");
    list_add(l, "JUMPIFNEQ _not_ok GF@semantic string@not_sharp\n");
    
    // Check comparison of null with int (0)
    list_add(l, "JUMPIFNEQ _null_int2 GF@type1 string@int\n");
    list_add(l, "JUMPIFEQ _sharp_ GF@tmp1 int@0\n");
    list_add(l, "JUMP _not_sharp_\n");
    list_add(l, "LABEL _null_int2\n");
    list_add(l, "JUMPIFNEQ _null_string GF@type2 string@int\n");
    list_add(l, "JUMPIFEQ _sharp_ GF@tmp2 int@0\n");

    // Check comparison of null with string ("")
    list_add(l, "LABEL _null_string\n");
    list_add(l, "JUMPIFNEQ _null_string2 GF@type1 string@string\n");
    list_add(l, "JUMPIFEQ _sharp_ GF@tmp1 string@\n");
    list_add(l, "JUMP _not_sharp_\n");
    list_add(l, "LABEL _null_string2\n");
    list_add(l, "JUMPIFNEQ _null_float GF@type2 string@string\n");
    list_add(l, "JUMPIFEQ _sharp_ GF@tmp2 string@\n");

    // Check comparison of null with float (0.0)
    list_add(l, "LABEL _null_float\n");
    list_add(l, "JUMPIFNEQ _null_float2 GF@type1 string@float\n");
    list_add(l, "JUMPIFEQ _sharp_ GF@tmp1 float@0x0.0p+0\n");
    list_add(l, "JUMP _not_sharp_\n");
    list_add(l, "LABEL _null_float2\n");
    list_add(l, "JUMPIFNEQ _not_sharp GF@type2 string@float\n");
    list_add(l, "JUMPIFEQ _sharp_ GF@tmp2 float@0x0.0p+0\n");

    list_add(l, "LABEL _not_sharp_\n");
    list_add(l, "PUSHS bool@true\n"); //true
    list_add(l, "PUSHS bool@false\n");//true\n"); //
    list_add(l, "RETURN\n");

    list_add(l, "LABEL _sharp_\n");
    list_add(l, "PUSHS bool@true\n");
    list_add(l, "PUSHS bool@true\n"); //was true
    list_add(l, "RETURN\n");

    // Implicit conversion not available
    list_add(l, "LABEL _not_ok\n");
    list_add(l, "EXIT int@7\n");
    
    // Operands are (now) of same types
    list_add(l, "LABEL _same_type\n");
    list_add(l, "JUMPIFEQ _type_check_ok GF@semantic string@comparison\n");//
    list_add(l, "JUMPIFNEQ _no_null GF@type1 string@nil\n");
    list_add(l, "JUMPIFNEQ _no_null GF@semantic string@not_sharp\n");
    list_add(l, "JUMP _sharp_\n");
    list_add(l, "LABEL _no_null\n");
									   
    list_add(l, "JUMPIFEQ _type_check_ok GF@semantic string@sharp\n");//
    list_add(l, "JUMPIFEQ _type_check_ok GF@semantic string@not_sharp\n");//
    list_add(l, "JUMPIFEQ _not_ok GF@type1 string@string\n");
    list_add(l, "JUMPIFEQ _not_ok GF@type1 string@bool\n");
    
    // In case od division, both operands must be floats
    list_add(l, "JUMPIFEQ _type_check_ok GF@type1 string@float\n");
    list_add(l, "JUMPIFEQ _type_check_ok GF@semantic string@arithmetic\n");
    list_add(l, "INT2FLOAT GF@tmp1 GF@tmp1\n");
    list_add(l, "INT2FLOAT GF@tmp2 GF@tmp2\n");
    
    // Control (and implicit conversion) was successful
    list_add(l, "LABEL _type_check_ok\n");
    list_add(l, "PUSHS GF@tmp2\n");
    list_add(l, "PUSHS GF@tmp1\n");
    list_add(l, "RETURN\n");
    list_add(l, "LABEL _artihmetic_semantic_end\n");
}

void call_sharp_condition(list_t *l){
    list_add(l, "MOVE GF@semantic string@sharp\n");
    list_add(l, "CALL _arithmetic_semantic\n");
}

void call_not_sharp_condition(list_t *l){
    list_add(l, "MOVE GF@semantic string@not_sharp\n");
    list_add(l, "CALL _arithmetic_semantic\n");
}

/** 
 * Checks validity of conditions
 * @param l List of instructions
 */ 
void generate_condition_type(list_t *l){
    list_add(l, "JUMP _condition_type_end\n");
    list_add(l, "LABEL _condition_type\n");
    list_add(l, "POPS GF@tmp1\n");
    list_add(l, "TYPE GF@type1 GF@tmp1\n");
    list_add(l, "PUSHS GF@tmp1\n");
    list_add(l, "JUMPIFEQ _condition_ok GF@type1 string@bool\n");
    list_add(l, "JUMPIFEQ _condition_int GF@type1 string@int\n");
    list_add(l, "JUMPIFEQ _condition_float GF@type1 string@float\n");
    list_add(l, "JUMPIFEQ _condition_null GF@type1 string@\n");
    list_add(l, "LABEL _condition_string\n");
    list_add(l, "PUSHS string@\n");
    list_add(l, "EQS\n");
    list_add(l, "PUSHS string@0\n");
    list_add(l, "PUSHS GF@tmp1\n");
    list_add(l, "EQS\n");
    list_add(l, "ORS\n");
    list_add(l, "PUSHS bool@false\n");
    list_add(l, "RETURN\n");
    list_add(l, "LABEL _condition_null\n");
    list_add(l, "PUSHS nil@nil\n");
    list_add(l, "JUMP _condition_end\n");

    list_add(l, "LABEL _condition_int\n");
    list_add(l, "PUSHS int@0\n");
    list_add(l, "JUMP _condition_end\n");

    list_add(l, "LABEL _condition_float\n");
    list_add(l, "PUSHS float@0x0.0p+0\n");
    list_add(l, "JUMP _condition_end\n");

    list_add(l, "LABEL _condition_end\n");
    list_add(l, "EQS\n");
    list_add(l, "PUSHS bool@false\n");
    list_add(l, "RETURN\n");

    list_add(l, "LABEL _condition_ok\n");
    list_add(l, "PUSHS bool@true\n");
    list_add(l, "RETURN\n");
    list_add(l, "LABEL _condition_type_end\n");
}

/**
 * Calls condition check
 * @param l List of conditions
 */
void call_condition_type(list_t *l){
    list_add(l, "CALL _condition_type\n");
}

/**
 * Used for exiting with error 4
 * @param l List of instructions
 */
void generate_wrong_param_type(list_t *l){
    list_add(l, "LABEL _wrong_param_type\n");
    list_add(l, "EXIT int@4\n");
}

/**
 * Used for exiting with error 6 
 * @param l List of instructions
 */
void generate_incorrect_return(list_t *l){
    list_add(l, "LABEL _incorrect_return\n");
    list_add(l, "EXIT int@6\n");
}

/** 
 * Generates === and !== conditions, implicit conversions included
 * @param l List of instructions
 */
void generate_not_equals(list_t *l){
    list_add(l, "LABEL _eq_or_neq\n");
    list_add(l, "POPS GF@tmp1\n");
    list_add(l, "POPS GF@tmp2\n");
    list_add(l, "LABEL _equals_compare\n");
    list_add(l, "TYPE GF@type1 GF@tmp1\n");
    list_add(l, "TYPE GF@type2 GF@tmp2\n");

    list_add(l, "JUMPIFEQ _equals_same_type GF@type1 GF@type2\n");
    list_add(l, "JUMPIFNEQ _equals_diff_type GF@type1 GF@type2\n");
    list_add(l, "LABEL _equals_first_int\n");
    list_add(l, "INT2FLOAT GF@tmp1 GF@tmp1\n");
    list_add(l, "JUMP _equals_compare\n");
    list_add(l, "LABEL _equals_second_int\n");
    list_add(l, "INT2FLOAT GF@tmp2 GF@tmp2\n");
    list_add(l, "JUMP _equals_compare\n");
    list_add(l, "LABEL _equals_same_type\n");
    list_add(l, "PUSHS GF@tmp2\n");
    list_add(l, "PUSHS GF@tmp1\n");
    list_add(l, "EQS\n");
    list_add(l, "JUMPIFNEQ _not_equal GF@semantic string@equal\n");
    list_add(l, "RETURN\n");
    list_add(l, "LABEL _not_equal\n");
    list_add(l, "NOTS\n");
    list_add(l, "RETURN\n");
    list_add(l, "LABEL _equals_diff_type\n");
    list_add(l, "JUMPIFEQ _equal_final GF@semantic string@equal\n");
    list_add(l, "PUSHS bool@true\n");
    list_add(l, "RETURN\n");
    list_add(l, "LABEL _equal_final\n");
    list_add(l, "PUSHS bool@false\n");
    list_add(l, "RETURN\n");
}

/**
 * Calls === condition's code generation
 * @param l List of instructions
 */
void call_equals(list_t *l){
    list_add(l, "MOVE GF@semantic string@equal\n");
    list_add(l, "CALL _eq_or_neq\n");
}

/**
 * Calls !== conditions's code generation
 * @param l List of instructions
 */
void call_not_equals(list_t *l){
    list_add(l, "MOVE GF@semantic string@not_equal\n");
    list_add(l, "CALL _eq_or_neq\n");
}

/** 
 * Code for builtin function intval
 * @param l List of instructions
 */
void generate_intval(list_t *l){
    list_add(l, "LABEL _intval\n");
    list_add(l, "POPS GF@tmp1\n");
    list_add(l, "TYPE GF@type1 GF@tmp1\n");
    list_add(l, "JUMPIFEQ _intval_float GF@type1 string@float\n");
    list_add(l, "JUMPIFEQ _intval_int GF@type1 string@int\n");
    list_add(l, "JUMPIFEQ _intval_null GF@type1 string@nil\n");
    list_add(l, "JUMP _wrong_param_type\n");
    list_add(l, "LABEL _intval_float\n");
    list_add(l, "FLOAT2INT GF@tmp1 GF@tmp1\n");
    list_add(l, "LABEL _intval_int\n");
    list_add(l, "PUSHS GF@tmp1\n");
    list_add(l, "RETURN\n");
    list_add(l, "LABEL _intval_null\n");
    list_add(l, "PUSHS int@0\n");
    list_add(l, "RETURN\n");
}

/** 
 * Code for builtin function floatval
 * @param l List of instructions
 */
void generate_floatval(list_t *l){
    list_add(l, "LABEL _floatval\n");
    list_add(l, "POPS GF@tmp1\n");
    list_add(l, "TYPE GF@type1 GF@tmp1\n");
    list_add(l, "JUMPIFEQ _floatval_int GF@type1 string@int\n");
    list_add(l, "JUMPIFEQ _floatval_float GF@type1 string@float\n");
    list_add(l, "JUMPIFEQ _floatval_null GF@type1 string@nil\n");
    list_add(l, "JUMP _wrong_param_type\n");
    list_add(l, "LABEL _floatval_int\n");
    list_add(l, "INT2FLOAT GF@tmp1 GF@tmp1\n");
    list_add(l, "LABEL _floatval_float\n");
    list_add(l, "PUSHS GF@tmp1\n");
    list_add(l, "RETURN\n");
    list_add(l, "LABEL _floatval_null\n");
    list_add(l, "PUSHS float@0x0.0p+0\n");
    list_add(l, "RETURN\n");
}

/** 
 * Code for builtin function strval
 * @param l List of instructions
 */
void generate_strval(list_t *l){
    list_add(l, "LABEL _strval\n");
    list_add(l, "POPS GF@tmp1\n");
    list_add(l, "TYPE GF@type1 GF@tmp1\n");
    list_add(l, "JUMPIFEQ _strval_null GF@type1 string@nil\n");
    list_add(l, "JUMPIFEQ _strval_string GF@type1 string@string\n");
    list_add(l, "JUMP _wrong_param_type\n");
    list_add(l, "LABEL _strval_null\n");
    list_add(l, "PUSHS string@\n");
    list_add(l, "RETURN\n");
    list_add(l, "LABEL _strval_string\n");
    list_add(l, "PUSHS GF@tmp1\n");
    list_add(l, "RETURN\n");
}

/** 
 * Code for builtin function strlen
 * @param l List of instructions
 */
void generate_strlen(list_t *l){
    list_add(l, "LABEL _strlen\n");
    list_add(l, "POPS GF@tmp1\n");
    list_add(l, "TYPE GF@type1 GF@tmp1\n");
    list_add(l, "JUMPIFEQ _strlen_null GF@type1 string@nil\n");
    list_add(l, "JUMPIFEQ _strlen_string GF@type1 string@string\n");
    list_add(l, "JUMP _wrong_param_type\n");
    list_add(l, "LABEL _strlen_null\n");
    list_add(l, "PUSHS int@0\n");
    list_add(l, "RETURN\n");
    list_add(l, "LABEL _strlen_string\n");
    list_add(l, "STRLEN GF@tmp2 GF@tmp1\n");
    list_add(l, "PUSHS GF@tmp2\n");
    list_add(l, "RETURN\n");
}

/** 
 * Code for builtin function ord
 * @param l List of instructions
 */
void generate_ord(list_t *l){
    list_add(l, "LABEL _ord\n");
    list_add(l, "POPS GF@tmp1\n");
    list_add(l, "TYPE GF@type1 GF@tmp1\n");
    list_add(l, "JUMPIFEQ _ord_null GF@type1 string@nil\n");
    list_add(l, "JUMPIFEQ _ord_string GF@type1 string@string\n");
    list_add(l, "JUMP _wrong_param_type\n");
    list_add(l, "LABEL _ord_null\n");
    list_add(l, "PUSHS int@0\n");
    list_add(l, "RETURN\n");
    list_add(l, "LABEL _ord_string\n");
    list_add(l, "JUMPIFEQ _ord_null GF@tmp1 string@\n");
    list_add(l, "STRI2INT GF@tmp2 GF@tmp1 int@0\n");
    list_add(l, "PUSHS GF@tmp2\n");
    list_add(l, "RETURN\n");
}

/**
 * Code for builtin function chr
 * @param l List of instructions
 */
void generate_chr(list_t *l){
    list_add(l, "LABEL _chr\n");
    list_add(l, "POPS GF@tmp1\n");
    list_add(l, "TYPE GF@type1 GF@tmp1\n");
    list_add(l, "JUMPIFEQ _chr_int GF@type1 string@int\n"); 
    list_add(l, "JUMP _wrong_param_type\n");
    list_add(l, "LABEL _chr_int\n");
    list_add(l, "INT2CHAR GF@tmp2 GF@tmp1\n");
    list_add(l, "PUSHS GF@tmp2\n");
    list_add(l, "RETURN\n");
}


/**
 * Code for builtin function substring
 * @param l List of instructions 
 */
void generate_substring(list_t *l){
    list_add(l, "LABEL _substring\n");
    list_add(l, "CREATEFRAME\n");
    list_add(l, "PUSHFRAME\n");
    list_add(l, "DEFVAR LF@end_index\n");
    list_add(l, "DEFVAR LF@start_index\n");
    list_add(l, "DEFVAR LF@orig_string\n");
    list_add(l, "POPS LF@end_index\n");
    list_add(l, "POPS LF@start_index\n"); 
    list_add(l, "POPS LF@orig_string\n"); 
    list_add(l, "STRLEN GF@tmp1 LF@orig_string\n");
    list_add(l, "LT GF@tmp3 GF@tmp1 LF@start_index\n");
    list_add(l, "JUMPIFEQ _end_fail GF@tmp3 bool@true\n");

    // Argument controls
    list_add(l, "EQ GF@tmp3 GF@tmp1 LF@start_index\n");
    list_add(l, "JUMPIFEQ _end_fail GF@tmp3 bool@true\n");

    list_add(l, "LT GF@tmp3 GF@tmp1 LF@end_index\n");
    list_add(l, "JUMPIFEQ _end_fail GF@tmp3 bool@true\n");

    list_add(l, "GT GF@tmp3 LF@start_index LF@end_index\n");
    list_add(l, "JUMPIFEQ _end_fail GF@tmp3 bool@true\n");

    list_add(l, "LT GF@tmp3 LF@start_index int@0\n");
    list_add(l, "JUMPIFEQ _end_fail GF@tmp3 bool@true\n");

    list_add(l, "LT GF@tmp3 LF@end_index int@0\n");
    list_add(l, "JUMPIFEQ _end_fail GF@tmp3 bool@true\n");

    // Function
    list_add(l, "MOVE GF@tmp2 LF@orig_string\n");
    list_add(l, "MOVE GF@tmp1 LF@start_index\n");

    list_add(l, "MOVE GF@tmp3 string@\n");
    list_add(l, "JUMPIFNEQ _substring_loop GF@tmp1 LF@end_index\n");
    list_add(l, "JUMP _substring_return\n");

    list_add(l, "LABEL _substring_loop\n");
    list_add(l, "GETCHAR GF@tmp2 LF@orig_string GF@tmp1\n");
    list_add(l, "CONCAT GF@tmp3 GF@tmp3 GF@tmp2\n");
    list_add(l, "ADD GF@tmp1 GF@tmp1 int@1\n");
    list_add(l, "JUMPIFNEQ _substring_loop GF@tmp1 LF@end_index\n");
    list_add(l, "JUMP _substring_return\n");

    list_add(l, "LABEL _end_fail\n");
    list_add(l, "PUSHS nil@nil\n");
    list_add(l, "POPFRAME\n");
    list_add(l, "RETURN\n");

    list_add(l, "LABEL _substring_return\n");
    list_add(l, "PUSHS GF@tmp3\n");
    list_add(l, "POPFRAME\n");
    list_add(l, "RETURN\n");
}


/**
 * Generates code for semantic controls and builtin functions
 * @param l List of instructions
 */
void generate_start(list_t *l){
    list_add(l, ".IFJcode22\n");
    list_add(l, "CREATEFRAME\n");
    list_add(l, "PUSHFRAME \n");
    generate_tmp_variables(l);
    list_add(l, "JUMP _predefined_functions_skip\n");
    generate_wrong_param_type(l);
    generate_incorrect_return(l);
    generate_arithmetic_semantic(l);
    generate_undefined_variable(l);
    generate_condition_type(l);
    generate_not_equals(l);
    generate_intval(l);
    generate_floatval(l);
    generate_strval(l);
    generate_strlen(l);
    generate_ord(l);
    generate_chr(l);
    generate_substring(l);
    list_add(l, "LABEL _predefined_functions_skip\n");
}

/**
 * Calls a semantic control (and implicit conversions) for addition, multiplication and substraction
 * @param l List of instruction
 */
void call_arithmetic_semantic(list_t *l){
    list_add(l, "MOVE GF@semantic string@arithmetic\n");
    list_add(l, "CALL _arithmetic_semantic\n");
}

/**
 * Calls a semantic control and int-to-float conversion for division
 * @param l List of instructions
 */
void call_divide_semantic(list_t *l){
    list_add(l, "MOVE GF@semantic string@divide\n");
    list_add(l, "CALL _arithmetic_semantic\n");
}

/**
 * Calls semantic controls for comparisons
 * @param l List of instructions
 */
void call_comparison_semantic(list_t *l){
    list_add(l, "MOVE GF@semantic string@comparison\n");
    list_add(l, "CALL _arithmetic_semantic\n");
}

/**
 * Generates the end of the whole program
 * @param l List of instructions
 */ 
void generate_end(list_t *l){
    list_add(l, "POPFRAME\n");
}

/* CODE CITATION
 * StackOverflow question https://stackoverflow.com/questions/779875/what-function-is-to-replace-a-substring-from-a-string-in-c
 * answered here https://stackoverflow.com/a/779960,  Apr 23, 2009 at 1:28 by jmucchiello
 * You must free the result if result is non-NULL. */
char *str_replace(char *orig, char *rep, char *with) {
    char *result; // the return string
    char *ins;    // the next insert point
    char *tmp;    // varies
    int len_rep;  // length of rep (the string to remove)
    int len_with; // length of with (the string to replace rep with)
    int len_front; // distance between rep and end of last rep
    int count;    // number of replacements

    // sanity checks and initialization
    if (!orig || !rep)
        return NULL;
    len_rep = strlen(rep);
    if (len_rep == 0)
        return NULL; // empty rep causes infinite loop during count
    if (!with)
        with = "";
    len_with = strlen(with);

    // count the number of replacements needed
    ins = orig;
    for (count = 0; tmp = strstr(ins, rep); ++count) {
        ins = tmp + len_rep;
    }

    tmp = result = malloc(strlen(orig) + (len_with - len_rep) * count + 1);

    if (!result)
        return NULL;

    // first time through the loop, all the variable are set correctly
    // from here on,
    //    tmp points to the end of the result string
    //    ins points to the next occurrence of rep in orig
    //    orig points to the remainder of orig after "end of rep"
    while (count--) {
        ins = strstr(orig, rep);
        len_front = ins - orig;
        tmp = strncpy(tmp, orig, len_front) + len_front;
        tmp = strcpy(tmp, with) + len_with;
        orig += len_front + len_rep; // move to next "end of rep"
    }
    strcpy(tmp, orig);
    return result;
}
/* END OF CITATION */

// Hex alpha convertion to dec number
int alpha_to_num(char c) {
    switch(c) {
        case 'a': case 'A':
            return 10;
        case 'b': case 'B':
            return 11;
        case 'c': case 'C':
            return 12;
        case 'd': case 'D':
            return 13;
        case 'e': case 'E':
            return 14;
        case 'f': case 'F':
            return 15;
        default:
            break;
    }
    return 16;
}

char *hex_to_char(char *str) {
    int len = strlen(str);

    int num = 0;
    int num1 = 0;
    int num0 = 0;

    for (int i = 0; i < len - 3; i++) {
        if (str[i] == '\\' && (str[i + 1] == 'x')) {
            if (isdigit(str[i + 2])) {
                num1 = str[i + 2] - '0';
            } else {
                num1 = alpha_to_num(str[i + 2]);
                if (num1 == 16)
                    error_handle(LEXEME_ERROR, 0);
            }
            
            if (isdigit(str[i + 3])) {
                num0 = str[i + 3] - '0';
            } else {
                num0 = alpha_to_num(str[i + 3]);
                if (num0 == 16)
                    error_handle(LEXEME_ERROR, 0);
            }

            num = num1 * 16 + num0 * 1;
            if (!(num > 1 && num < 255))
                    error_handle(LEXEME_ERROR, 0);
            str[i] = (char)num;
            for (int j = 1; i + j <= len - 3; j++)
                str[i + j] = str[i + j + 3];

            len -= 3;
        }
    }
    return str;
}

char *oct_to_char(char *str) {
    int len = strlen(str);

    int num = 0;
    int num2 = 0;
    int num1 = 0;
    int num0 = 0;

    for (int i = 0; i < len - 3; i++) {
        if (str[i] == '\\' && isdigit(str[i + 1])) {
            num2 = str[i + 1] - '0';
            num1 = str[i + 2] - '0';
            num0 = str[i + 3] - '0';
            num = num2 * 64 + num1 * 8 + num0 * 1; 
            if (!(num > 1 && num < 255))
                    error_handle(LEXEME_ERROR, 0);

            str[i] = (char)num;
            for (int j = 1; i + j <= len - 3; j++)
                str[i + j] = str[i + j + 3];

            len -= 3;
        }
    }
    return str;
}

/** 
 * Removes unprintable characters from a loaded string and replaces them with escape sequences
 * @param token_string String saved in a token sent by scanner
 * @return Printable string
 */
char *convert_string(char *token_string){
    int orig_len = strlen(token_string);
    char *new_string = malloc(orig_len);  
    strcpy(new_string, (token_string+1)); //Gets rid of first quotation mark
    new_string[orig_len-2] = '\0'; // Index before final \0

    new_string = oct_to_char(new_string); //change oct numbers
    new_string = hex_to_char(new_string); //change hex numbers

    char *result = new_string;
    //TODO add other unwanted or try automalising it
    char *unwanted[] = {" ", "\\n", "$", "\t", "\\t", "\"", "\\\\"};
    char *replacement[] = {"\\032", "\\010", "036", "\\009", "\\009", "034", "\\092"};
    int num_of_unwanted = 7;
    for (int i = 0; i < num_of_unwanted; i++){
        result = str_replace(new_string, unwanted[i], replacement[i]);
        free(new_string);
        new_string = result;
    }
    return new_string;
}

//TODO write() without args
/**
 * Generates code for builtin function write based on argument type
 * @param tree Function call with its arguments
 * @param l List of instructions
 */
void generate_write(stree_t tree, list_t *l){
    node_t *current_child = tree->first_child;
    char *result;
    while (current_child != NULL){
        switch (current_child->type){
	    case N_INT_VAL: 
            	list_add(l, "WRITE int@%d\n", current_child->data.int_value);
	    	break;
	    case N_STR_VAL:
		result = convert_string(current_child->data.string_value);
	    	list_add(l, "WRITE string@%s\n", result);
		free(result);
	    	break;
	    case N_FLOAT_VAL:
	        list_add(l, "WRITE float@%a\n", current_child->data.double_value);
	    	break;
	    case N_VARIABLE:
        generate_variable_definition(l, current_child->data.operand->id);
		list_add(l, "WRITE LF@%s\n", current_child->data.operand->id);
		break;
        }
        current_child = current_child->next_sibling;
    }
}

/* Functions for calling builtin function read */
void generate_readi(stree_t tree, list_t *l){
    list_add(l, "READ LF@%s int\n", tree->first_child->data.operand->id);
} 

void generate_reads(stree_t tree, list_t *l){
    list_add(l, "READ LF@%s string\n", tree->first_child->data.operand->id);
}

void generate_readf(stree_t tree, list_t *l){
    list_add(l, "READ LF@%s float\n", tree->first_child->data.operand->id);
}

/**
 * Pushes a term to stack
 * @param n Term to be pushed
 * @param l List of instructions
 */
void generate_push(node_t *n, list_t *l){
    char *result;
    switch(n->type){
	case N_INT_VAL:
	    list_add(l, "PUSHS int@%d\n", n->data.int_value);
	    break;
	case N_STR_VAL:
	    result = convert_string(n->data.string_value);
	    list_add(l, "PUSHS string@%s\n", result);
	    free(result);
	    break;
	case N_FLOAT_VAL:
	    list_add(l, "PUSHS float@%a\n", n->data.double_value);
	    break;
	case N_VARIABLE:
        generate_variable_definition(l, n->data.operand->id);
	    list_add(l, "PUSHS LF@%s\n", n->data.operand->id);
	    break;
	case N_NULL_VAL:
	    list_add(l, "PUSHS nil@nil\n");
	    break;
    }
}

//TODO check number of params
/** 
 * Calls builtin function intval with its argument
 * @param tree Fuction call with its argument
 * @param l List of instructions
 */
void call_intval(stree_t tree, list_t *l){
    generate_push(tree->first_child, l);
    list_add(l, "CALL _intval\n");
}

/** 
 * Calls builtin function floatval with its argument
 * @param tree Fuction call with its argument
 * @param l List of instructions
 */
void call_floatval(stree_t tree, list_t *l){
    generate_push(tree->first_child, l);
    list_add(l, "CALL _floatval\n");
}

/** 
 * Calls builtin function strval with its argument
 * @param tree Fuction call with its argument
 * @param l List of instructions
 */
void call_strval(stree_t tree, list_t *l){
    generate_push(tree->first_child, l);
    list_add(l, "CALL _strval\n");
}

/** 
 * Calls builtin function strlen with its argument
 * @param tree Fuction call with its argument
 * @param l List of instructions
 */
void call_strlen(stree_t tree, list_t *l){
    generate_push(tree->first_child, l);
    list_add(l, "CALL _strlen\n");
}

/** 
 * Calls builtin function ord with its argument
 * @param tree Fuction call with its argument
 * @param l List of instructions
 */
void call_ord(stree_t tree, list_t *l){
    generate_push(tree->first_child, l);
    list_add(l, "CALL _ord\n");
}

/** 
 * Calls builtin function chr with its argument
 * @param tree Fuction call with its argument
 * @param l List of instructions
 */
void call_chr(stree_t tree, list_t *l){
    generate_push(tree->first_child, l);
    list_add(l, "CALL _chr\n");
}

/**
 * Calls builtin function substring
 * Pushes arguments to stack and checks their count
 * @param tree Function call's subtree
 * @param l List of instructions
 */
void call_substring(stree_t tree, list_t *l){
    node_t *current_arg = tree->first_child;
    int exp_arg_count = 3;
    for (int i = 0; i < exp_arg_count; i++){
	if (current_arg != NULL){
	   generate_push(current_arg, l);
	}
	else {
        list_free(*l);
        stree_dispose(&tree);
	    error_handle(PARAM_OR_RET_ERROR, 0);
	}
	current_arg = current_arg->next_sibling;
    }
    if (current_arg != NULL){
        list_free(*l);
        stree_dispose(&tree);
	    error_handle(PARAM_OR_RET_ERROR, 0);
    }
    list_add(l, "CALL _substring\n");
}

void generate_arithmetic(stree_t tree, list_t *l);

void generate_func_call(stree_t tree, list_t *l);

/**
 * Assigns a function return value or an expression to a variable
 * @param tree Assignment subtree
 * @param l List of instructions
 */
void generate_assign(stree_t tree, list_t *l){
    const char *var_name = tree->first_child->data.operand->id;
    if (tree->first_child->defvar == true){
	 list_add(l, "DEFVAR LF@%s\n", var_name);
    }
    node_t *right_side = tree->first_child->next_sibling;
    switch (right_side->type){
	case N_FUNC_CALL:
	    if (!strcmp(right_side->data.function->id, "readi")){
	        generate_readi(tree, l);
	    }
	    else if (!strcmp(right_side->data.function->id, "reads")){
	        generate_reads(tree, l);
	    }
            else if (!strcmp(right_side->data.function->id, "readf")){
	        generate_readf(tree, l);
	    }
	    else if (!strcmp(right_side->data.function->id, "floatval")){
		call_floatval(right_side, l);
		list_add(l, "POPS LF@%s\n", var_name);
	    }
	    else if (!strcmp(right_side->data.function->id, "intval")){
		call_intval(right_side, l);
		list_add(l, "POPS LF@%s\n", var_name);
	    }
	    else if (!strcmp(right_side->data.function->id, "strval")){
	        call_strval(right_side, l);
		list_add(l, "POPS LF@%s\n", var_name);
	    }
	    else if (!strcmp(right_side->data.function->id, "strlen")){
		call_strlen(right_side, l);
		list_add(l, "POPS LF@%s\n", var_name);
	    }
	    else if (!strcmp(right_side->data.function->id, "ord")){
		call_ord(right_side, l);
		list_add(l, "POPS LF@%s\n", var_name);
	    }
	    else if (!strcmp(right_side->data.function->id, "chr")){
		call_chr(right_side, l);
		list_add(l, "POPS LF@%s\n", var_name);
	    }
	    else if (!strcmp(right_side->data.function->id, "substring")){
		call_substring(right_side, l);
		list_add(l, "POPS LF@%s\n", var_name);
	    }
	    else {
		generate_func_call(right_side, l);
		list_add(l, "POPS LF@%s\n", var_name);
	    }
      break;
	case N_INT_VAL: case N_VARIABLE: case N_STR_VAL: case N_FLOAT_VAL: case N_NULL_VAL:
	case N_ADD: case N_SUB: case N_MUL: case N_DIV: case N_CONC: //
	    foreach(right_side, generate_arithmetic, l);
	    list_add(l, "POPS LF@%s\n", var_name);
            break;
    }
}

/**
 * Generates code for an expression and pushes the result to stack
 * @param tree Expression subtree
 * @param l List of instructions
 */
void generate_arithmetic(stree_t tree, list_t *l){
    char *stack_operations[] = {[N_ADD] = "ADDS", [N_SUB] = "SUBS", [N_MUL] = "MULS", [N_DIV]="DIVS",
	    [N_GR] = "GTS", [N_LS] = "LTS", [N_EQUAL] = "EQS", [N_LE] = "ANDS", [N_GE] = "ORS", [N_NOT_EQUAL] = "NOTS"}; 
    switch(tree->type){
        case N_ADD: case N_SUB: case N_MUL:
	    call_arithmetic_semantic(l);	
            list_add(l, "%s\n", stack_operations[tree->type]);
	    break;
	case N_CONC:
	    list_add(l, "POPS GF@tmp2\n");
	    list_add(l, "POPS GF@tmp1\n");
	    list_add(l, "CONCAT GF@tmp3 GF@tmp1 GF@tmp2\n");
	    list_add(l, "PUSHS GF@tmp3\n");
	    break;
	case N_DIV:
	    call_divide_semantic(l);
	    list_add(l, "%s\n", stack_operations[tree->type]);
	    break;
	case N_EQUAL:
	    call_equals(l);
	    break;
	case N_NOT_EQUAL: 
	    call_not_equals(l);
	    break;
	case N_GR:
	    call_sharp_condition(l);
	    list_add(l, "%s\n", stack_operations[tree->type]);
	    break;
	case N_LS:
	    call_sharp_condition(l);
	    list_add(l, "%s\n", stack_operations[tree->type]);
	    break;
	case N_GE:
	    call_not_sharp_condition(l);
	    list_add(l, "LTS\n");
	    list_add(l, "NOTS\n");
	    break;
	case N_LE:
	    call_not_sharp_condition(l);
	    list_add(l, "GTS\n");
	    list_add(l, "NOTS\n");
	    break;
        case N_STR_VAL: case N_INT_VAL: case N_FLOAT_VAL: case N_VARIABLE: case N_NULL_VAL:
            generate_push(tree, l);
	    break;
    }
}

/**
 * Evaluates condition including a single term
 * @param tree Condition
 * @param l List of instructions
 */
void one_member_condition(stree_t tree, list_t *l){
   switch(tree->type){
	case N_INT_VAL:
	    list_add(l, "PUSHS int@0\n");
	    break;
	case N_STR_VAL:
	    if (!strcmp(tree->data.string_value,"\"0\"")){
	        list_add(l, "PUSHS string@0\n");
	    }
            else {
	   	 list_add(l, "PUSHS string@\n"); 
	    }
	    break;
	case N_FLOAT_VAL:
	    list_add(l, "PUSHS float@%a\n", 0.0);
	    break;
	case N_NULL_VAL:
	    list_add(l, "PUSHS nil@nil\n"); 
	    break;
	}
}

/**
 * Generates code for a condition
 * @param tree Node pointer to first elements of the condition
 * @param l List of instructions
 */
void generate_condition(stree_t tree, list_t *l){
    if (tree->first_child == NULL && tree->type != N_VARIABLE){
	generate_push(tree, l);
	one_member_condition(tree, l);
	list_add(l, "EQS\n");
	list_add(l, "PUSHS bool@false\n");
    }
    else {
	foreach(tree, generate_arithmetic, l);
	call_condition_type(l);
    }
}

/**
 * Generates structure for if-else blocks, then calls generate_statements back
 * @param tree If-else subtree
 * @param l List of instructions
 * @param counter Label number
 * @param in-function True if if-else block is nested in a function definition
 */
void generate_if_else(stree_t tree, list_t *l, int counter, bool in_function){
    list_add(l, "LABEL _if%d\n", counter);
    generate_condition(tree->first_child->first_child->next_sibling, l);
    list_add(l, "JUMPIFNEQS _else%d\n", counter); 
    generate_statements(tree->first_child->next_sibling->first_child, l, in_function);
    list_add(l, "JUMP _else%d_skip\n", counter);
    list_add(l, "LABEL _else%d\n", counter);
    if (tree->next_sibling != NULL){
        generate_statements(tree->next_sibling->first_child->first_child, l, in_function);
    }
    list_add(l, "LABEL _else%d_skip\n", counter);
}

/**
 * Generates structure for while blocks, then calls generate_statements back
 * @param tree While subtree
 * @param l List of instructions
 * @param counter Label number
 * @param in-function True if if-else block is nested in a function definition
 */
void generate_while(stree_t tree, list_t *l, int counter, bool in_function){
    list_add(l, "LABEL while%d_start\n", counter);
    generate_condition(tree->first_child->first_child->next_sibling, l);
    list_add(l, "JUMPIFNEQS while%d_end\n", counter);
    generate_statements(tree->first_child->next_sibling->first_child, l, in_function);
    list_add(l, "JUMP while%d_start\n", counter);
    list_add(l, "LABEL while%d_end\n", counter);
}

/**
 * Semantic control for function arguments
 * @param l List of instructions
 * @param param_count Index of a given argument
 * @param param_type Expected argument type
 */
void call_check_param(list_t *l, int param_count, id_type param_type){
    list_add(l, "TYPE GF@type1 TF@%%%d\n", param_count);
    switch(param_type){
        case H_INT_ID:
	    list_add(l, "JUMPIFNEQ _wrong_param_type GF@type1 string@int\n");
	    break;
	case H_FLOAT_ID: 
	    list_add(l, "JUMPIFNEQ _wrong_param_type GF@type1 string@float\n");
	    break;
	case H_STRING_ID:
	    list_add(l, "JUMPIFNEQ _wrong_param_type GF@type1 string@string\n");
	    break;
    }		
    
}


/**
 * Semantic control for variable definition
 * 
 * @param l List of instructions
 */
void generate_variable_definition(list_t *l, const char *variable_name){
    list_add(l, "TYPE GF@type1 LF@%s\n", variable_name);
    list_add(l, "JUMPIFEQ _var_not_defined GF@type1 string@\n");
}
void generate_undefined_variable(list_t *l){
    list_add(l, "LABEL _var_not_defined\n");
    list_add(l, "EXIT int@5\n");
}

/**
 * Generates code for a call of a user-defined function
 * Moves arguments to a temporary frame and checks their validity
 * @param tree Function call subtree
 * @param l List of instructions
 */
void generate_func_call(stree_t tree, list_t *l){
    list_add(l, "CREATEFRAME\n");
    node_t *param = tree->first_child;
    params_t *param_list = tree->data.function->params;
    int param_count = 0;
    while((param != NULL) && (param_list != NULL)){
	param_count++;
	generate_push(param, l); 	
	list_add(l, "DEFVAR TF@%%%d\n", param_count);
	list_add(l, "POPS TF@%%%d\n", param_count);

	call_check_param(l, param_count, param_list->param);

	param = param->next_sibling;
	param_list = param_list->next_param;
    }
    if ((param != NULL) || (param_list != NULL)){
	list_add(l, "JUMP _wrong_param_type\n");
    }
    list_add(l, "CALL func_%s\n", tree->data.function->id);
}

/**
 * Generates first part of a function definition code:
 * prepares return value, then calls generate_statements
 * @param tree Function definition subtree
 * @param l List of instructions
 */
void generate_func_def_head(stree_t tree, list_t *l){
    list_add(l, "JUMP _skip_func_%s\n", tree->data.function->id);
    list_add(l, "LABEL func_%s\n", tree->data.function->id);
    list_add(l, "PUSHFRAME\n");
    list_add(l, "DEFVAR LF@%%retval\n");
    list_add(l, "MOVE LF@%%retval nil@nil\n");
    node_t *param = tree->first_child;
    int param_count = 0;
    while (param != NULL && (param->type == N_INT_P || param->type == N_FLOAT_P || param->type == N_STRING_P)){
	param_count++;
	htab_data_t *param_data = param->first_child->data.operand;
	list_add(l, "DEFVAR LF@%s\n", param_data->id);
	list_add(l, "MOVE LF@%s LF@%%%d\n", param_data->id, param_count);
	param = param->next_sibling;
    }
    generate_statements(tree->first_child, l, true);
}

/**
 * Generates function definition final part: pushes return value to stack
 * @param tree Function definition subtree
 * @param l List of instructions
 */
void generate_func_def_tail(stree_t tree, list_t *l){
    list_add(l, "JUMPIFEQ _wrong_param_type GF@semantic string@not_void_func\n");
    list_add(l, "PUSHS LF@%%retval\n");
    list_add(l, "POPFRAME\n");
    list_add(l, "RETURN\n");
    list_add(l, "LABEL _skip_func_%s\n", tree->data.function->id);
}

/**
 * Checks if a return value is valid and pushes it to stack
 * @param l List of instructions
 * @param return_type Expected return type
 * */
void check_return_type(list_t *l, id_type return_type){
    static int return_label = 1;
    list_add(l, "POPS GF@tmp1\n");
    list_add(l, "TYPE GF@type1 GF@tmp1\n");
    switch(return_type){
	    case H_Q_INT_ID: case H_Q_FLOAT_ID: case H_Q_STRING_ID: 
	    list_add(l, "JUMPIFEQ _return_type_%d_ok GF@type1 string@nil\n", return_label);
	}
    switch(return_type){
	    case H_INT_ID: case H_Q_INT_ID:
	    list_add(l, "JUMPIFNEQ _wrong_param_type GF@type1 string@int\n");
	    break;
	    case H_FLOAT_ID: case H_Q_FLOAT_ID:
	    list_add(l, "JUMPIFNEQ _wrong_param_type GF@type1 string@float\n");
	    break;
	    case H_STRING_ID: case H_Q_STRING_ID:
	    list_add(l, "JUMPIFNEQ _wrong_param_type GF@type1 string@string\n");
    }
    list_add(l, "LABEL _return_type_%d_ok\n", return_label);
    list_add(l, "PUSHS GF@tmp1\n");
    return_label++;
}

/**
 * Generates code and semantic controls for return statements
 * @param tree Return subtree
 * @param l List of instructions
 * @param in_funtion True is return is nested in a function
 * @param this_return_type Function's expected return type
 */
void generate_return_stat(stree_t tree, list_t *l, bool in_function, id_type this_return_type){
   if (in_function){
	node_t* return_val = tree->first_child;
	if (return_val != NULL){
	    if (this_return_type == H_VOID_FUNC){
		list_add(l, "JUMP _incorrect_return\n");
	    }
	    else if (return_val->type == N_UNKNOWN){
		return_val = return_val->next_sibling;
	    }
	    generate_arithmetic(return_val, l);
	    check_return_type(l, this_return_type);
	    list_add(l, "POPFRAME\n");
	    list_add(l, "RETURN\n");
	}
	else {
	    list_add(l, "PUSHS LF@%%retval\n");
	    if (this_return_type != H_VOID_FUNC){
		list_add(l, "JUMP _incorrect_return\n");
	    }
	    list_add(l, "POPFRAME\n");
	    list_add(l, "RETURN\n");
	}
    }
    else {
	list_add(l, "EXIT int@0\n");
    }
}

/**
 * Main function for code generation. Gets a (sub)tree pointer, selects statement type.
 * Is recursively called for statements execution
 * @param tree AST or its subtree
 * @param l List of instruction
 * @param in-function True if statements-to-be-generated are located in a function definition
 */
void generate_statements(stree_t tree, list_t *l, bool in_function){
    static id_type this_return_type = H_UNKNOWN_ID;
    static int label_counter = 0;
    if (tree == NULL){
	return;
    }
    else if (tree->type == N_ROOT){
	tree = tree->first_child;
    }
    switch(tree->type){
	case N_FUNC_CALL:
	    if (!strcmp(tree->data.function->id, "write")){ //move together withother functions
	        generate_write(tree, l);
	    }
	    else {
		generate_func_call(tree, l);
	    }
	    break;
	case N_FUNC_DEF:
	    this_return_type = tree->data.function->return_type;
	    generate_func_def_head(tree, l);
	    if (this_return_type != H_VOID_FUNC){
		list_add(l, "MOVE GF@semantic string@not_void_func\n");
	    }
	    else {
		list_add(l, "MOVE GF@semantic string@void_func\n");
	    }
	    generate_func_def_tail(tree, l);
	    break;
	case N_ASSIGN:
	    generate_assign(tree, l);
	    break;
	case N_IF:
	    label_counter++;
	    generate_if_else(tree, l, label_counter, in_function);
	    break;
	case N_WHILE:
	    label_counter++;
	    generate_while(tree, l, label_counter, in_function);
	    break;
	case N_RETURN:
	    generate_return_stat(tree, l, in_function, this_return_type);
    }
    generate_statements(tree->next_sibling, l, in_function);
}

/***** END OF FILE generator.c *****/
