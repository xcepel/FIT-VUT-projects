/*************************************************
* FILENAME: error_handle.h
* PROJECT:  IFJ 2022/23
* AUTHORS:  xstast38 -- Mikuláš Šťastný
*	  
*************************************************/
#ifndef __ERROR_HANDLE_H__
#define __ERROR_HANDLE_H__

enum{
    LEXEME_ERROR = 1,
    SYNTAX_ERROR,
    FUNC_DEF_ERROR, // Used for undefined function or redefinition of function
    PARAM_OR_RET_ERROR, // Used for wrong number/type of function parameters or wrong type
                        // of return value in function
    VAR_DEF_ERROR, // Used for undefined variable
    RET_EXPR_ERROR, // Used for missing/unwanted expression in return from function statement
    TYPE_IN_EXPR, // Used for error of type compatibility in expressions
    OTHER_SEMANTIC_ERROR, // Used for other semantic errors
    INTERNAL_ERROR_MESSAGE = 99, // Used for internal errors (e. g. dynamic allocation error)
};

/**
 * @brief In case of an error, prints an error message, frees alocated memory and exits
 *        with correct return value.
 * 
 * @param error_flag type of error 
 * @param line error occurence line
 */
void error_handle(int error_flag, int line);

#endif

/***** END OF FILE error_handle.h *****/

