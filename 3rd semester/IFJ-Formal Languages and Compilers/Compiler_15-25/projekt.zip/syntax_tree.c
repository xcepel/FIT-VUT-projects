/*************************************************
* FILENAME: syntax_tree.c
* PROJECT:  IFJ 2022/23
* AUTHORS:  xtrnov01 -- Eva Trnovská
*	  
*************************************************/

#include "syntax_tree.h"
#include "symtable.h"
#include "error_handle.h"

/**
 * Allocates an empty node that is NOT connected to the rest of the tree.
 * Its type is set to UNKNOWN.
 */
node_t *stree_empty_node(){
    node_t *n = (node_t *)malloc(sizeof(node_t));
    if (n == NULL){
	error_handle(INTERNAL_ERROR_MESSAGE, 0);
    }
    n->parent = NULL;
    n->first_child = NULL;
    n->next_sibling = NULL;
    n->type = N_UNKNOWN;
    n->defvar = false;
    n->current_table = NULL;
    return n;
}

/**
 * Creates the root node.
 * @param symtable Main symtable passed to the tree; functions' IDs and variables in the main body of compiled program are stored there.
 */
stree_t stree_create_root(htab_t *symtable){
    node_t *n = stree_empty_node();
    n->type = N_ROOT;
    n->data.int_value = 0;
    n->current_table = symtable;
    return n;
}

/** 
 * Returns the last sibling of a given node.
 * @param base the node whose last sibling we are searching for
 * @return last-sibling of a given node
 */
node_t *stree_last_sibling(node_t *base){
    if (base == NULL){
	error_handle(INTERNAL_ERROR_MESSAGE, 0);
    }
    node_t *tmp = base->next_sibling;
    node_t *prev = tmp;
    while (tmp != NULL){
	prev = tmp;
	tmp = tmp->next_sibling;
    }
    return prev;
}

/**
 * Returns the last child of a given node.
 * @param parent Parent node whose last child we are searching for 
 * @return last-child of a given node
 */
node_t * stree_last_child(node_t *parent){
    if (parent == NULL){ 
	error_handle(INTERNAL_ERROR_MESSAGE, 0);
    }
    node_t *tmp = parent->first_child;
    node_t *prev = tmp;
    while (tmp != NULL){
	prev = tmp;
	tmp = tmp->next_sibling;
    }
    return prev;
}

/**
 * Allocates an empty node and connect its to AST. It becomes the last child of a given parent.
 * @param parent Node to which the newly created node will be connected.
 * @return created node
 */
node_t * stree_create_child(node_t *parent){
    if (parent == NULL){
	error_handle(INTERNAL_ERROR_MESSAGE, 0);
	return NULL;
    }
    node_t *prev = stree_last_child(parent);
    node_t *child = stree_empty_node();
    child->current_table = parent->current_table;
    child->parent = parent;
    if (prev == NULL){
	parent->first_child = child;
	return child;
    }
    prev->next_sibling = child;
    return child;
}

/**
 * Allocates an empty node and connect its to AST. It becomes the last sibling of the given node.
 * @param parent Node to which the newly created node will be connected.
 * @return created node
 */
node_t * stree_create_sibling(node_t *base){
    if (base == NULL){
	error_handle(INTERNAL_ERROR_MESSAGE, 0);
    }
    node_t *prev = stree_last_sibling(base);
    node_t *new = stree_empty_node();
    new->current_table = base->current_table; 
    new->parent = base->parent;
    if (prev == NULL){
	base->next_sibling = new;
	return new;
    }
    prev->next_sibling = new;
    return new;
}

/** 
 * Sets node's type to variable and adds it to the symtable
 * @param n Node that is representing the variable.
 * @param t Token that contains the variable's data.
 * @param definition True if the variable is a left side of an assignement.
 */
void stree_add_variable(node_t *n, token *t, bool definition){
    n->type = N_VARIABLE;
    htab_data_t *table_item = htab_lookup_add(n->current_table, t->val.s_val, true, definition, &(n->defvar));
    n->data.operand = table_item;
}

/**
 * Sets node's type to a given type
 * @param n Selected node
 * @param type Type of node to be set
 */
void stree_set_type(node_t *n, node_type_t type){
    n->type = type;
}

/**
 * In case of a constant, sets the node's type accordingly and saves its data from the token to the AST.
 * @param n Node representing the constant
 * @param t Token whose data we are saving
 */
void stree_add_terminal(node_t *n, token *t){
    switch (t->type){
	case INT_VAL:
	    n->type = N_INT_VAL;
	    n->data.int_value = t->val.i_val;
	    break;
    	case FLOAT_VAL:
            n->type = N_FLOAT_VAL;
            n->data.double_value = t->val.d_val;
	    break;
    	case STR_VAL:
	    n->type = N_STR_VAL;
            n->data.string_value = t->val.s_val;
	    break;
    	case NULL_:
	    n->type = N_NULL_VAL;
	    break;
    }
}

/**
 * Adds a function call to AST and looks it up in the symtable
 * @param n Node representing the function call
 * @param t Token containg function's call's data
 */
void stree_add_func_call(node_t *n, token *t){
    n->type = N_FUNC_CALL;
    htab_data_t *table_item = htab_lookup_add(n->current_table, t->val.s_val, false, false, &(n->defvar)); 
    n->data.function = table_item;
}

/**
 * Adds a function definition to AST and looks it up in the symtable
 * @param n Node representing the function definition
 * @param t Token containg function's data
 */
void stree_add_func_def(node_t *n, token *t){
    n->type = N_FUNC_DEF;
    htab_data_t *table_item = htab_lookup_add(n->current_table, t->val.s_val, false, true, &(n->defvar));
    table_item->func_symtable = htab_init(ARR_LEN_MIN); 
    if (table_item->func_symtable == NULL){
	error_handle(INTERNAL_ERROR_MESSAGE, 0);
    }
    n->data.function = table_item;
    n->current_table = table_item->func_symtable;
}


/** 
 * Frees the entire AST
 * @param t Tree to be deleted
 */
void stree_dispose(stree_t *t){
    if (*t != NULL){
        stree_dispose(&(*t)->first_child);
	    stree_dispose(&(*t)->next_sibling);
	    free(*t);
	    *t = NULL;
    }
}
	
/***** END OF FILE syntax_tree.c *****/
