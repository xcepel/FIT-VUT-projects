/*************************************************
* FILENAME: semchecks.c
* PROJECT:  IFJ 2022/23
* AUTHORS:  xstast38 -- Mikuláš Šťastný
*	  
*************************************************/

#include <stdio.h>
#include <string.h>
#include "semchecks.h"
#include "symtable.h"
#include "error_handle.h"

void sem_check_function_redefinition(htab_t *t, char *id, int line){

    // Trying to redefine builtin function
    if(!strcmp(id, "readi") || !strcmp(id, "readf") || !strcmp(id, "reads") || !strcmp(id, "write")){
        htab_free(t);
        error_handle(FUNC_DEF_ERROR, line);
    }

    htab_data_t *item = htab_find(t, id);

    if(item != NULL){
        // Trying to redefine function
        if(item->is_defined == true){
            htab_free(t);
            error_handle(FUNC_DEF_ERROR, line);
        }
    }
}

void sem_check_function_definition(htab_t *t, char *id, int line){
    htab_data_t *item = htab_find(t, id);

    // If function with id is not defined or is not a builtin function calls error_handle
    if(item == NULL && strcmp(id, "readi") && strcmp(id, "readf") && strcmp(id, "reads") && strcmp(id, "write")
       && strcmp(id, "floatval") && strcmp(id, "intval") && strcmp(id, "strval") && strcmp(id, "strlen")
       && strcmp(id, "substring") && strcmp(id, "ord") && strcmp(id, "chr")){
        htab_free(t);
        error_handle(FUNC_DEF_ERROR, line);
    }
}

void sem_check_undefined_variable(htab_t *t, char *id, int line){
    htab_data_t *item = htab_find(t, id);

    if(item == NULL){
        htab_free(t);
        error_handle(VAR_DEF_ERROR, line);
    }
}

void sem_check_params_redefinition(htab_data_t *data, char *param_id, int line){
    if(data != NULL){
        params_t *param = data->params;
        while(param != NULL){
            if(!strcmp(param->param_id, param_id)){
                error_handle(PARAM_OR_RET_ERROR, line);
            }
            param = param->next_param;
        }
    }
}

/***** END OF FILE semchecks.c *****/
