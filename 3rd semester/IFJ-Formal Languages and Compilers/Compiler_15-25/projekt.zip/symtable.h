/*************************************************
* FILENAME: symtable.h
* PROJECT:  IFJ 2022/23
* AUTHORS:  xcepel03 -- Kateřina Čepelkoá
*           xtrnov01 -- Eva Trnovská
*           xstast38 -- Mikuláš Šťastný
*
*************************************************/

#ifndef __HTAB_H__
#define __HTAB_H__

#include <string.h>     // size_t
#include <stdbool.h>    // bool
#include <stdint.h>    // uint32_t
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

#define ARR_LEN_MIN 31
#define AVG_LEN_MIN 1
#define AVG_LEN_MAX 5 

typedef enum { H_VOID_FUNC, H_INT_ID, H_Q_INT_ID, H_FLOAT_ID, H_Q_FLOAT_ID, H_STRING_ID, H_Q_STRING_ID, H_UNKNOWN_ID }id_type;

/***************************************************************************************
*    BEGINNING OF CODE CITATION:
*    Title: htab.h (IJC-DU2)
*    Author: Petr Peringer
*    (Comments by xcepel03 and xtrnov01)
*    Last modification: 22. 03. 2022
*    Availability: https://www.fit.vutbr.cz/study/courses/IJC/public/DU2.html.cs
*    Licence: none (Public domain)
***************************************************************************************/

// Table
typedef struct htab {
    unsigned int size; // number of entries
    unsigned int arr_size; // size of pointer array
    struct htab_item **arr_ptr;
} htab_t;

// Types
typedef const char *htab_key_t;

typedef struct params{
    id_type param;
    char *param_id;
    struct params *next_param;
} params_t;

// Data
typedef struct htab_data {
    htab_key_t id;
    bool is_variable;
    bool is_defined;
    id_type return_type;
    params_t *params;
    htab_t *func_symtable;
} htab_data_t;

void htab_add_param(id_type param, char *param_id, htab_data_t *item);

// Item
typedef struct htab_item {
    htab_data_t data;
    struct htab_item *next;
} htab_item_t;

// Scatter (hash) function
size_t htab_hash_function(htab_key_t str);
                           
/* Functions for working with a table */

// Table constructor
htab_t *htab_init(size_t n); 

// Number of entries in the table
size_t htab_size(const htab_t *t);

// Size of array
size_t htab_bucket_count(const htab_t *t);

// Resizing of the table (allows you to reserve a space)
void htab_resize(htab_t *t, size_t newn);

// Searches for an entry in the table
htab_data_t * htab_find(htab_t *t, htab_key_t key);

// Searches for an entry in the table. If it is not found, adds it
htab_data_t * htab_lookup_add(htab_t *t, htab_key_t key, bool variable, bool definition, bool *defvar);

// Removes entry
bool htab_erase(htab_t *t, htab_key_t key);

// Goes through all the records and calls function f on them
void htab_for_each(const htab_t *t, void (*f)(htab_data_t *data));

// Clearing of the table
void htab_clear(htab_t *t);

// Destruction of the table
void htab_free(htab_t *t);

/***************************************************************************************
* END OF CITED CODE
****************************************************************************************/
void htab_print(htab_t *t);
#endif 

/***** END OF FILE symtable.h *****/
