/*************************************************
* FILENAME: generator.h
* PROJECT:  IFJ 2022/23
* AUTHORS:  xtrnov01 -- Eva Trnovská 
*	  
*************************************************/

#ifndef __GENERATOR_H__
#define __GENERATOR_H__

#include "syntax_tree.h"
#include "linked_list.h"

void foreach(stree_t tree, void (*func)(stree_t, list_t*), list_t *l);

void generate_statements(stree_t tree, list_t *l, bool in_function);

void generate_start(list_t *l);

void generate_end(list_t *l);

void generate_instructions(stree_t tree, list_t *l);

#endif

/***** END OF FILE generator.h *****/
