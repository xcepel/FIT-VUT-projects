/*************************************************
* FILENAME: semchecks.h
* PROJECT:  IFJ 2022/23
* AUTHORS:  xstast38 -- Mikuláš Šťastný
*	  
*************************************************/

#ifndef __SEMCHECKS_H__
#define __SEMCHECKS_H__

#include <stdio.h>
#include <stdbool.h>
#include "symtable.h"

/**
 * @brief Checks, if entered id of function is defined (redefinition would happen).
 *        If so, function calls error_handle, otherwise does nothing.
 * 
 * @param t hastable, where function should look for id
 * @param id id of variable or function
 * @param line line, where the potential error is
 */
void sem_check_function_redefinition(htab_t *t, char *id, int line);

/**
 * @brief Checks, if entered function is defined. If not, function calls
 *        error_handle, otherwise does nothing.
 * 
 * @param t hastable, where function should look for id
 * @param id id of variable or function
 * @param line line, where the potential error is
 */
void sem_check_function_definition(htab_t *t, char *id, int line);

/**
 * @brief Checks, if entered id of variable is defined. If not, function calls
 *        error_handle, otherwise does nothing.
 * 
 * @param t hastable, where function should look for id
 * @param id id of variable or function
 * @param line line, where the potential error is
 */
void sem_check_undefined_variable(htab_t *t, char *id, int line);

/**
 * @brief Checks, if entered param with param_id is already defined as function
 *        with id param. If so, function calls error_handle, otherwise does nothing.
 * 
 * @param data data of function, where sem_check should look for params
 * @param param_id id of param
 * @param line line, where the potential error is
 */
void sem_check_params_redefinition(htab_data_t *data, char *param_id, int line);

#endif

/***** END OF FILE semchecks.h *****/
