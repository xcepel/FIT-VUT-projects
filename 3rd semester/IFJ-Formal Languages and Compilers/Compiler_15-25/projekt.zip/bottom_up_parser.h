/*************************************************
* FILENAME: bottom_up_parser.h
* PROJECT:  IFJ 2022/23
* AUTHORS:  xhalen00 -- Timotej Halenár
*	  
*************************************************/


#ifndef __BOTTOM_UP_PARSER__
#define __BOTTOM_UP_PARSER__
#include "scanner.h"
#include "syntax_tree.h"

typedef enum {
    ADD_b, 
    MUL_b,
    L_PAR_b,
    R_PAR_b,
    ID_b,
    EXP_END_b,
    DIV_b,
    SUB_b,
    CONC_b,
    IS_EQUAL_TYPE_b,
    IS_NOT_EQUAL_TYPE_b,
    LESSER_b,
    GREATER_b,
    LESSER_E_b,
    GREATER_E_b,
    HANDLE_START_b,
    REDUCE_b,
    EXPR_b,
    EMPTY_b
}token_type;



typedef struct Stack_Element{
    token token_data;
    int type;
    struct Stack_Element *next;
    struct Stack_Element *prev;
    int is_terminal;
    node_t *node;
}stack_elem;

bool stree_add_parent(node_t *first, node_t *second, node_t* parent);

typedef struct{
    stack_elem *top;
    stack_elem *top_terminal;
}stack_t;

void init_stack(stack_t *stack);

void convert_token(stack_elem *my_stack_elem, token *my_token);

void push(stack_t *stack, token *token);

void pop(stack_t *stack);

void stack_state(stack_t *stack);

int bottom_up_analysis(token *previous_input, token *input, node_t *n);

void top_terminal(stack_t *stack);

#endif

/***** END OF FILE bottom_up_parser.h *****/
