/*************************************************
* FILENAME: syntax_tree.h
* PROJECT:  IFJ 2022/23
* AUTHORS:  xtrnov01 -- Eva Trnovská
*	  
*************************************************/

#ifndef __TREE_H__
#define __TREE_H__

#include "symtable.h"
#include "scanner.h"

/**
 * Abstract syntax tree node types
 */
typedef enum { N_UNKNOWN, N_ROOT, N_ADD, N_SUB, N_MUL, N_DIV, N_CONC, N_EQUAL, N_NOT_EQUAL, N_GR, N_LS, N_GE, N_LE, 
	N_ASSIGN, N_VARIABLE, N_INT_VAL, N_FLOAT_VAL, N_STR_VAL, N_NULL_VAL, 
	N_FUNC_CALL, N_FUNC_DEF, N_WHILE, N_IF, N_ELSE, N_CONDITION, N_BLOCK,
	N_RETURN, N_INT_P, N_FLOAT_P, N_STRING_P, N_VOID_R, N_STRING_R, N_Q_STRING_R, N_INT_R, N_Q_INT_R, N_FLOAT_R, N_Q_FLOAT_R, N_EXPR_ONLY }node_type_t;

typedef struct node node_t;

/**
 * Struct for AST's nodes
 */
struct node{
    node_type_t type;
    node_t *parent;
    node_t *first_child;
    node_t *next_sibling;
    bool defvar;
    htab_t *current_table;
    union { 
	htab_data_t *operand;
	htab_data_t *function;
	int int_value;
	double double_value;
	char *string_value;
    }data;
}; 

typedef node_t * stree_t;

node_t *stree_empty_node();

stree_t stree_create_root(htab_t *symtable);

void stree_add_return(node_t *n);

node_t *stree_create_child();

node_t *stree_create_sibling();

node_t *stree_last_sibling(node_t *base);

node_t *stree_last_child(node_t *parent);

void stree_set_type(node_t *n, node_type_t type);

void stree_add_variable(node_t *n, token *t, bool definition);

void stree_add_terminal(node_t *n, token *t);

void stree_add_func_call(node_t *n, token *t);

void stree_add_func_def(node_t *n, token *t);

void stree_print(stree_t t);

void stree_dispose(stree_t *t);

#endif

/***** END OF FILE syntax_tree.h *****/
