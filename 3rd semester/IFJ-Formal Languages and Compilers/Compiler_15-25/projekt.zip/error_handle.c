/*************************************************
* FILENAME: error_handle.c
* PROJECT:  IFJ 2022/23
* AUTHORS:  xstast38 -- Mikuláš Šťastný
*	  
*************************************************/

#include <stdio.h>
#include <stdlib.h>

#include "error_handle.h"

// TODO add freeing memory (new function maybe?)
void error_handle(int error_flag, int line){
    switch(error_flag){
        case LEXEME_ERROR:
            fprintf(stderr, "ERROR: lexeme error on line %d\n", line);
            exit(error_flag);
        case SYNTAX_ERROR:
            fprintf(stderr, "ERROR: syntax error on line %d\n", line);
            exit(error_flag);
        case FUNC_DEF_ERROR:
            fprintf(stderr, "ERROR: undefined function or redefinion of function on line %d\n", line);
            exit(error_flag);
        case PARAM_OR_RET_ERROR:
            fprintf(stderr, "ERROR: wrong type or count of parameters or wrong type of return on,line %d\n", line);
            exit(error_flag);
	    case VAR_DEF_ERROR:
            fprintf(stderr, "ERROR: undefined variable on line %d\n", line);
            exit(error_flag);
	    case RET_EXPR_ERROR:
            fprintf(stderr, "ERROR: missing or unwanted expression in return statement on line %d\n", line);
            exit(error_flag);
        case TYPE_IN_EXPR:
            fprintf(stderr, "ERROR: wrong type compatibility in expression on line %d\n", line);
            exit(error_flag);
        case OTHER_SEMANTIC_ERROR:
            fprintf(stderr, "ERROR: semantic error on line %d\n", line);
            exit(error_flag);
        case INTERNAL_ERROR_MESSAGE:
            fprintf(stderr, "ERROR: internal error of interpreter not based on user mistake\n");
            exit(error_flag);
    }	
}

/***** END OF FILE error_handle.c *****/
