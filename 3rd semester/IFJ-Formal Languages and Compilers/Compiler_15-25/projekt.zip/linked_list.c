/*************************************************
* FILENAME: linked_list.c
* PROJECT:  IFJ 2022/23
* AUTHORS:  xtrnov01 -- Eva Trnovská
*	  
*************************************************/

#include "linked_list.h"
#include "error_handle.h"
#include <stdio.h>
#include <stdarg.h>
#define MAX_STR_SIZE 300

/** 
 * Returns last element of a given list
 * @param l List of instructions
 * @return Last element
 */
elem_t *list_last(list_t l){
    elem_t *last = l;
    elem_t *prev = l;
    while (last != NULL){
	prev = last;
        last = last->next;
    }
    return prev;
}

/**
 * Prints the whole list of instructions
 *  User has to insert new lines himself
 *  @param l List of instructions
 */
void list_print(list_t l){
    while (l != NULL){
	printf("%s", l->item);
	l = l->next;
    }
}

/**
 * Adds a new instruction to the list
 * @param l List of instructions
 * @param format Formated string - instruction
 */
void list_add(list_t *l, char *format, ...){
    elem_t *new_elem = (elem_t *)malloc(sizeof(elem_t));
    if (new_elem == NULL){
	error_handle(INTERNAL_ERROR_MESSAGE, 0);
    }
    if (*l != NULL){
	new_elem->prev = list_last(*l);
	new_elem->prev->next = new_elem;
    }
    else {
	*l = new_elem;
	new_elem->prev = NULL;
    }

    // Set value of new_elem->item
    va_list arguments;
    va_start(arguments, format);
    new_elem->item = (char *)malloc(MAX_STR_SIZE);
    if (new_elem->item == NULL){
	error_handle(INTERNAL_ERROR_MESSAGE, 0);
    }
    vsprintf(new_elem->item, format, arguments);
    va_end(arguments);

    new_elem->next = NULL;
}

/**
 * Returns next instruction in the list
 * @param current Current element
 * @return Next element
 */
elem_t *list_next(elem_t *current){
     if (current != NULL)
     	return current->next;	 
     else
	 return NULL;
}

/**
 * Moves all defvars in front of code blocks (while, if-else) to prevent variable redefinition
 * @param l List of instructions
 */
void list_move_defvar(list_t l){
    int while_counter = 0;
    elem_t *first_while = NULL;
    // Find variables in danger of being repeatedly defined inside a cycle
    while (l != NULL){
	if (strstr(l->item, "LABEL while")){
	    if (strstr(l->item, "_start")){
		    if (while_counter == 0){
		        first_while = l;
		    }
	        while_counter++;
	    }
	    else if (strstr(l->item, "_end")){
		    while_counter--;
	    }
	}
    else if(strstr(l->item, "LABEL _if")){
        if(while_counter == 0){
            first_while = l;
        }
        while_counter++;
    }
    else if(strstr(l->item, "LABEL _else") && strstr(l->item, "_skip")){
        while_counter--;
    }
	// Move DEFVAR just in front of current first while cycle
	else if (strstr(l->item, "DEFVAR ")){
	    if (while_counter > 0){
		l->prev->next = l->next;
		l->next->prev = l->prev;
		elem_t *tmp = first_while->prev;
		first_while->prev = l;
		l->next = first_while;
		tmp->next = l;
		l->prev = tmp;
	    }
	}
	l = l->next;
    }

}

/**
 * Deletes last element of the list
 * @param l List of instructions
 */
void list_delete_last(list_t *l){
    elem_t *deleted = list_last(*l);
    if (deleted != NULL){
	if (*l != deleted){
            elem_t *prev = deleted->prev;
            if (prev != NULL){
	       prev->next = NULL;
            }
            free(deleted);
	}
	else {
	    free(deleted);
	    *l = NULL;
	}
    }
}

/**
 * Frees all elements of the list
 * @param l List of instructions
 */
void list_free(list_t l){
    elem_t *tmp = l;
    while (l != NULL){
	tmp = l->next;
	free(l->item); 
	free(l);
	l = tmp;
    }
}


/***** END OF FILE linked_list.c *****/
