/*************************************************
* FILENAME: scanner.h
* PROJECT:  IFJ 2022/23
* AUTHORS:  xcepel03 -- Kateřina Čepelková
*           xtrnov01 -- Eva Trnovská (refactoring)
*	  
*************************************************/

#ifndef __SCANNER_H__
#define __SCANNER_H__

typedef enum {
    _START,
    //Literals
    _INT_LIT,
    _DEC_Q,
    _DEC_LIT,
    _EXPONENT,
    _SIGN,
    _DEC_E_LIT,
    //Brackets
    _BLOCK_START,
    _BLOCK_END,
    _RIGHT_BR,
    _LEFT_BR,
    //Operator
    _PLUS,
    _MINUS,
    _MUL,
    _DIV,
    _DOT,
    _COMMA,
    _COLON,
    _SEMICOLON,
    //Variable
    _VARIABLE_Q,
    _ID_VAR,
    //Output
    _TEXT,
    _SLASH,
    _STR_LIT,
    //Comment
    _LINE,
    _BLOCK,
    _END_Q,
    //Identificator
    _IDENTIF,
    //Signs
    _NOT,
    _EX_EQUAL, // !=
    _NOT_EQ,
    _ASSIGN,
    _DOUBLE_EQ,
    _EQUAL,
    _BIGGER,
    _BIGGER_EQ,
    _SMALLER,
    _SMALLER_EQ,
    //Beginning + End of code
    _SMALLER_Q,
    _SMALLER_QP,
    _SMALLER_QPH,
    _BEGIN,
    _Q_END,
    _END,
    //Identificator of type
    _Q_MARK,
    _Q_S,
    _Q_ST,
    _Q_STR,
    _Q_STRI,
    _Q_STRIN,
    _STRING,
    _Q_I,
    _Q_IN,
    _INT,
    _Q_F,
    _Q_FL,
    _Q_FLO,
    _Q_FLOA,
    _FLOAT,
    //Final state
    _FINAL,
    //Error
    _ERROR,
    _SYNERR
} automata_state;


typedef struct {
    int line;
    enum {
        LEX_ERROR = 1,
        INT_VAL,
        FLOAT_VAL,
        STR_VAL,
        BLOCK_START,
        BLOCK_END,
        PLUS,
        MINUS,
        MUL,
        DIV, //10
        DOT,
        COMMA,
        COLON,
        SEMICOLON,
        MODULO,
        VARIABLE,
        LEFT_BR,
        RIGHT_BR,
        ID,
        ELSE, //20
        FLOAT, 
        FUNCTION,
        IF,
        INT,
        NULL_,
        RETURN,
        STRING,
        VOID,
        WHILE,
        NOT, //30
        NOT_EQ, 
        ASSIGN,
        EQ,
        BIGGER,
        BIGGER_EQ,
        SMALLER,
        SMALLER_EQ,
        BEGIN,
        END,
	Q_STRING, //40
	Q_INT,
	Q_FLOAT,
        INTERNAL_ERROR = 99
    } type;
    union {
        int i_val;
        double d_val;
        char *s_val;
    } val;
} token;


// Returns one token from stdin
token get_token();

#endif // __SCANNER_H__

/***** END OF FILE scanner.h *****/
