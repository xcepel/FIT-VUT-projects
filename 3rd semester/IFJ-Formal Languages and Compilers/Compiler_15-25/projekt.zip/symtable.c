/*************************************************
* FILENAME: symtable.c
* PROJECT:  IFJ 2022/23
* AUTHORS:  xcepel03 -- Kateřina Čepelková
*           xtrnov01 -- Eva Trnovská
*	  
*************************************************/

#include "symtable.h"
#include "error_handle.h"

void htab_add_param(id_type param, char *param_id, htab_data_t *item){
    params_t *new = (params_t *)malloc(sizeof(params_t));
    new->param = param;
    new->param_id = param_id;
    new->next_param = NULL;
    if (item->params == NULL){
	item->params = new;
    }
    else {
	params_t *prev = item->params;
	params_t *current = item->params;
	while (current != NULL){
	    prev = current;
	    current = current->next_param;
	}
	prev->next_param = new; 
    }
}    

// This function was taken out from 2nd IJC project 2021/2022
size_t htab_hash_function(htab_key_t str) {
    uint32_t h=0;
    const unsigned char *p;
    for (p=(const unsigned char*)str; *p != '\0'; p++)
    h = 65599*h + *p;
    return h;
}
                          
/* Functions for working with a table */
htab_t *htab_init(size_t n) {
    if (n < ARR_LEN_MIN)
        n = ARR_LEN_MIN;
    htab_t *t = calloc(1, sizeof(struct htab));
    if (t == NULL)
        return NULL;
                    
    t->arr_ptr = calloc (n, sizeof(t->arr_ptr));
    if (t->arr_ptr == NULL) {
        free(t);
        return NULL;
    }
                            
    t->arr_size = n;
    return t;
}

size_t htab_size(const htab_t *t) {
    return t->size;
}

size_t htab_bucket_count(const htab_t *t) {
    return t->arr_size;
}

void htab_resize(htab_t *t, size_t newn) {
    size_t oldn = htab_bucket_count(t);
    
    if (newn == 0)
        newn = ARR_LEN_MIN;
    if (oldn == newn)
        return;
    else {
        // creating new htab
        struct htab_item **new_arr_ptr = calloc(newn, sizeof(sizeof(struct htab_item)));
        if (new_arr_ptr == NULL)
            return;
        
        // copying old entries into new arr_ptr
        size_t idx;
        struct htab_item *item;
        struct htab_item *next_item;
        for (size_t i = 0; i < oldn; i++) {
            item = t->arr_ptr[i];
            while (item != NULL) {
                next_item = item->next; // saving next item
                idx = htab_hash_function(item->data.id) % newn; // idx acording to the new size
                item->next = new_arr_ptr[idx]; 
                new_arr_ptr[idx] = item;
                item = next_item;
            }
        }

        // freeing of the old htab
        free(t->arr_ptr);
        t->arr_ptr = new_arr_ptr;
        t->arr_size = newn;
    }
}

htab_data_t *htab_find(htab_t *t, htab_key_t key) {
    size_t idx = (htab_hash_function(key) % htab_bucket_count(t));
    
    struct htab_item *searched = t->arr_ptr[idx];
    while (searched != NULL) {
        if (!strcmp(searched->data.id, key))
            return &searched->data;

        searched = searched->next;
    }

    return NULL;
}

htab_data_t *htab_lookup_add(htab_t *t, htab_key_t key, bool variable, bool definition, bool *defvar) {
    // looking up in already registred entries
    size_t idx = htab_hash_function(key) % htab_bucket_count(t);
 
    struct htab_item *searched = t->arr_ptr[idx];
    while (searched != NULL) {
        if (!strcmp(searched->data.id, key)) {
            return &searched->data;
        }
        searched = searched->next;
    }
   
    // if the entry was not found, makes new one
    struct htab_item *item = malloc(sizeof(struct htab_item));
    char *str = malloc(strlen(key) + 1);
    if (!item || !str) {
        free(str);
        free(item);
        return NULL;
    }

    strcpy(str, key);
    item->data.id = str;
    item->data.is_defined = definition;
    item->data.is_variable = variable; 
    *defvar = variable && definition; 
    item->data.params = NULL;
    item->data.func_symtable = NULL;
    item->data.return_type = H_UNKNOWN_ID;  

    // putting new entry at the start
    item->next = t->arr_ptr[idx];
    t->arr_ptr[idx] = item;
    t->size++; // new entry added

    // if diameter > AVG_LEN_MAX -> 2x resize
    if (htab_size(t)/htab_bucket_count(t) > AVG_LEN_MAX)
        htab_resize(t, (htab_bucket_count(t) * 2));

    return &item->data;
}

bool htab_erase(htab_t *t, htab_key_t key) {
    size_t idx = htab_hash_function(key) % htab_bucket_count(t);
    
    struct htab_item *prev = t->arr_ptr[idx];
    struct htab_item *removed = t->arr_ptr[idx];
   
    // if it does not exist, it cannot be removed
    if (removed == NULL)
        return false;
    
    // checking the first entry
    if (!strcmp(removed->data.id, key)) {
        t->arr_ptr[idx] = removed->next;
        t->size--;
        free((void *)removed->data.id);
        free((void *)removed);
        // diameter < AVG_LEN_MIN -> 1/2resize
        if (htab_size(t)/htab_bucket_count(t) < AVG_LEN_MIN)
            htab_resize(t, (htab_bucket_count(t) / 2));
        
        return true;
    }
    
    // checking of the rest
    removed = removed->next;
    while (removed != NULL) {
        if (!strcmp(removed->data.id, key)) {
            prev->next = removed->next;
            t->size--;
            free((void *)removed->data.id);
            free((void *)removed);
            // diameter < AVG_LEN_MIN -> 1/2resize
            if (htab_size(t)/htab_bucket_count(t) < AVG_LEN_MIN)
                htab_resize(t, (htab_bucket_count(t) / 2));
            
            return true;
        }
        prev = removed;
        removed = removed->next;
    }    

    // entry not found, cannot be erased
    return false;
}

void htab_for_each(const htab_t *t, void (*f)(htab_data_t *data)) {
    size_t size = htab_bucket_count(t);
    struct htab_item *item;

    for (size_t i = 0; i < size; i++) {   
        item = t->arr_ptr[i];
        while (item != NULL) {
            f(&item->data);
            item = item->next;
        }
    }
}

void htab_clear_item(htab_item_t *item){
    free((void *)item->data.id);
    params_t *tmp = item->data.params, *tmp1;
    while(tmp != NULL){
        tmp1 = tmp->next_param;
        free(tmp->param_id);
        free(tmp);
        tmp = tmp1;
    }

    if(item->data.func_symtable != NULL){
        htab_free(item->data.func_symtable);
    }
    free(item);
}

void htab_clear(htab_t *t) {
    size_t size = htab_bucket_count(t);
    struct htab_item *item;
    struct htab_item *cache; // cache for saving the next one

    for (size_t i = 0; i < size; i++) {
        item = t->arr_ptr[i];
        while (item != NULL) {
            cache = item->next;
            htab_clear_item(item);
            item = cache;
        }
    }
    
    // checking for double free
    for (size_t i = 0; i < size; i++)
        t->arr_ptr[i] = NULL;
    
    t->size = 0;
}

void htab_free(htab_t *t) {
    htab_clear(t);
    free(t->arr_ptr);
    free(t);
}

/***** END OF FILE symtable.c *****/
