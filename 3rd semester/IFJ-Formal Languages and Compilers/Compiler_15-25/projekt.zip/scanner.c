/*************************************************
* FILENAME: scanner.c
* PROJECT:  IFJ 2022/23
* AUTHORS:  xcepel03 -- Kateřina Čepelková
*           xtrnov01 -- Eva Trnovská (line counting)
*	  
*************************************************/

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "scanner.h"
#include "error_handle.h"


// State START
automata_state start_transition(int edge) {
    switch (edge) {
        case '$': 
            return _VARIABLE_Q;
        case '<': 
            return _SMALLER;
        case '>': 
            return _BIGGER;
        case '(': 
            return _LEFT_BR;
        case ')': 
            return _RIGHT_BR;
        case '{': 
            return _BLOCK_START;
        case '}': 
            return _BLOCK_END;
        case '/': 
            return _DIV;
        case '?': 
            return _Q_MARK;
        case '=': 
            return _ASSIGN;
        case '!': 
            return _NOT;
        case '0' ... '9':
            return _INT_LIT;
        case 'a' ... 'z': case 'A' ... 'Z': case '_':
            return _IDENTIF;
        case '+':
            return _PLUS;
        case '"':
            return _TEXT;
        case '-': 
            return _MINUS;
        case '*': 
            return _MUL;
        case '.': 
            return _DOT;
        case ',': 
            return _COMMA;
        case ':': 
            return _COLON;
        case ';': 
            return _SEMICOLON;
        default:
            return _FINAL;
    }
    return _FINAL;
}


// State for int or float(with exponent))
automata_state int_lit_transition(int edge) {
    switch (edge) {
        case '0' ... '9':
            return _INT_LIT;
        case '.': 
            return _DEC_Q;
        case 'e': case 'E': 
            return _EXPONENT;
    }
    return _FINAL;
}


// State that decides if entry is float or not
automata_state q_dec_transition(int edge) {
    switch (edge) {
        case '0' ... '9':
            return _DEC_LIT;
    }
    return _ERROR;
}


// State decides if float / float + exponent?
automata_state dec_lit_transition(int edge) {
    switch (edge) {
        case '0' ... '9':
            return _DEC_LIT;
        case 'e': case 'E':
            return _EXPONENT;
    }
    return _FINAL;
}


// State controls correct exponent
automata_state exponent_transition(int edge) {
    switch (edge) {
        case '0' ... '9':
            return _DEC_E_LIT;
        case '+': case '-':
            return _SIGN;
    }
    return _ERROR;
}


// State adds sign to exponent
automata_state sign_transition(int edge) {
    switch (edge) { 
        case '0' ... '9':
            return _DEC_E_LIT;
    }
    return _ERROR;
}


// State for float with exponent
automata_state dec_e_lit_transition(int edge) {
    switch (edge) {
        case '0' ... '9':
            return _DEC_E_LIT;
    }
    return _FINAL;
}


// State for start of variables
automata_state variable_q_transition(int edge) {
    switch (edge) {
        case 'a' ... 'z': case 'A' ... 'Z': case '_':
            return _ID_VAR;
    }
    return _ERROR;
}


// State for variables
automata_state id_var_transition(int edge) {
    switch (edge) {
        case 'a' ... 'z': case 'A' ... 'Z': case '0' ... '9': case '_':
            return _ID_VAR;
    }
    return _FINAL;
}


// State for dividing or comment
automata_state div_transition(int edge) {
    switch (edge) {
        case '/':
            return _LINE;
        case '*':
            return _BLOCK;
    }
    return _FINAL;
}


// State that saves text from " "
automata_state text_transition(int edge) {
    switch (edge) {
        case '\\':
            return _SLASH;
        case '"':
            return _STR_LIT;
        case '$':
            return _ERROR;
        default:
            break;
    }
    return _TEXT;
}


// State for marking line comment
automata_state line_transition() {
    int next = fgetc(stdin);
    ungetc(next, stdin);
    switch (next) {
        case '\n':
        case EOF:
            return _START;
        default:
            break;
    }
    return _LINE;
}


// State for marking block comment
automata_state block_transition(int edge) {
    switch (edge) {
        case '*':
            return _END_Q;
        default:
            break;
    }
    return _BLOCK;
}


// State that checks if its end of line comment
automata_state end_q_transition(int edge) {
    switch (edge) {
        int c;
        case '/':
            //while (isspace(c = fgetc(stdin))); // removes whitespaces after
            //ungetc(c, stdin);
            return _START;
        default:
            break;
    }
    return _BLOCK;
}


// State that saves identificators
automata_state id_transition(int edge) {
    switch (edge) {
        case 'a' ... 'z': case 'A' ... 'Z': case '0' ... '9': case '_':
            return _IDENTIF;
    }
    return _FINAL;
}


// State for not (!)
automata_state not_transition(int edge) {
    switch (edge) {
        case '=':
            return _EX_EQUAL;
        default:
            break;
    }
    return _FINAL;
}

// State for !=
automata_state ex_eq_transition(int edge) {
    switch (edge) {
        case '=':
            return _NOT_EQ;
        default: 
            break;
    }
    return _ERROR;
}


// State for =
automata_state assign_transition(int edge) {
    switch (edge) {
        case '=':
            return _DOUBLE_EQ;
        default:
            break;
    }
    return _FINAL;
}


// State for ==
automata_state double_eq_transition(int edge) {
    switch (edge) {
        case '=':
            return _EQUAL;
        default:
            break;
    }
    return _ERROR;
}


// State for <
automata_state bigger_transition(int edge) {
    switch (edge) {
        case '=':
            return _BIGGER_EQ;
        default:
            break;
    }
    return _FINAL;
}


// State for >
automata_state smaller_transition(int edge) {
    switch (edge) {
        case '=':
            return _SMALLER_EQ;
        case '?':
            return _SMALLER_Q;
        default:
            break;
    }
    return _FINAL;
}


// States for end of code <?php
automata_state smaller_q_transition(int edge) {
    switch (edge) {
        case 'p':
            return _SMALLER_QP;
        default:
            break;
    }
    return _ERROR;
}

automata_state smaller_qp_transition(int edge) {
    switch (edge) {
        case 'h': 
            return _SMALLER_QPH;
        default:
            break;
    }
    return _ERROR;
}

automata_state smaller_qph_transition(int edge) {
    switch (edge) {
        case 'p': 
            return _BEGIN;
        default:
            break;
    }
    return _ERROR;
}

automata_state begin_transition(int edge) {
    if (isspace(edge))
        return _FINAL;
    else
        return _ERROR;
}

// State for ?
automata_state q_transition(int edge) {
    switch (edge) {
        case '>':
            return _Q_END;
        case 's':
            return _Q_S;
        case 'i':
            return _Q_I;
        case 'f':
            return _Q_F;
        default:
            break;
    }
    return _ERROR;
}

// State for comfirming end of code
automata_state q_end_transition(int edge) {
    // Check for windows end of line
    if (edge == '\r')
        edge = fgetc(stdin);
    if (edge == '\n')
        edge = fgetc(stdin);
    switch (edge) {
        case EOF:
            return _END;
        default:
            break;
    }
    return _SYNERR;
}

// State for recognition of type ?string
automata_state q_s_transition(int edge) {
    switch (edge) {
        case 't':
            return _Q_ST;
        default:
            break;
    }
    return _ERROR;
}

automata_state q_st_transition(int edge) {
    switch (edge) {
        case 'r':
            return _Q_STR;
        default:
            break;
    }
    return _ERROR;
}

automata_state q_str_transition(int edge) {
    switch (edge) {
        case 'i':
            return _Q_STRI;
        default:
            break;
    }
    return _ERROR;
}

automata_state q_stri_transition(int edge) {
    switch (edge) {
        case 'n':
            return _Q_STRIN;
        default:
            break;
    }
    return _ERROR;
}

automata_state q_strin_transition(int edge) {
    switch (edge) {
        case 'g':
            return _STRING;
        default:
            break;
    }
    return _ERROR;
}


// State for recognition of type ?int
automata_state q_i_transition(int edge) {
    switch (edge) {
        case 'n':
            return _Q_IN;
        default:
            break;
    }
    return _ERROR;
}

automata_state q_in_transition(int edge) {
    switch (edge) {
        case 't':
            return _INT;
        default:
            break;
    }
    return _ERROR;
}
            

// State for recognition of type ?float
automata_state q_f_transition(int edge) {
    switch (edge) {
        case 'l':
            return _Q_FL;
        default:
            break;
    }
    return _ERROR;
}

automata_state q_fl_transition(int edge) {
    switch (edge) {
        case 'o':
            return _Q_FLO;
        default:
            break;
    }
    return _ERROR;
}

automata_state q_flo_transition(int edge) {
    switch (edge) {
        case 'a':
            return _Q_FLOA;
        default:
            break;
    }
    return _ERROR;
}

automata_state q_floa_transition(int edge){
    switch (edge) {
        case 't':
            return _FLOAT;
        default:
            break;
    }
    return _ERROR;
}


//Transition between all states
automata_state transition(automata_state in, int edge) {
    switch (in) {
        case _START:
            return start_transition(edge);
        case _INT_LIT:
            return int_lit_transition(edge);
        case _DEC_Q:
            return q_dec_transition(edge);
        case _DEC_LIT:
            return dec_lit_transition(edge);
        case _EXPONENT:
            return exponent_transition(edge);
        case _DEC_E_LIT:
            return dec_e_lit_transition(edge);
        case _SIGN:
            return sign_transition(edge);
        case _BLOCK_END: case _BLOCK_START: case _LEFT_BR: 
        case _RIGHT_BR: case _PLUS: case _MINUS: case _MUL: case  _DOT: 
        case _COMMA: case  _COLON: case _SEMICOLON:
            return _FINAL;
        case _VARIABLE_Q:
            return variable_q_transition(edge);
        case _ID_VAR:
            return id_var_transition(edge);
        case _TEXT:
            return text_transition(edge);
        case _SLASH:
            return _TEXT;
        case _STR_LIT:
            return _FINAL;
        case _DIV:
            return div_transition(edge);
        case _LINE:
            return line_transition();
        case _BLOCK:
            return block_transition(edge);
        case _END_Q:
            return end_q_transition(edge);
        case _IDENTIF:
            return id_transition(edge);
        case _NOT:
            return not_transition(edge);
        case _EX_EQUAL:
            return ex_eq_transition(edge);
        case _NOT_EQ:
            return _FINAL;
        case _ASSIGN:
            return assign_transition(edge);
        case _DOUBLE_EQ:
            return double_eq_transition(edge);
        case _EQUAL:
            return _FINAL;
        case _BIGGER:
            return bigger_transition(edge);
        case _BIGGER_EQ:
            return _FINAL;
        case _SMALLER:
            return smaller_transition(edge);
        case _SMALLER_EQ:
            return _FINAL;
        case _SMALLER_Q:
            return smaller_q_transition(edge);
        case _SMALLER_QP:
            return smaller_qp_transition(edge);
        case _SMALLER_QPH:
            return smaller_qph_transition(edge);
        case _BEGIN:
            return begin_transition(edge);
        case _Q_MARK:
            return q_transition(edge);
        case _Q_END:
            return q_end_transition(edge);
        case _END:
            return _FINAL;
        case _Q_S:
            return q_s_transition(edge);
        case _Q_ST:
            return q_st_transition(edge);
        case _Q_STR:
            return q_str_transition(edge);
        case _Q_STRI:
            return q_stri_transition(edge);
        case _Q_STRIN:
            return q_strin_transition(edge);
        case _STRING:
            return _FINAL;
        case _Q_I:
            return q_i_transition(edge);
        case _Q_IN:
            return q_in_transition(edge);
        case _INT:
            return _FINAL;
        case _Q_F:
            return q_f_transition(edge);
        case _Q_FL:
            return q_fl_transition(edge);
        case _Q_FLO:
            return q_flo_transition(edge);
        case _Q_FLOA:
            return q_floa_transition(edge);
        case _FLOAT:
            return _FINAL;
        default:
            break;
    }
    return _ERROR;
}


// Differencing key words from identificator
token key_words(char *str, int line) {
    if (!strcmp(str, "else")) {
        free(str);
        return (token){line, ELSE, {0}};
    } else if (!strcmp(str, "float")) {
        free(str);
        return (token){line, FLOAT, {0}};
    } else if (!strcmp(str, "function")) {
        free(str);
        return (token){line, FUNCTION, {0}};
    } else if (!strcmp(str, "if")) {
        free(str);
        return (token){line, IF, {0}};
    } else if (!strcmp(str, "int")) {
        free(str);
        return (token){line, INT, {0}};
    } else if (!strcmp(str, "null")) {
        free(str);
        return (token){line, NULL_, {0}};
    } else if (!strcmp(str, "return")) {
        free(str);
        return (token){line, RETURN, {0}};
    } else if (!strcmp(str, "string")) {
        free(str);
        return (token){line, STRING, {0}};
    } else if (!strcmp(str, "void")) {
        free(str);
	return (token){line, VOID, {0}};
    } else if (!strcmp(str, "while")) {
        free(str);
        return (token){line, WHILE, {0}};
    } else 
        return (token){line, ID, {.s_val = str}};
}


//Transition from final state to token
token make_token(automata_state final, char *str, int line) {
    switch (final) {
        case _INT_LIT:
            return (token){line, INT_VAL, {.i_val = atoi(str)}};
        case _DEC_LIT: case _DEC_E_LIT:
            return (token){line, FLOAT_VAL, {.d_val = strtod(str, NULL)}};
        case _BLOCK_START:
            return (token){line, BLOCK_START, {0}};
        case _BLOCK_END:
            return (token){line, BLOCK_END, {0}};
        case _RIGHT_BR:
            return (token){line, RIGHT_BR, {0}};
        case _LEFT_BR:
            return (token){line, LEFT_BR, {0}};
        case _PLUS:
            return (token){line, PLUS, {0}};
        case _MINUS:
            return (token){line, MINUS, {0}};
        case _MUL:
            return (token){line, MUL, {0}};
        case _DIV:
            return (token){line, DIV, {0}};
        case _DOT:
            return (token){line, DOT, {0}};
        case _COMMA:
            return (token){line, COMMA, {0}};
        case _COLON:
            return (token){line, COLON, {0}};
        case _SEMICOLON:
            return (token){line, SEMICOLON, {0}};
        case _ID_VAR:
            return (token){line, VARIABLE, {.s_val = str}};
        case _STR_LIT:
            return (token){line, STR_VAL, {.s_val = str}};
        case _IDENTIF:
            return key_words(str, line);
        case _NOT:
            return (token){line, NOT, {0}};
        case _NOT_EQ:
            return (token){line, NOT_EQ, {0}};
        case _ASSIGN:
            return (token){line, ASSIGN, {0}};
        case _EQUAL:
            return (token){line, EQ, {0}};
        case _BIGGER:
            return (token){line, BIGGER, {0}};
        case _BIGGER_EQ:
            return (token){line, BIGGER_EQ, {0}};
        case _SMALLER:
            return (token){line, SMALLER, {0}};
        case _SMALLER_EQ:
            return (token){line, SMALLER_EQ, {0}};
        case _BEGIN:
            return (token){line, BEGIN, {0}};
        case _END:
            return (token){line, END, {0}};
        case _STRING:
            return (token){line, Q_STRING, {0}};
        case _INT:
            return (token){line, Q_INT, {0}};
        case _FLOAT:
            return (token){line, Q_FLOAT, {0}};
        default:
            break;
    }
    // securing falldown
    error_handle(LEXEME_ERROR, line);
}


// Returns one token from stdin
token get_token() {
    static bool start_check = false; // prolog found
    static int current_line = 1;
    automata_state now = _START;
    automata_state next;
    char *str = NULL;
    char *newstr = NULL;

    int edge = fgetc(stdin);
    // Check if (no whitespace)<?php
    if (!start_check && edge != '<') {
        error_handle(SYNTAX_ERROR, current_line); // 
    } 
    start_check = true;

    // Skipping whitespaces
    while (isspace(edge)) {
        if (edge == '\n'){
	    current_line++;
    	}
	edge = fgetc(stdin);
    }
    ungetc(edge, stdin);

    // Loads chars until the EOF or until it finds a lexeme
    for (int cnt = 1; (edge = fgetc(stdin)) != EOF; cnt++) {
        next = transition(now, edge);
        if (next == _FINAL) {
            ungetc(edge, stdin);
            token res = make_token(now, str, current_line); // finishing token -> return its type
            // str need to be freed manually later 
            if (now != _ID_VAR && now != _STR_LIT && now != _IDENTIF)
                free(str);
            return res;
        }

        if (next == _ERROR) {
            free(str);
            error_handle(LEXEME_ERROR, current_line);
        }
        
        if (next == _SYNERR) {
            free(str);
            error_handle(SYNTAX_ERROR, current_line);
        }
        
        if (next == _START) {
            free(str);
            return get_token();
        }

        // Dispose of comments
        if (now == _LINE || now == _BLOCK || now == _END_Q) {
	    now = next;
            cnt = 0;
            continue;
        }

        // Saves literals/text
        newstr = realloc(str, cnt + 1);
        if (newstr == NULL) {
            free(str);
            error_handle(INTERNAL_ERROR_MESSAGE, current_line);
        }
        str = newstr;
        str[cnt - 1] = edge;
        str[cnt] = '\0';

        now = next;
    }

    // finishing unfinnished token (tokenEOF)
    if (edge == EOF && now != _START) {
        token res;
        if (now == _Q_END) {
            now = q_end_transition(edge); 
            res = make_token(now, str, current_line);
        } else {
            res = make_token(now, str, current_line);
        }
        if (now != _ID_VAR && now != _STR_LIT && now != _IDENTIF)
                free(str);
        return res;
    }

    return (token){current_line, END, {0}};
}

/***** END OF FILE scanner.c *****/
