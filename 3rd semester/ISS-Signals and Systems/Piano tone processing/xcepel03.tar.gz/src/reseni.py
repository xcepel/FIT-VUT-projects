# Reseni ISS 2022/2023
# Autor: Kateřina Čepelková, xcepel03


import math
import numpy as np
import matplotlib.pyplot as plt
import soundfile as sf

# Nacteni vsech signalu
# --- upraveny kod ze zadani ---
MIDIFROM = 24
MIDITO = 108
SKIP_SEC = 0.25
HOWMUCH_SEC = 0.5
WHOLETONE_SEC = 2
howmanytones = MIDITO - MIDIFROM + 1
tones = np.arange(MIDIFROM, MIDITO + 1)
original, Fs = sf.read('../audio/klavir.wav')
SKIP = math.ceil(SKIP_SEC * Fs)  # preskoceni zacatku
N = int(Fs * HOWMUCH_SEC)
Nwholetone = int(Fs * WHOLETONE_SEC)
WHOLETONE = Fs * WHOLETONE_SEC
xall = np.zeros((MIDITO + 1, N))  # matrix with all tones - first signals empty,
# but we have plenty of memory ...
samplefrom = int(SKIP_SEC * Fs)
sampleto = samplefrom + N

for tone in tones:
    x = original[samplefrom:sampleto]
    x = x - np.mean(x)  # safer to center ...
    xall[tone, :] = x
    samplefrom += Nwholetone
    sampleto += Nwholetone
# --- konec kodu ze zadani ---

# --- UKOL 1 - Zaklady ---
# Zobrazte 3 periody vašich tří tónů v ustálené části a spočítejte a vykreslete spektrum celého 0.5s dlouhého úseku.
# Vaše tóny uložte jako audio/a_orig.wav, audio/b_orig.wav, a audio/c_orig.wav

# pulsekundy tonu + jeji ukladani
a_tone = 37
a_f = 69.30
# plt.subplot(311)
# plt.plot(xall[a_tone])
a_start = Nwholetone * (a_tone - MIDIFROM)
a_whole = original[a_start:a_start + WHOLETONE]
sf.write('../audio/a_orig.wav', xall[a_tone], Fs)

b_tone = 62
b_f = 293.66
# plt.subplot(312)
# plt.plot(xall[b_tone])
b_start = Nwholetone * (b_tone - MIDIFROM)
b_whole = original[b_start:b_start + WHOLETONE]
sf.write('../audio/b_orig.wav', xall[b_tone], Fs)

c_tone = 104
c_f = 3322.44
# plt.subplot(313)
# plt.plot(xall[c_tone])
c_start = Nwholetone * (c_tone - MIDIFROM)
c_whole = original[c_start:c_start + WHOLETONE]
sf.write('../audio/c_orig.wav', xall[c_tone], Fs)

# plt.show()

# 3 periody z 2s
a_period = (1 / a_f) * Fs  # kolik vzorku na 1 periodu
plt.subplot(311)
plt.title('3 periody (tony: 37, 62, 104)')
plt.ylabel('Amplituda')
a_ox = np.arange(0, 3 * a_period / Fs, step=1 / Fs)
plt.plot(a_ox, a_whole[SKIP:SKIP + math.ceil(a_period * 3)])

b_period = (1 / b_f) * Fs
plt.subplot(312)
plt.ylabel('Amplituda')
b_ox = np.arange(0, 3 * b_period / Fs, step=1 / Fs)
plt.plot(b_ox, b_whole[SKIP:SKIP + math.ceil(b_period * 3)])

c_period = (1 / c_f) * Fs
plt.subplot(313)
plt.ylabel('Amplituda')
plt.xlabel('Čas [s]')
c_ox = np.arange(0, 3 * c_period / Fs, step=1 / Fs)
plt.plot(c_ox, c_whole[SKIP:SKIP + math.ceil(c_period * 3)])

plt.show()

# spektrum celého 0.5s dlouhého úseku
a_toneDFT = np.fft.fft(xall[a_tone])
a_G = 10 * np.log10(1e-5 + (1 / N * (np.abs(a_toneDFT) ** 2)))
a_freq = np.arange(a_G.size) * Fs / N  # frequency (x-axis)
plt.subplot(311)
plt.title('Spektrum (tony: 37, 62, 104)')
plt.ylabel('PSD [dB]')
plt.plot(a_freq[:a_freq.size // 2], a_G[:a_freq.size // 2])

b_toneDFT = np.fft.fft(xall[b_tone])
b_G = 10 * np.log10(1e-5 + (1 / N * (np.abs(b_toneDFT) ** 2)))
b_freq = np.arange(b_G.size) * Fs / N  # frequency (x-axis)
plt.subplot(312)
plt.ylabel('PSD [dB]')
plt.plot(b_freq[:b_freq.size // 2], b_G[:b_freq.size // 2])

c_toneDFT = np.fft.fft(xall[c_tone])
c_G = 10 * np.log10(1e-5 + (1 / N * (np.abs(c_toneDFT) ** 2)))
c_freq = np.arange(c_G.size) * Fs / N  # frequency (x-axis)
plt.subplot(313)
plt.ylabel('PSD [dB]')
plt.xlabel('Frekvence [Hz]')
plt.plot(c_freq[:c_freq.size // 2], c_G[:c_freq.size // 2])

plt.show()


# --- UKOL 2 - Určení základní frekvence ---
# pomoci DFT
# frekvence vsech vzorku
dft_max = [0] * 109
print("Ukol 2 (DFT):")
for x in range(24, 109):  # 108+1
    dft_max[x] = np.argmax(np.abs(np.fft.fft(xall[x]))[:np.abs(np.fft.fft(xall[x])).size // 2]) * Fs * 1 / N
    print(x, "=>", dft_max[x])

# graf DFT
a_module = np.abs(a_toneDFT)
a_module_half = a_module[:a_module.size // 2]
a_F = np.arange(a_module_half.size) * (Fs / xall[a_tone].size)
plt.subplot(311)
plt.title('DFT (tony: 37, 62, 104)')
plt.ylabel('Amplituda')
plt.plot(a_F, a_module_half)
plt.axvline(x=dft_max[a_tone], color='red', linestyle='dotted')

b_module = np.abs(b_toneDFT)
b_module_half = b_module[:b_module.size // 2]
b_F = np.arange(b_module_half.size) * (Fs / xall[a_tone].size)
plt.subplot(312)
plt.ylabel('Amplituda')
plt.plot(b_F, b_module_half)
plt.axvline(x=dft_max[b_tone], color='red', linestyle='dotted')

c_module = np.abs(c_toneDFT)
c_module_half = c_module[:c_module.size // 2]
c_F = np.arange(c_module_half.size) * (Fs / xall[c_tone].size)
plt.subplot(313)
plt.xlabel('Frekvence [Hz]')
plt.ylabel('Amplituda')
plt.plot(c_F, c_module_half)
plt.axvline(x=dft_max[c_tone], color='red', linestyle='dotted')

plt.show()


# --- UKOL 3 - Zpřesnění odhadu základní frekvence f0 ---
FREQPOINTS = 100
n = np.arange(0, N)
f0 = [0] * 109
print("Ukol 3 (DTFT):")
for x in range(24, 109):
    fsweep = np.linspace((dft_max[x]) + 2 * (Fs / N), (dft_max[x]) - 2 * (Fs / N), FREQPOINTS)
    # print(fsweep[0], " az ", fsweep[99])
    mat = np.zeros([FREQPOINTS, N], dtype=complex)
    for k in np.arange(0, FREQPOINTS):
        mat[k, :] = np.exp(-1j * 2 * np.pi * fsweep[k] / Fs * n)  # norm. omega = 2 * pi * f / Fs ...
    dtft = np.matmul(mat, xall[x])
    # rucni oprava hodnot
    if (x <= 37) or (53 <= x <= 55):
        f0[x] = fsweep[np.argmax(np.abs(dtft))] / 2
    elif 38 <= x <= 40:
        f0[x] = fsweep[np.argmax(np.abs(dtft))] / 3
    else:
        f0[x] = fsweep[np.argmax(np.abs(dtft))]
    print(x, "=>", f0[x])


# --- UKOL 4 - Reprezentace klavíru ---
# stejný jako 3 akorát to uděláš 5krát pro každej tón a uložíš výsledek dtft
f1 = [list()] * 109
for x in range(24, 109):
    fsweep1 = np.linspace((1*f0[x]) + 2 * (Fs / N), (1*f0[x]) - 2 * (Fs / N), FREQPOINTS)
    mat1 = np.zeros([FREQPOINTS, N], dtype=complex)
    for k in np.arange(0, FREQPOINTS):
        mat1[k, :] = np.exp(-1j * 2 * np.pi * fsweep1[k] / Fs * n)  # norm. omega = 2 * pi * f / Fs ...
    dtft1 = np.matmul(mat1, xall[x])
    f1[x] = [np.max(np.abs(dtft1)), np.angle(dtft1[np.argmax(np.abs(dtft1))])]  # (modul, fáze)


# print("f1 vypocitany")

f2 = [list()] * 109
for x in range(24, 109):
    fsweep2 = np.linspace((2*f0[x]) + 2 * (Fs / N), (2*f0[x]) - 2 * (Fs / N), FREQPOINTS)
    mat2 = np.zeros([FREQPOINTS, N], dtype=complex)
    for k in np.arange(0, FREQPOINTS):
        mat2[k, :] = np.exp(-1j * 2 * np.pi * fsweep2[k] / Fs * n)  # norm. omega = 2 * pi * f / Fs ...
    dtft2 = np.matmul(mat2, xall[x])
    f2[x] = [np.max(np.abs(dtft2)), np.angle(dtft2[np.argmax(np.abs(dtft2))])]

# print("f2 vypocitany")

f3 = [list()] * 109
for x in range(24, 109):
    fsweep3 = np.linspace((3*f0[x]) + 2 * (Fs / N), (3*f0[x]) - 2 * (Fs / N), FREQPOINTS)
    mat3 = np.zeros([FREQPOINTS, N], dtype=complex)
    for k in np.arange(0, FREQPOINTS):
        mat3[k, :] = np.exp(-1j * 2 * np.pi * fsweep3[k] / Fs * n)  # norm. omega = 2 * pi * f / Fs ...
    dtft3 = np.matmul(mat3, xall[x])
    f3[x] = [np.max(np.abs(dtft3)), np.angle(dtft3[np.argmax(np.abs(dtft3))])]

# print("f3 vypocitany")

f4 = [list()] * 109
for x in range(24, 109):
    fsweep4 = np.linspace((4*f0[x]) + 2 * (Fs / N), (4*f0[x]) - 2 * (Fs / N), FREQPOINTS)
    mat4 = np.zeros([FREQPOINTS, N], dtype=complex)
    for k in np.arange(0, FREQPOINTS):
        mat4[k, :] = np.exp(-1j * 2 * np.pi * fsweep4[k] / Fs * n)  # norm. omega = 2 * pi * f / Fs ...
    dtft4 = np.matmul(mat4, xall[x])
    f4[x] = [np.max(np.abs(dtft4)), np.angle(dtft4[np.argmax(np.abs(dtft4))])]

# print("f4 vypocitany")

f5 = [list()] * 109
for x in range(24, 109):
    fsweep5 = np.linspace((5*f0[x]) + 2 * (Fs / N), (5*f0[x]) - 2 * (Fs / N), FREQPOINTS)
    mat5 = np.zeros([FREQPOINTS, N], dtype=complex)
    for k in np.arange(0, FREQPOINTS):
        mat5[k, :] = np.exp(-1j * 2 * np.pi * fsweep5[k] / Fs * n)  # norm. omega = 2 * pi * f / Fs ...
    dtft5 = np.matmul(mat5, xall[x])
    f5[x] = [np.max(np.abs(dtft5)), np.angle(dtft5[np.argmax(np.abs(dtft5))])]

# print("f5 vypocitany")


# Vykresleni spektra pro a
plt.subplot(311)
x_line = round(11 * f0[a_tone]) // 2
plt.plot(a_freq[:x_line], a_G[:x_line])
plt.plot(5*f0[a_tone], 10 * np.log10(1e-5 + (1 / N * (np.abs(f5[a_tone][0] ** 2)))), marker="o", color="green", markersize=6)
plt.plot(4*f0[a_tone], 10 * np.log10(1e-5 + (1 / N * (np.abs(f4[a_tone][0] ** 2)))), marker="o", color="green", markersize=6)
plt.plot(3*f0[a_tone], 10 * np.log10(1e-5 + (1 / N * (np.abs(f3[a_tone][0] ** 2)))), marker="o", color="green", markersize=6)
plt.plot(2*f0[a_tone], 10 * np.log10(1e-5 + (1 / N * (np.abs(f2[a_tone][0] ** 2)))), marker="o", color="green", markersize=6)
plt.plot(1*f0[a_tone], 10 * np.log10(1e-5 + (1 / N * (np.abs(f1[a_tone][0] ** 2)))), marker="o", color="green", markersize=6)
plt.title("Spektrum tonu (37, 67, 104)")
plt.ylabel('PSD [dB]')
# plt.show()

# Vykresleni spektra pro b
plt.subplot(312)
x_line = round(11 * f0[b_tone]) // 2
plt.plot(b_freq[:x_line], b_G[:x_line])
plt.plot(5*f0[b_tone], 10 * np.log10(1e-5 + (1 / N * (np.abs(f5[b_tone][0] ** 2)))), marker="o", color="green", markersize=6)
plt.plot(4*f0[b_tone], 10 * np.log10(1e-5 + (1 / N * (np.abs(f4[b_tone][0] ** 2)))), marker="o", color="green", markersize=6)
plt.plot(3*f0[b_tone], 10 * np.log10(1e-5 + (1 / N * (np.abs(f3[b_tone][0] ** 2)))), marker="o", color="green", markersize=6)
plt.plot(2*f0[b_tone], 10 * np.log10(1e-5 + (1 / N * (np.abs(f2[b_tone][0] ** 2)))), marker="o", color="green", markersize=6)
plt.plot(1*f0[b_tone], 10 * np.log10(1e-5 + (1 / N * (np.abs(f1[b_tone][0] ** 2)))), marker="o", color="green", markersize=6)
plt.ylabel('PSD [dB]')
# plt.show()

# Vykresleni spektra pro c
x_line = round(11 * f0[c_tone]) // 2
plt.subplot(313)
plt.plot(c_freq[:x_line], c_G[:x_line])
plt.plot(5*f0[c_tone], 10 * np.log10(1e-5 + (1 / N * (np.abs(f5[c_tone][0] ** 2)))), marker="o", color="green", markersize=6)
plt.plot(4*f0[c_tone], 10 * np.log10(1e-5 + (1 / N * (np.abs(f4[c_tone][0] ** 2)))), marker="o", color="green", markersize=6)
plt.plot(3*f0[c_tone], 10 * np.log10(1e-5 + (1 / N * (np.abs(f3[c_tone][0] ** 2)))), marker="o", color="green", markersize=6)
plt.plot(2*f0[c_tone], 10 * np.log10(1e-5 + (1 / N * (np.abs(f2[c_tone][0] ** 2)))), marker="o", color="green", markersize=6)
plt.plot(1*f0[c_tone], 10 * np.log10(1e-5 + (1 / N * (np.abs(f1[c_tone][0] ** 2)))), marker="o", color="green", markersize=6)
plt.xlabel('Frekvence [Hz]')
plt.ylabel('PSD [dB]')
plt.show()

# --- UKOL 5 -  Syntéza tónů ---
# udělat pole, poskládat znovu komplexní čísla z těch f1-f5
# Dát je na správný místa v tom poli a udělat na tím polem ifft
# ještě budeš muset vyrobit komplexně sdružený čísla k těm f1-f5 a taky je tam dát před tím ifft