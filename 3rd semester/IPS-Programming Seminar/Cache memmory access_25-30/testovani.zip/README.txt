
Příklady pro předmět IPS

- demonstrují vliv paměťové hierarchie na rychlost programů

- přiložené výsledky jsou jen pro ilustraci

- odkazy na zdroje jsou na WWW a v příkladech


