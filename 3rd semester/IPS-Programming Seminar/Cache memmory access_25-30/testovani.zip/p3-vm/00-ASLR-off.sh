
echo "Turn ASLR off:"
setarch `uname -m` -v -R /bin/bash

