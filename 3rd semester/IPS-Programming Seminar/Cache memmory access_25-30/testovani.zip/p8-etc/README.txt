
Tests of various performance-related problems
=============================================

test-volatile: Interesting paradox --
  volatile access is faster if we call extra empty function

test-branch-predict: Branch predictor effects (Intel i5 only)
  (We need conditional jump instruction in the loop. Newer GCC compilers
   optimize the jump using CMOV instruction, which is not predicted.
   We need extra GCC options to switch the optimization off. See Makefile)

test-align: Aligned/unaligned access timing difference
  (needs improvement)

test-containers: Insert operation cost for various containers

test-false-sharing: Threads use their own data placed in single cache line
  (simple test of cache coherency protocol performance)

