
// False-sharing example
// =====================
// Two threads work on different small data optionally placed in the same cache-line
// Inspired by: http://cpp-today.blogspot.com/2008/05/false-sharing-hits-again.html
// Warning: Results depend on system load and CPU architecture

// Compile:     g++ THISFILE.cc -lpthread -O2
// Run:         time ./a.out [sharing]

#include <iostream>
#include <thread>

// L1 cache line size (getconf LEVEL1_DCACHE_LINESIZE)
const unsigned CACHE_LINE_SZ = 64;      // ***EDIT*** (depends on HW architecture)
const unsigned SZ = 10;
static_assert(SZ<CACHE_LINE_SZ);
const unsigned PAD_SZ = CACHE_LINE_SZ - SZ;     // padding to next cache line

// processing of the data
void work(unsigned char * ptr) {
    unsigned long long count = 100000000;
    while (--count) {   // warning: removed by -O3 optimization
        for (unsigned i = 0; i < SZ; ++i) {
            ++ptr[i];
        }
    }
}

// test using 2 threads
int main(int argc, char *argv[])
{
    using namespace std;
    int c = thread::hardware_concurrency();
    if(c<2) {
        cerr << "insufficient hardware_concurrency: " << c << "\n";
        return 1;
    }

    // we use single and bigger array to better control of padding
    alignas(CACHE_LINE_SZ) unsigned char a[2*CACHE_LINE_SZ] = { 0, };

    cout << "size  = " << SZ << "\n";
    const int delta = SZ + (argc > 1 ? 0 : PAD_SZ);     // use padding if any program argument
    cout << "delta = " << delta << "\n";

    thread t1(work, a);    // a passed by value
    thread t2(work, a + delta);

    t1.join();
    t2.join();

    return a[0]-a[delta];
}

