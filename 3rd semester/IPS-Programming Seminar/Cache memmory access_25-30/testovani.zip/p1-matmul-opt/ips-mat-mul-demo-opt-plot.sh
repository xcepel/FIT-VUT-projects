#!/bin/bash
if [ $# = 0 ]; then
    F="ips-mat-mul-demo.log"
else
    F="$1"
fi
LC_ALL=C
DATA=data
echo "# $0  $F" >$DATA
echo "# $(sed -n 2p $F)" >>$DATA        # machine
echo "# $(sed -n 3p $F)" >>$DATA        # date
echo "# $(sed -n 4p $F)" >>$DATA        # CFLAGS used

egrep '(^N=|seconds$)' $F |
  sed 's/seconds.*$//' |
  sed 's/N=//' |
  column -c 40 -x >>$DATA

gnuplot <<__END__
set title "NxN matrix multiplication experiment"
set term pdf; set output "data.pdf"

set key top left box
set style data linespoints
set pointsize 0.2
set xlabel "N"
set ylabel "t [s]"
set grid
plot "data" using 1:2 title "-O0", \
     "data" using 1:3 title "-O2", \
     "data" using 1:4 title "-O3", \
     "data" using 1:5 title "-O3 -funroll-all-loops", \
     x**3/1.0e9 with lines lw 0.5 title "k.x^3"

set logscale y
plot "data" using 1:2 title "-O0", \
     "data" using 1:3 title "-O2", \
     "data" using 1:4 title "-O3", \
     "data" using 1:5 title "-O3 -funroll-all-loops", \
     x**3/1.0e9 with lines lw 0.5 title "k.x^3"
__END__
