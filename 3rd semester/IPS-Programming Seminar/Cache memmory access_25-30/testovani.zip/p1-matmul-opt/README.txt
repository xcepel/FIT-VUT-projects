
Matrix multiplication (better textbook algorithm)
with various compiler optimization levels

Shows the importance of compiler optimizations

