
Measure program interruption time (for demonstration only)

The program loops and if one iteration takes more than expected time, prints
time difference (in CPU clocks). The output depends on interrupts (not all are
serviced by the same CPU core), task-switches, and other operations of the system.

