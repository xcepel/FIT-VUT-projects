
Test of cachegrind (valgrind tool)

See the cache miss results

Cachegrind emulates 2 levels of cache only (L1+LL)

LL = Last-Level cache
(Use Linux command: getconf -a|grep CACHE)

