
echo "Turn ASLR off:"
setarch `uname -m` -v -R ./00-run.sh

