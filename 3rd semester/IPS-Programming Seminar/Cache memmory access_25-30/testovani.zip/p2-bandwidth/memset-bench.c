/*
 *  memset-bench.c --- basic test of memory access speed
 *  Warning: takes cca 1min, measuring it is not exact!
 *
 */

/* max size of buffers */
#define MSIZE (256*1024*1024L)

#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

//////////////////////////////////////////////////////////////////
#ifdef __linux__
// Linux-only implementation
#include <unistd.h>             // getpid()
#include <sched.h>              // sched_setaffinity, cpu_set_t, CPU_SET
void lock_on_core1(void)
{
    cpu_set_t set;
    CPU_SET(1, &set);
    if (sched_setaffinity(getpid(), sizeof(set), &set) == -1)
        perror("sched_setaffinity");
}
#else
#define lock_on_core1()
#endif
//////////////////////////////////////////////////////////////////

/* buffer */
char *buffer;

void print_time(double dt, unsigned long size)
{
    printf("%10.3f %12.0f\n", size / 1024.0, size / (1024.0 * 1024.0) / dt);    /* KB, MiB/s */
    fflush(stdin);
}

double MEASURE(const size_t size)
{
    clock_t start;
    clock_t delta;
    static long n = 2000000;            // measure n operations
    if(n<1) n = 1;

    memset(buffer, 0, size);     // cache fill
    //////////////////////////////////////////////////////////
    // measuring #1
    start = clock();
    for (long i = 0; i < n; ++i)
        memset(buffer, 0, size);
    delta = clock() - start;    // time
    clock_t delta_min=delta;

    //////////////////////////////////////////////////////////
    // measuring #2
    start = clock();
    for (long i = 0; i < n; ++i)
        memset(buffer, 0, size);
    delta = clock() - start;    // time
    if(delta<delta_min) delta_min=delta;
    //////////////////////////////////////////////////////////
    double t = (double) delta_min / CLOCKS_PER_SEC; // time [s]
    double r = t/n;             // return time of single operation
    if (t > 0.15)
        n /= 2;                 // keep measuring time low
    if (t < 0.05)
        n *= 2;                 // keep measuring time reasonable
    return r;
}

unsigned long nstep(size_t size) {
    unsigned long KB = size/1024;
    if(KB<1)
        return 128;
    if(KB<16)
        return 512;
    if(KB<40)
        return 1024;
    return (size&~0xFFFUL)/16;
}

/* main test */
int main(int argc, const char *argv[])
{
    lock_on_core1();
    size_t size;
    size_t end = MSIZE;
    if (argc > 1)
        end = atoi(argv[1]) * 1024 * 1024L;
    if (end > MSIZE)
        end = MSIZE;
    buffer = malloc(MSIZE);
    if(buffer==NULL) {
        fprintf(stderr, "Error: no memory\n");
        return 1;
    }
#if 1 // try without this initialization -- interesting results
    memset(buffer,1,MSIZE);
#endif
    printf("# Data for Gnuplot\n");
    printf("# MSIZE = %zu KB\n", (size_t) MSIZE / 1024);
    printf("# Block size in KB      Transfer rate in MB/s\n\n");

    for (size = 128; size < end; size += nstep(size)) {
        double t = MEASURE(size);
        print_time(t, size);            // print time
    }
    return 0;
}
