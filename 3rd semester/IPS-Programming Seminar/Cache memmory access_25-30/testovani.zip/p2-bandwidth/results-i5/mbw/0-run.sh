
echo Memory benchmark:
mbw 100 >/dev/null
for i in 1 5 10 50 100 500 1000; do
    echo "Size=$i MiB"
    for j in `seq 1 10`; do
        mbw $i | grep AVG >mbw-$i
    done
done
