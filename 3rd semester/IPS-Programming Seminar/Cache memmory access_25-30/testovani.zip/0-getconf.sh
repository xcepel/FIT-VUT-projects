echo
getconf -a| grep CACHE
echo
getconf -a| grep PAGESIZE
echo
