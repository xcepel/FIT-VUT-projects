
Matrix multiplication demo

 - effect of cache and reference locality
 - effectivity of various algorithms
 - Warning: computation takes cca 5 minutes
 - Depends on libraries:
   - GSL (package libgsl-dev)
   - BLAS (for example libatlas-base-dev or libopenblas-dev)

